"use strict";(()=>{var w2=Object.create;var Fu=Object.defineProperty,E2=Object.defineProperties,S2=Object.getOwnPropertyDescriptor,I2=Object.getOwnPropertyDescriptors,x2=Object.getOwnPropertyNames,Qo=Object.getOwnPropertySymbols,T2=Object.getPrototypeOf,Bu=Object.prototype.hasOwnProperty,xm=Object.prototype.propertyIsEnumerable;var Im=(t,e,n)=>e in t?Fu(t,e,{enumerable:!0,configurable:!0,writable:!0,value:n}):t[e]=n,Ke=(t,e)=>{for(var n in e||={})Bu.call(e,n)&&Im(t,n,e[n]);if(Qo)for(var n of Qo(e))xm.call(e,n)&&Im(t,n,e[n]);return t},pt=(t,e)=>E2(t,I2(e));var qt=(t,e)=>{var n={};for(var r in t)Bu.call(t,r)&&e.indexOf(r)<0&&(n[r]=t[r]);if(t!=null&&Qo)for(var r of Qo(t))e.indexOf(r)<0&&xm.call(t,r)&&(n[r]=t[r]);return n};var kt=(t,e)=>()=>(e||t((e={exports:{}}).exports,e),e.exports);var C2=(t,e,n,r)=>{if(e&&typeof e=="object"||typeof e=="function")for(let i of x2(e))!Bu.call(t,i)&&i!==n&&Fu(t,i,{get:()=>e[i],enumerable:!(r=S2(e,i))||r.enumerable});return t};var F=(t,e,n)=>(n=t!=null?w2(T2(t)):{},C2(e||!t||!t.__esModule?Fu(n,"default",{value:t,enumerable:!0}):n,t));var qu=(t,e,n)=>new Promise((r,i)=>{var s=l=>{try{a(n.next(l))}catch(u){i(u)}},o=l=>{try{a(n.throw(l))}catch(u){i(u)}},a=l=>l.done?r(l.value):Promise.resolve(l.value).then(s,o);a((n=n.apply(t,e)).next())});var bm=kt(B=>{"use strict";var Yi=Symbol.for("react.element"),k2=Symbol.for("react.portal"),D2=Symbol.for("react.fragment"),N2=Symbol.for("react.strict_mode"),P2=Symbol.for("react.profiler"),_2=Symbol.for("react.provider"),O2=Symbol.for("react.context"),L2=Symbol.for("react.forward_ref"),M2=Symbol.for("react.suspense"),b2=Symbol.for("react.memo"),R2=Symbol.for("react.lazy"),Tm=Symbol.iterator;function z2(t){return t===null||typeof t!="object"?null:(t=Tm&&t[Tm]||t["@@iterator"],typeof t=="function"?t:null)}var Dm={isMounted:function(){return!1},enqueueForceUpdate:function(){},enqueueReplaceState:function(){},enqueueSetState:function(){}},Nm=Object.assign,Pm={};function Xr(t,e,n){this.props=t,this.context=e,this.refs=Pm,this.updater=n||Dm}Xr.prototype.isReactComponent={};Xr.prototype.setState=function(t,e){if(typeof t!="object"&&typeof t!="function"&&t!=null)throw Error("setState(...): takes an object of state variables to update or a function which returns an object of state variables.");this.updater.enqueueSetState(this,t,e,"setState")};Xr.prototype.forceUpdate=function(t){this.updater.enqueueForceUpdate(this,t,"forceUpdate")};function _m(){}_m.prototype=Xr.prototype;function Uu(t,e,n){this.props=t,this.context=e,this.refs=Pm,this.updater=n||Dm}var ju=Uu.prototype=new _m;ju.constructor=Uu;Nm(ju,Xr.prototype);ju.isPureReactComponent=!0;var Cm=Array.isArray,Om=Object.prototype.hasOwnProperty,Qu={current:null},Lm={key:!0,ref:!0,__self:!0,__source:!0};function Mm(t,e,n){var r,i={},s=null,o=null;if(e!=null)for(r in e.ref!==void 0&&(o=e.ref),e.key!==void 0&&(s=""+e.key),e)Om.call(e,r)&&!Lm.hasOwnProperty(r)&&(i[r]=e[r]);var a=arguments.length-2;if(a===1)i.children=n;else if(1<a){for(var l=Array(a),u=0;u<a;u++)l[u]=arguments[u+2];i.children=l}if(t&&t.defaultProps)for(r in a=t.defaultProps,a)i[r]===void 0&&(i[r]=a[r]);return{$$typeof:Yi,type:t,key:s,ref:o,props:i,_owner:Qu.current}}function F2(t,e){return{$$typeof:Yi,type:t.type,key:e,ref:t.ref,props:t.props,_owner:t._owner}}function Hu(t){return typeof t=="object"&&t!==null&&t.$$typeof===Yi}function B2(t){var e={"=":"=0",":":"=2"};return"$"+t.replace(/[=:]/g,function(n){return e[n]})}var km=/\/+/g;function Vu(t,e){return typeof t=="object"&&t!==null&&t.key!=null?B2(""+t.key):e.toString(36)}function Ko(t,e,n,r,i){var s=typeof t;(s==="undefined"||s==="boolean")&&(t=null);var o=!1;if(t===null)o=!0;else switch(s){case"string":case"number":o=!0;break;case"object":switch(t.$$typeof){case Yi:case k2:o=!0}}if(o)return o=t,i=i(o),t=r===""?"."+Vu(o,0):r,Cm(i)?(n="",t!=null&&(n=t.replace(km,"$&/")+"/"),Ko(i,e,n,"",function(u){return u})):i!=null&&(Hu(i)&&(i=F2(i,n+(!i.key||o&&o.key===i.key?"":(""+i.key).replace(km,"$&/")+"/")+t)),e.push(i)),1;if(o=0,r=r===""?".":r+":",Cm(t))for(var a=0;a<t.length;a++){s=t[a];var l=r+Vu(s,a);o+=Ko(s,e,n,l,i)}else if(l=z2(t),typeof l=="function")for(t=l.call(t),a=0;!(s=t.next()).done;)s=s.value,l=r+Vu(s,a++),o+=Ko(s,e,n,l,i);else if(s==="object")throw e=String(t),Error("Objects are not valid as a React child (found: "+(e==="[object Object]"?"object with keys {"+Object.keys(t).join(", ")+"}":e)+"). If you meant to render a collection of children, use an array instead.");return o}function Ho(t,e,n){if(t==null)return t;var r=[],i=0;return Ko(t,r,"","",function(s){return e.call(n,s,i++)}),r}function q2(t){if(t._status===-1){var e=t._result;e=e(),e.then(function(n){(t._status===0||t._status===-1)&&(t._status=1,t._result=n)},function(n){(t._status===0||t._status===-1)&&(t._status=2,t._result=n)}),t._status===-1&&(t._status=0,t._result=e)}if(t._status===1)return t._result.default;throw t._result}var Xe={current:null},Xo={transition:null},V2={ReactCurrentDispatcher:Xe,ReactCurrentBatchConfig:Xo,ReactCurrentOwner:Qu};B.Children={map:Ho,forEach:function(t,e,n){Ho(t,function(){e.apply(this,arguments)},n)},count:function(t){var e=0;return Ho(t,function(){e++}),e},toArray:function(t){return Ho(t,function(e){return e})||[]},only:function(t){if(!Hu(t))throw Error("React.Children.only expected to receive a single React element child.");return t}};B.Component=Xr;B.Fragment=D2;B.Profiler=P2;B.PureComponent=Uu;B.StrictMode=N2;B.Suspense=M2;B.__SECRET_INTERNALS_DO_NOT_USE_OR_YOU_WILL_BE_FIRED=V2;B.cloneElement=function(t,e,n){if(t==null)throw Error("React.cloneElement(...): The argument must be a React element, but you passed "+t+".");var r=Nm({},t.props),i=t.key,s=t.ref,o=t._owner;if(e!=null){if(e.ref!==void 0&&(s=e.ref,o=Qu.current),e.key!==void 0&&(i=""+e.key),t.type&&t.type.defaultProps)var a=t.type.defaultProps;for(l in e)Om.call(e,l)&&!Lm.hasOwnProperty(l)&&(r[l]=e[l]===void 0&&a!==void 0?a[l]:e[l])}var l=arguments.length-2;if(l===1)r.children=n;else if(1<l){a=Array(l);for(var u=0;u<l;u++)a[u]=arguments[u+2];r.children=a}return{$$typeof:Yi,type:t.type,key:i,ref:s,props:r,_owner:o}};B.createContext=function(t){return t={$$typeof:O2,_currentValue:t,_currentValue2:t,_threadCount:0,Provider:null,Consumer:null,_defaultValue:null,_globalName:null},t.Provider={$$typeof:_2,_context:t},t.Consumer=t};B.createElement=Mm;B.createFactory=function(t){var e=Mm.bind(null,t);return e.type=t,e};B.createRef=function(){return{current:null}};B.forwardRef=function(t){return{$$typeof:L2,render:t}};B.isValidElement=Hu;B.lazy=function(t){return{$$typeof:R2,_payload:{_status:-1,_result:t},_init:q2}};B.memo=function(t,e){return{$$typeof:b2,type:t,compare:e===void 0?null:e}};B.startTransition=function(t){var e=Xo.transition;Xo.transition={};try{t()}finally{Xo.transition=e}};B.unstable_act=function(){throw Error("act(...) is not supported in production builds of React.")};B.useCallback=function(t,e){return Xe.current.useCallback(t,e)};B.useContext=function(t){return Xe.current.useContext(t)};B.useDebugValue=function(){};B.useDeferredValue=function(t){return Xe.current.useDeferredValue(t)};B.useEffect=function(t,e){return Xe.current.useEffect(t,e)};B.useId=function(){return Xe.current.useId()};B.useImperativeHandle=function(t,e,n){return Xe.current.useImperativeHandle(t,e,n)};B.useInsertionEffect=function(t,e){return Xe.current.useInsertionEffect(t,e)};B.useLayoutEffect=function(t,e){return Xe.current.useLayoutEffect(t,e)};B.useMemo=function(t,e){return Xe.current.useMemo(t,e)};B.useReducer=function(t,e,n){return Xe.current.useReducer(t,e,n)};B.useRef=function(t){return Xe.current.useRef(t)};B.useState=function(t){return Xe.current.useState(t)};B.useSyncExternalStore=function(t,e,n){return Xe.current.useSyncExternalStore(t,e,n)};B.useTransition=function(){return Xe.current.useTransition()};B.version="18.2.0"});var it=kt((Rx,Rm)=>{"use strict";Rm.exports=bm()});var Km=kt(Z=>{"use strict";function Gu(t,e){var n=t.length;t.push(e);e:for(;0<n;){var r=n-1>>>1,i=t[r];if(0<Wo(i,e))t[r]=e,t[n]=i,n=r;else break e}}function Dt(t){return t.length===0?null:t[0]}function Jo(t){if(t.length===0)return null;var e=t[0],n=t.pop();if(n!==e){t[0]=n;e:for(var r=0,i=t.length,s=i>>>1;r<s;){var o=2*(r+1)-1,a=t[o],l=o+1,u=t[l];if(0>Wo(a,n))l<i&&0>Wo(u,a)?(t[r]=u,t[l]=n,r=l):(t[r]=a,t[o]=n,r=o);else if(l<i&&0>Wo(u,n))t[r]=u,t[l]=n,r=l;else break e}}return e}function Wo(t,e){var n=t.sortIndex-e.sortIndex;return n!==0?n:t.id-e.id}typeof performance=="object"&&typeof performance.now=="function"?(zm=performance,Z.unstable_now=function(){return zm.now()}):(Ku=Date,Fm=Ku.now(),Z.unstable_now=function(){return Ku.now()-Fm});var zm,Ku,Fm,Vt=[],Dn=[],U2=1,mt=null,be=3,Zo=!1,fr=!1,es=!1,Vm=typeof setTimeout=="function"?setTimeout:null,Um=typeof clearTimeout=="function"?clearTimeout:null,Bm=typeof setImmediate<"u"?setImmediate:null;typeof navigator<"u"&&navigator.scheduling!==void 0&&navigator.scheduling.isInputPending!==void 0&&navigator.scheduling.isInputPending.bind(navigator.scheduling);function Ju(t){for(var e=Dt(Dn);e!==null;){if(e.callback===null)Jo(Dn);else if(e.startTime<=t)Jo(Dn),e.sortIndex=e.expirationTime,Gu(Vt,e);else break;e=Dt(Dn)}}function Zu(t){if(es=!1,Ju(t),!fr)if(Dt(Vt)!==null)fr=!0,$u(Yu);else{var e=Dt(Dn);e!==null&&ec(Zu,e.startTime-t)}}function Yu(t,e){fr=!1,es&&(es=!1,Um(ts),ts=-1),Zo=!0;var n=be;try{for(Ju(e),mt=Dt(Vt);mt!==null&&(!(mt.expirationTime>e)||t&&!Hm());){var r=mt.callback;if(typeof r=="function"){mt.callback=null,be=mt.priorityLevel;var i=r(mt.expirationTime<=e);e=Z.unstable_now(),typeof i=="function"?mt.callback=i:mt===Dt(Vt)&&Jo(Vt),Ju(e)}else Jo(Vt);mt=Dt(Vt)}if(mt!==null)var s=!0;else{var o=Dt(Dn);o!==null&&ec(Zu,o.startTime-e),s=!1}return s}finally{mt=null,be=n,Zo=!1}}var Yo=!1,Go=null,ts=-1,jm=5,Qm=-1;function Hm(){return!(Z.unstable_now()-Qm<jm)}function Xu(){if(Go!==null){var t=Z.unstable_now();Qm=t;var e=!0;try{e=Go(!0,t)}finally{e?$i():(Yo=!1,Go=null)}}else Yo=!1}var $i;typeof Bm=="function"?$i=function(){Bm(Xu)}:typeof MessageChannel<"u"?(Wu=new MessageChannel,qm=Wu.port2,Wu.port1.onmessage=Xu,$i=function(){qm.postMessage(null)}):$i=function(){Vm(Xu,0)};var Wu,qm;function $u(t){Go=t,Yo||(Yo=!0,$i())}function ec(t,e){ts=Vm(function(){t(Z.unstable_now())},e)}Z.unstable_IdlePriority=5;Z.unstable_ImmediatePriority=1;Z.unstable_LowPriority=4;Z.unstable_NormalPriority=3;Z.unstable_Profiling=null;Z.unstable_UserBlockingPriority=2;Z.unstable_cancelCallback=function(t){t.callback=null};Z.unstable_continueExecution=function(){fr||Zo||(fr=!0,$u(Yu))};Z.unstable_forceFrameRate=function(t){0>t||125<t?console.error("forceFrameRate takes a positive int between 0 and 125, forcing frame rates higher than 125 fps is not supported"):jm=0<t?Math.floor(1e3/t):5};Z.unstable_getCurrentPriorityLevel=function(){return be};Z.unstable_getFirstCallbackNode=function(){return Dt(Vt)};Z.unstable_next=function(t){switch(be){case 1:case 2:case 3:var e=3;break;default:e=be}var n=be;be=e;try{return t()}finally{be=n}};Z.unstable_pauseExecution=function(){};Z.unstable_requestPaint=function(){};Z.unstable_runWithPriority=function(t,e){switch(t){case 1:case 2:case 3:case 4:case 5:break;default:t=3}var n=be;be=t;try{return e()}finally{be=n}};Z.unstable_scheduleCallback=function(t,e,n){var r=Z.unstable_now();switch(typeof n=="object"&&n!==null?(n=n.delay,n=typeof n=="number"&&0<n?r+n:r):n=r,t){case 1:var i=-1;break;case 2:i=250;break;case 5:i=1073741823;break;case 4:i=1e4;break;default:i=5e3}return i=n+i,t={id:U2++,callback:e,priorityLevel:t,startTime:n,expirationTime:i,sortIndex:-1},n>r?(t.sortIndex=n,Gu(Dn,t),Dt(Vt)===null&&t===Dt(Dn)&&(es?(Um(ts),ts=-1):es=!0,ec(Zu,n-r))):(t.sortIndex=i,Gu(Vt,t),fr||Zo||(fr=!0,$u(Yu))),t};Z.unstable_shouldYield=Hm;Z.unstable_wrapCallback=function(t){var e=be;return function(){var n=be;be=e;try{return t.apply(this,arguments)}finally{be=n}}}});var Wm=kt((Fx,Xm)=>{"use strict";Xm.exports=Km()});var e1=kt(ct=>{"use strict";var t0=it(),lt=Wm();function w(t){for(var e="https://reactjs.org/docs/error-decoder.html?invariant="+t,n=1;n<arguments.length;n++)e+="&args[]="+encodeURIComponent(arguments[n]);return"Minified React error #"+t+"; visit "+e+" for the full message or use the non-minified dev environment for full errors and additional helpful warnings."}var n0=new Set,Is={};function Cr(t,e){pi(t,e),pi(t+"Capture",e)}function pi(t,e){for(Is[t]=e,t=0;t<e.length;t++)n0.add(e[t])}var ln=!(typeof window>"u"||typeof window.document>"u"||typeof window.document.createElement>"u"),Ic=Object.prototype.hasOwnProperty,j2=/^[:A-Z_a-z\u00C0-\u00D6\u00D8-\u00F6\u00F8-\u02FF\u0370-\u037D\u037F-\u1FFF\u200C-\u200D\u2070-\u218F\u2C00-\u2FEF\u3001-\uD7FF\uF900-\uFDCF\uFDF0-\uFFFD][:A-Z_a-z\u00C0-\u00D6\u00D8-\u00F6\u00F8-\u02FF\u0370-\u037D\u037F-\u1FFF\u200C-\u200D\u2070-\u218F\u2C00-\u2FEF\u3001-\uD7FF\uF900-\uFDCF\uFDF0-\uFFFD\-.0-9\u00B7\u0300-\u036F\u203F-\u2040]*$/,Gm={},Jm={};function Q2(t){return Ic.call(Jm,t)?!0:Ic.call(Gm,t)?!1:j2.test(t)?Jm[t]=!0:(Gm[t]=!0,!1)}function H2(t,e,n,r){if(n!==null&&n.type===0)return!1;switch(typeof e){case"function":case"symbol":return!0;case"boolean":return r?!1:n!==null?!n.acceptsBooleans:(t=t.toLowerCase().slice(0,5),t!=="data-"&&t!=="aria-");default:return!1}}function K2(t,e,n,r){if(e===null||typeof e>"u"||H2(t,e,n,r))return!0;if(r)return!1;if(n!==null)switch(n.type){case 3:return!e;case 4:return e===!1;case 5:return isNaN(e);case 6:return isNaN(e)||1>e}return!1}function Je(t,e,n,r,i,s,o){this.acceptsBooleans=e===2||e===3||e===4,this.attributeName=r,this.attributeNamespace=i,this.mustUseProperty=n,this.propertyName=t,this.type=e,this.sanitizeURL=s,this.removeEmptyString=o}var Oe={};"children dangerouslySetInnerHTML defaultValue defaultChecked innerHTML suppressContentEditableWarning suppressHydrationWarning style".split(" ").forEach(function(t){Oe[t]=new Je(t,0,!1,t,null,!1,!1)});[["acceptCharset","accept-charset"],["className","class"],["htmlFor","for"],["httpEquiv","http-equiv"]].forEach(function(t){var e=t[0];Oe[e]=new Je(e,1,!1,t[1],null,!1,!1)});["contentEditable","draggable","spellCheck","value"].forEach(function(t){Oe[t]=new Je(t,2,!1,t.toLowerCase(),null,!1,!1)});["autoReverse","externalResourcesRequired","focusable","preserveAlpha"].forEach(function(t){Oe[t]=new Je(t,2,!1,t,null,!1,!1)});"allowFullScreen async autoFocus autoPlay controls default defer disabled disablePictureInPicture disableRemotePlayback formNoValidate hidden loop noModule noValidate open playsInline readOnly required reversed scoped seamless itemScope".split(" ").forEach(function(t){Oe[t]=new Je(t,3,!1,t.toLowerCase(),null,!1,!1)});["checked","multiple","muted","selected"].forEach(function(t){Oe[t]=new Je(t,3,!0,t,null,!1,!1)});["capture","download"].forEach(function(t){Oe[t]=new Je(t,4,!1,t,null,!1,!1)});["cols","rows","size","span"].forEach(function(t){Oe[t]=new Je(t,6,!1,t,null,!1,!1)});["rowSpan","start"].forEach(function(t){Oe[t]=new Je(t,5,!1,t.toLowerCase(),null,!1,!1)});var mh=/[\-:]([a-z])/g;function gh(t){return t[1].toUpperCase()}"accent-height alignment-baseline arabic-form baseline-shift cap-height clip-path clip-rule color-interpolation color-interpolation-filters color-profile color-rendering dominant-baseline enable-background fill-opacity fill-rule flood-color flood-opacity font-family font-size font-size-adjust font-stretch font-style font-variant font-weight glyph-name glyph-orientation-horizontal glyph-orientation-vertical horiz-adv-x horiz-origin-x image-rendering letter-spacing lighting-color marker-end marker-mid marker-start overline-position overline-thickness paint-order panose-1 pointer-events rendering-intent shape-rendering stop-color stop-opacity strikethrough-position strikethrough-thickness stroke-dasharray stroke-dashoffset stroke-linecap stroke-linejoin stroke-miterlimit stroke-opacity stroke-width text-anchor text-decoration text-rendering underline-position underline-thickness unicode-bidi unicode-range units-per-em v-alphabetic v-hanging v-ideographic v-mathematical vector-effect vert-adv-y vert-origin-x vert-origin-y word-spacing writing-mode xmlns:xlink x-height".split(" ").forEach(function(t){var e=t.replace(mh,gh);Oe[e]=new Je(e,1,!1,t,null,!1,!1)});"xlink:actuate xlink:arcrole xlink:role xlink:show xlink:title xlink:type".split(" ").forEach(function(t){var e=t.replace(mh,gh);Oe[e]=new Je(e,1,!1,t,"http://www.w3.org/1999/xlink",!1,!1)});["xml:base","xml:lang","xml:space"].forEach(function(t){var e=t.replace(mh,gh);Oe[e]=new Je(e,1,!1,t,"http://www.w3.org/XML/1998/namespace",!1,!1)});["tabIndex","crossOrigin"].forEach(function(t){Oe[t]=new Je(t,1,!1,t.toLowerCase(),null,!1,!1)});Oe.xlinkHref=new Je("xlinkHref",1,!1,"xlink:href","http://www.w3.org/1999/xlink",!0,!1);["src","href","action","formAction"].forEach(function(t){Oe[t]=new Je(t,1,!1,t.toLowerCase(),null,!0,!0)});function yh(t,e,n,r){var i=Oe.hasOwnProperty(e)?Oe[e]:null;(i!==null?i.type!==0:r||!(2<e.length)||e[0]!=="o"&&e[0]!=="O"||e[1]!=="n"&&e[1]!=="N")&&(K2(e,n,i,r)&&(n=null),r||i===null?Q2(e)&&(n===null?t.removeAttribute(e):t.setAttribute(e,""+n)):i.mustUseProperty?t[i.propertyName]=n===null?i.type===3?!1:"":n:(e=i.attributeName,r=i.attributeNamespace,n===null?t.removeAttribute(e):(i=i.type,n=i===3||i===4&&n===!0?"":""+n,r?t.setAttributeNS(r,e,n):t.setAttribute(e,n))))}var dn=t0.__SECRET_INTERNALS_DO_NOT_USE_OR_YOU_WILL_BE_FIRED,$o=Symbol.for("react.element"),Jr=Symbol.for("react.portal"),Zr=Symbol.for("react.fragment"),Ah=Symbol.for("react.strict_mode"),xc=Symbol.for("react.profiler"),r0=Symbol.for("react.provider"),i0=Symbol.for("react.context"),vh=Symbol.for("react.forward_ref"),Tc=Symbol.for("react.suspense"),Cc=Symbol.for("react.suspense_list"),wh=Symbol.for("react.memo"),Pn=Symbol.for("react.lazy");Symbol.for("react.scope");Symbol.for("react.debug_trace_mode");var s0=Symbol.for("react.offscreen");Symbol.for("react.legacy_hidden");Symbol.for("react.cache");Symbol.for("react.tracing_marker");var Zm=Symbol.iterator;function ns(t){return t===null||typeof t!="object"?null:(t=Zm&&t[Zm]||t["@@iterator"],typeof t=="function"?t:null)}var ue=Object.assign,tc;function cs(t){if(tc===void 0)try{throw Error()}catch(n){var e=n.stack.trim().match(/\n( *(at )?)/);tc=e&&e[1]||""}return`
`+tc+t}var nc=!1;function rc(t,e){if(!t||nc)return"";nc=!0;var n=Error.prepareStackTrace;Error.prepareStackTrace=void 0;try{if(e)if(e=function(){throw Error()},Object.defineProperty(e.prototype,"props",{set:function(){throw Error()}}),typeof Reflect=="object"&&Reflect.construct){try{Reflect.construct(e,[])}catch(u){var r=u}Reflect.construct(t,[],e)}else{try{e.call()}catch(u){r=u}t.call(e.prototype)}else{try{throw Error()}catch(u){r=u}t()}}catch(u){if(u&&r&&typeof u.stack=="string"){for(var i=u.stack.split(`
`),s=r.stack.split(`
`),o=i.length-1,a=s.length-1;1<=o&&0<=a&&i[o]!==s[a];)a--;for(;1<=o&&0<=a;o--,a--)if(i[o]!==s[a]){if(o!==1||a!==1)do if(o--,a--,0>a||i[o]!==s[a]){var l=`
`+i[o].replace(" at new "," at ");return t.displayName&&l.includes("<anonymous>")&&(l=l.replace("<anonymous>",t.displayName)),l}while(1<=o&&0<=a);break}}}finally{nc=!1,Error.prepareStackTrace=n}return(t=t?t.displayName||t.name:"")?cs(t):""}function X2(t){switch(t.tag){case 5:return cs(t.type);case 16:return cs("Lazy");case 13:return cs("Suspense");case 19:return cs("SuspenseList");case 0:case 2:case 15:return t=rc(t.type,!1),t;case 11:return t=rc(t.type.render,!1),t;case 1:return t=rc(t.type,!0),t;default:return""}}function kc(t){if(t==null)return null;if(typeof t=="function")return t.displayName||t.name||null;if(typeof t=="string")return t;switch(t){case Zr:return"Fragment";case Jr:return"Portal";case xc:return"Profiler";case Ah:return"StrictMode";case Tc:return"Suspense";case Cc:return"SuspenseList"}if(typeof t=="object")switch(t.$$typeof){case i0:return(t.displayName||"Context")+".Consumer";case r0:return(t._context.displayName||"Context")+".Provider";case vh:var e=t.render;return t=t.displayName,t||(t=e.displayName||e.name||"",t=t!==""?"ForwardRef("+t+")":"ForwardRef"),t;case wh:return e=t.displayName||null,e!==null?e:kc(t.type)||"Memo";case Pn:e=t._payload,t=t._init;try{return kc(t(e))}catch{}}return null}function W2(t){var e=t.type;switch(t.tag){case 24:return"Cache";case 9:return(e.displayName||"Context")+".Consumer";case 10:return(e._context.displayName||"Context")+".Provider";case 18:return"DehydratedFragment";case 11:return t=e.render,t=t.displayName||t.name||"",e.displayName||(t!==""?"ForwardRef("+t+")":"ForwardRef");case 7:return"Fragment";case 5:return e;case 4:return"Portal";case 3:return"Root";case 6:return"Text";case 16:return kc(e);case 8:return e===Ah?"StrictMode":"Mode";case 22:return"Offscreen";case 12:return"Profiler";case 21:return"Scope";case 13:return"Suspense";case 19:return"SuspenseList";case 25:return"TracingMarker";case 1:case 0:case 17:case 2:case 14:case 15:if(typeof e=="function")return e.displayName||e.name||null;if(typeof e=="string")return e}return null}function Qn(t){switch(typeof t){case"boolean":case"number":case"string":case"undefined":return t;case"object":return t;default:return""}}function o0(t){var e=t.type;return(t=t.nodeName)&&t.toLowerCase()==="input"&&(e==="checkbox"||e==="radio")}function G2(t){var e=o0(t)?"checked":"value",n=Object.getOwnPropertyDescriptor(t.constructor.prototype,e),r=""+t[e];if(!t.hasOwnProperty(e)&&typeof n<"u"&&typeof n.get=="function"&&typeof n.set=="function"){var i=n.get,s=n.set;return Object.defineProperty(t,e,{configurable:!0,get:function(){return i.call(this)},set:function(o){r=""+o,s.call(this,o)}}),Object.defineProperty(t,e,{enumerable:n.enumerable}),{getValue:function(){return r},setValue:function(o){r=""+o},stopTracking:function(){t._valueTracker=null,delete t[e]}}}}function ea(t){t._valueTracker||(t._valueTracker=G2(t))}function a0(t){if(!t)return!1;var e=t._valueTracker;if(!e)return!0;var n=e.getValue(),r="";return t&&(r=o0(t)?t.checked?"true":"false":t.value),t=r,t!==n?(e.setValue(t),!0):!1}function Da(t){if(t=t||(typeof document<"u"?document:void 0),typeof t>"u")return null;try{return t.activeElement||t.body}catch{return t.body}}function Dc(t,e){var n=e.checked;return ue({},e,{defaultChecked:void 0,defaultValue:void 0,value:void 0,checked:n??t._wrapperState.initialChecked})}function Ym(t,e){var n=e.defaultValue==null?"":e.defaultValue,r=e.checked!=null?e.checked:e.defaultChecked;n=Qn(e.value!=null?e.value:n),t._wrapperState={initialChecked:r,initialValue:n,controlled:e.type==="checkbox"||e.type==="radio"?e.checked!=null:e.value!=null}}function l0(t,e){e=e.checked,e!=null&&yh(t,"checked",e,!1)}function Nc(t,e){l0(t,e);var n=Qn(e.value),r=e.type;if(n!=null)r==="number"?(n===0&&t.value===""||t.value!=n)&&(t.value=""+n):t.value!==""+n&&(t.value=""+n);else if(r==="submit"||r==="reset"){t.removeAttribute("value");return}e.hasOwnProperty("value")?Pc(t,e.type,n):e.hasOwnProperty("defaultValue")&&Pc(t,e.type,Qn(e.defaultValue)),e.checked==null&&e.defaultChecked!=null&&(t.defaultChecked=!!e.defaultChecked)}function $m(t,e,n){if(e.hasOwnProperty("value")||e.hasOwnProperty("defaultValue")){var r=e.type;if(!(r!=="submit"&&r!=="reset"||e.value!==void 0&&e.value!==null))return;e=""+t._wrapperState.initialValue,n||e===t.value||(t.value=e),t.defaultValue=e}n=t.name,n!==""&&(t.name=""),t.defaultChecked=!!t._wrapperState.initialChecked,n!==""&&(t.name=n)}function Pc(t,e,n){(e!=="number"||Da(t.ownerDocument)!==t)&&(n==null?t.defaultValue=""+t._wrapperState.initialValue:t.defaultValue!==""+n&&(t.defaultValue=""+n))}var hs=Array.isArray;function li(t,e,n,r){if(t=t.options,e){e={};for(var i=0;i<n.length;i++)e["$"+n[i]]=!0;for(n=0;n<t.length;n++)i=e.hasOwnProperty("$"+t[n].value),t[n].selected!==i&&(t[n].selected=i),i&&r&&(t[n].defaultSelected=!0)}else{for(n=""+Qn(n),e=null,i=0;i<t.length;i++){if(t[i].value===n){t[i].selected=!0,r&&(t[i].defaultSelected=!0);return}e!==null||t[i].disabled||(e=t[i])}e!==null&&(e.selected=!0)}}function _c(t,e){if(e.dangerouslySetInnerHTML!=null)throw Error(w(91));return ue({},e,{value:void 0,defaultValue:void 0,children:""+t._wrapperState.initialValue})}function eg(t,e){var n=e.value;if(n==null){if(n=e.children,e=e.defaultValue,n!=null){if(e!=null)throw Error(w(92));if(hs(n)){if(1<n.length)throw Error(w(93));n=n[0]}e=n}e==null&&(e=""),n=e}t._wrapperState={initialValue:Qn(n)}}function u0(t,e){var n=Qn(e.value),r=Qn(e.defaultValue);n!=null&&(n=""+n,n!==t.value&&(t.value=n),e.defaultValue==null&&t.defaultValue!==n&&(t.defaultValue=n)),r!=null&&(t.defaultValue=""+r)}function tg(t){var e=t.textContent;e===t._wrapperState.initialValue&&e!==""&&e!==null&&(t.value=e)}function c0(t){switch(t){case"svg":return"http://www.w3.org/2000/svg";case"math":return"http://www.w3.org/1998/Math/MathML";default:return"http://www.w3.org/1999/xhtml"}}function Oc(t,e){return t==null||t==="http://www.w3.org/1999/xhtml"?c0(e):t==="http://www.w3.org/2000/svg"&&e==="foreignObject"?"http://www.w3.org/1999/xhtml":t}var ta,h0=function(t){return typeof MSApp<"u"&&MSApp.execUnsafeLocalFunction?function(e,n,r,i){MSApp.execUnsafeLocalFunction(function(){return t(e,n,r,i)})}:t}(function(t,e){if(t.namespaceURI!=="http://www.w3.org/2000/svg"||"innerHTML"in t)t.innerHTML=e;else{for(ta=ta||document.createElement("div"),ta.innerHTML="<svg>"+e.valueOf().toString()+"</svg>",e=ta.firstChild;t.firstChild;)t.removeChild(t.firstChild);for(;e.firstChild;)t.appendChild(e.firstChild)}});function xs(t,e){if(e){var n=t.firstChild;if(n&&n===t.lastChild&&n.nodeType===3){n.nodeValue=e;return}}t.textContent=e}var ps={animationIterationCount:!0,aspectRatio:!0,borderImageOutset:!0,borderImageSlice:!0,borderImageWidth:!0,boxFlex:!0,boxFlexGroup:!0,boxOrdinalGroup:!0,columnCount:!0,columns:!0,flex:!0,flexGrow:!0,flexPositive:!0,flexShrink:!0,flexNegative:!0,flexOrder:!0,gridArea:!0,gridRow:!0,gridRowEnd:!0,gridRowSpan:!0,gridRowStart:!0,gridColumn:!0,gridColumnEnd:!0,gridColumnSpan:!0,gridColumnStart:!0,fontWeight:!0,lineClamp:!0,lineHeight:!0,opacity:!0,order:!0,orphans:!0,tabSize:!0,widows:!0,zIndex:!0,zoom:!0,fillOpacity:!0,floodOpacity:!0,stopOpacity:!0,strokeDasharray:!0,strokeDashoffset:!0,strokeMiterlimit:!0,strokeOpacity:!0,strokeWidth:!0},J2=["Webkit","ms","Moz","O"];Object.keys(ps).forEach(function(t){J2.forEach(function(e){e=e+t.charAt(0).toUpperCase()+t.substring(1),ps[e]=ps[t]})});function d0(t,e,n){return e==null||typeof e=="boolean"||e===""?"":n||typeof e!="number"||e===0||ps.hasOwnProperty(t)&&ps[t]?(""+e).trim():e+"px"}function f0(t,e){t=t.style;for(var n in e)if(e.hasOwnProperty(n)){var r=n.indexOf("--")===0,i=d0(n,e[n],r);n==="float"&&(n="cssFloat"),r?t.setProperty(n,i):t[n]=i}}var Z2=ue({menuitem:!0},{area:!0,base:!0,br:!0,col:!0,embed:!0,hr:!0,img:!0,input:!0,keygen:!0,link:!0,meta:!0,param:!0,source:!0,track:!0,wbr:!0});function Lc(t,e){if(e){if(Z2[t]&&(e.children!=null||e.dangerouslySetInnerHTML!=null))throw Error(w(137,t));if(e.dangerouslySetInnerHTML!=null){if(e.children!=null)throw Error(w(60));if(typeof e.dangerouslySetInnerHTML!="object"||!("__html"in e.dangerouslySetInnerHTML))throw Error(w(61))}if(e.style!=null&&typeof e.style!="object")throw Error(w(62))}}function Mc(t,e){if(t.indexOf("-")===-1)return typeof e.is=="string";switch(t){case"annotation-xml":case"color-profile":case"font-face":case"font-face-src":case"font-face-uri":case"font-face-format":case"font-face-name":case"missing-glyph":return!1;default:return!0}}var bc=null;function Eh(t){return t=t.target||t.srcElement||window,t.correspondingUseElement&&(t=t.correspondingUseElement),t.nodeType===3?t.parentNode:t}var Rc=null,ui=null,ci=null;function ng(t){if(t=Us(t)){if(typeof Rc!="function")throw Error(w(280));var e=t.stateNode;e&&(e=nl(e),Rc(t.stateNode,t.type,e))}}function p0(t){ui?ci?ci.push(t):ci=[t]:ui=t}function m0(){if(ui){var t=ui,e=ci;if(ci=ui=null,ng(t),e)for(t=0;t<e.length;t++)ng(e[t])}}function g0(t,e){return t(e)}function y0(){}var ic=!1;function A0(t,e,n){if(ic)return t(e,n);ic=!0;try{return g0(t,e,n)}finally{ic=!1,(ui!==null||ci!==null)&&(y0(),m0())}}function Ts(t,e){var n=t.stateNode;if(n===null)return null;var r=nl(n);if(r===null)return null;n=r[e];e:switch(e){case"onClick":case"onClickCapture":case"onDoubleClick":case"onDoubleClickCapture":case"onMouseDown":case"onMouseDownCapture":case"onMouseMove":case"onMouseMoveCapture":case"onMouseUp":case"onMouseUpCapture":case"onMouseEnter":(r=!r.disabled)||(t=t.type,r=!(t==="button"||t==="input"||t==="select"||t==="textarea")),t=!r;break e;default:t=!1}if(t)return null;if(n&&typeof n!="function")throw Error(w(231,e,typeof n));return n}var zc=!1;if(ln)try{Wr={},Object.defineProperty(Wr,"passive",{get:function(){zc=!0}}),window.addEventListener("test",Wr,Wr),window.removeEventListener("test",Wr,Wr)}catch{zc=!1}var Wr;function Y2(t,e,n,r,i,s,o,a,l){var u=Array.prototype.slice.call(arguments,3);try{e.apply(n,u)}catch(c){this.onError(c)}}var ms=!1,Na=null,Pa=!1,Fc=null,$2={onError:function(t){ms=!0,Na=t}};function e5(t,e,n,r,i,s,o,a,l){ms=!1,Na=null,Y2.apply($2,arguments)}function t5(t,e,n,r,i,s,o,a,l){if(e5.apply(this,arguments),ms){if(ms){var u=Na;ms=!1,Na=null}else throw Error(w(198));Pa||(Pa=!0,Fc=u)}}function kr(t){var e=t,n=t;if(t.alternate)for(;e.return;)e=e.return;else{t=e;do e=t,e.flags&4098&&(n=e.return),t=e.return;while(t)}return e.tag===3?n:null}function v0(t){if(t.tag===13){var e=t.memoizedState;if(e===null&&(t=t.alternate,t!==null&&(e=t.memoizedState)),e!==null)return e.dehydrated}return null}function rg(t){if(kr(t)!==t)throw Error(w(188))}function n5(t){var e=t.alternate;if(!e){if(e=kr(t),e===null)throw Error(w(188));return e!==t?null:t}for(var n=t,r=e;;){var i=n.return;if(i===null)break;var s=i.alternate;if(s===null){if(r=i.return,r!==null){n=r;continue}break}if(i.child===s.child){for(s=i.child;s;){if(s===n)return rg(i),t;if(s===r)return rg(i),e;s=s.sibling}throw Error(w(188))}if(n.return!==r.return)n=i,r=s;else{for(var o=!1,a=i.child;a;){if(a===n){o=!0,n=i,r=s;break}if(a===r){o=!0,r=i,n=s;break}a=a.sibling}if(!o){for(a=s.child;a;){if(a===n){o=!0,n=s,r=i;break}if(a===r){o=!0,r=s,n=i;break}a=a.sibling}if(!o)throw Error(w(189))}}if(n.alternate!==r)throw Error(w(190))}if(n.tag!==3)throw Error(w(188));return n.stateNode.current===n?t:e}function w0(t){return t=n5(t),t!==null?E0(t):null}function E0(t){if(t.tag===5||t.tag===6)return t;for(t=t.child;t!==null;){var e=E0(t);if(e!==null)return e;t=t.sibling}return null}var S0=lt.unstable_scheduleCallback,ig=lt.unstable_cancelCallback,r5=lt.unstable_shouldYield,i5=lt.unstable_requestPaint,fe=lt.unstable_now,s5=lt.unstable_getCurrentPriorityLevel,Sh=lt.unstable_ImmediatePriority,I0=lt.unstable_UserBlockingPriority,_a=lt.unstable_NormalPriority,o5=lt.unstable_LowPriority,x0=lt.unstable_IdlePriority,Ya=null,Ht=null;function a5(t){if(Ht&&typeof Ht.onCommitFiberRoot=="function")try{Ht.onCommitFiberRoot(Ya,t,void 0,(t.current.flags&128)===128)}catch{}}var Lt=Math.clz32?Math.clz32:c5,l5=Math.log,u5=Math.LN2;function c5(t){return t>>>=0,t===0?32:31-(l5(t)/u5|0)|0}var na=64,ra=4194304;function ds(t){switch(t&-t){case 1:return 1;case 2:return 2;case 4:return 4;case 8:return 8;case 16:return 16;case 32:return 32;case 64:case 128:case 256:case 512:case 1024:case 2048:case 4096:case 8192:case 16384:case 32768:case 65536:case 131072:case 262144:case 524288:case 1048576:case 2097152:return t&4194240;case 4194304:case 8388608:case 16777216:case 33554432:case 67108864:return t&130023424;case 134217728:return 134217728;case 268435456:return 268435456;case 536870912:return 536870912;case 1073741824:return 1073741824;default:return t}}function Oa(t,e){var n=t.pendingLanes;if(n===0)return 0;var r=0,i=t.suspendedLanes,s=t.pingedLanes,o=n&268435455;if(o!==0){var a=o&~i;a!==0?r=ds(a):(s&=o,s!==0&&(r=ds(s)))}else o=n&~i,o!==0?r=ds(o):s!==0&&(r=ds(s));if(r===0)return 0;if(e!==0&&e!==r&&!(e&i)&&(i=r&-r,s=e&-e,i>=s||i===16&&(s&4194240)!==0))return e;if(r&4&&(r|=n&16),e=t.entangledLanes,e!==0)for(t=t.entanglements,e&=r;0<e;)n=31-Lt(e),i=1<<n,r|=t[n],e&=~i;return r}function h5(t,e){switch(t){case 1:case 2:case 4:return e+250;case 8:case 16:case 32:case 64:case 128:case 256:case 512:case 1024:case 2048:case 4096:case 8192:case 16384:case 32768:case 65536:case 131072:case 262144:case 524288:case 1048576:case 2097152:return e+5e3;case 4194304:case 8388608:case 16777216:case 33554432:case 67108864:return-1;case 134217728:case 268435456:case 536870912:case 1073741824:return-1;default:return-1}}function d5(t,e){for(var n=t.suspendedLanes,r=t.pingedLanes,i=t.expirationTimes,s=t.pendingLanes;0<s;){var o=31-Lt(s),a=1<<o,l=i[o];l===-1?(!(a&n)||a&r)&&(i[o]=h5(a,e)):l<=e&&(t.expiredLanes|=a),s&=~a}}function Bc(t){return t=t.pendingLanes&-1073741825,t!==0?t:t&1073741824?1073741824:0}function T0(){var t=na;return na<<=1,!(na&4194240)&&(na=64),t}function sc(t){for(var e=[],n=0;31>n;n++)e.push(t);return e}function qs(t,e,n){t.pendingLanes|=e,e!==536870912&&(t.suspendedLanes=0,t.pingedLanes=0),t=t.eventTimes,e=31-Lt(e),t[e]=n}function f5(t,e){var n=t.pendingLanes&~e;t.pendingLanes=e,t.suspendedLanes=0,t.pingedLanes=0,t.expiredLanes&=e,t.mutableReadLanes&=e,t.entangledLanes&=e,e=t.entanglements;var r=t.eventTimes;for(t=t.expirationTimes;0<n;){var i=31-Lt(n),s=1<<i;e[i]=0,r[i]=-1,t[i]=-1,n&=~s}}function Ih(t,e){var n=t.entangledLanes|=e;for(t=t.entanglements;n;){var r=31-Lt(n),i=1<<r;i&e|t[r]&e&&(t[r]|=e),n&=~i}}var W=0;function C0(t){return t&=-t,1<t?4<t?t&268435455?16:536870912:4:1}var k0,xh,D0,N0,P0,qc=!1,ia=[],Rn=null,zn=null,Fn=null,Cs=new Map,ks=new Map,On=[],p5="mousedown mouseup touchcancel touchend touchstart auxclick dblclick pointercancel pointerdown pointerup dragend dragstart drop compositionend compositionstart keydown keypress keyup input textInput copy cut paste click change contextmenu reset submit".split(" ");function sg(t,e){switch(t){case"focusin":case"focusout":Rn=null;break;case"dragenter":case"dragleave":zn=null;break;case"mouseover":case"mouseout":Fn=null;break;case"pointerover":case"pointerout":Cs.delete(e.pointerId);break;case"gotpointercapture":case"lostpointercapture":ks.delete(e.pointerId)}}function rs(t,e,n,r,i,s){return t===null||t.nativeEvent!==s?(t={blockedOn:e,domEventName:n,eventSystemFlags:r,nativeEvent:s,targetContainers:[i]},e!==null&&(e=Us(e),e!==null&&xh(e)),t):(t.eventSystemFlags|=r,e=t.targetContainers,i!==null&&e.indexOf(i)===-1&&e.push(i),t)}function m5(t,e,n,r,i){switch(e){case"focusin":return Rn=rs(Rn,t,e,n,r,i),!0;case"dragenter":return zn=rs(zn,t,e,n,r,i),!0;case"mouseover":return Fn=rs(Fn,t,e,n,r,i),!0;case"pointerover":var s=i.pointerId;return Cs.set(s,rs(Cs.get(s)||null,t,e,n,r,i)),!0;case"gotpointercapture":return s=i.pointerId,ks.set(s,rs(ks.get(s)||null,t,e,n,r,i)),!0}return!1}function _0(t){var e=gr(t.target);if(e!==null){var n=kr(e);if(n!==null){if(e=n.tag,e===13){if(e=v0(n),e!==null){t.blockedOn=e,P0(t.priority,function(){D0(n)});return}}else if(e===3&&n.stateNode.current.memoizedState.isDehydrated){t.blockedOn=n.tag===3?n.stateNode.containerInfo:null;return}}}t.blockedOn=null}function Aa(t){if(t.blockedOn!==null)return!1;for(var e=t.targetContainers;0<e.length;){var n=Vc(t.domEventName,t.eventSystemFlags,e[0],t.nativeEvent);if(n===null){n=t.nativeEvent;var r=new n.constructor(n.type,n);bc=r,n.target.dispatchEvent(r),bc=null}else return e=Us(n),e!==null&&xh(e),t.blockedOn=n,!1;e.shift()}return!0}function og(t,e,n){Aa(t)&&n.delete(e)}function g5(){qc=!1,Rn!==null&&Aa(Rn)&&(Rn=null),zn!==null&&Aa(zn)&&(zn=null),Fn!==null&&Aa(Fn)&&(Fn=null),Cs.forEach(og),ks.forEach(og)}function is(t,e){t.blockedOn===e&&(t.blockedOn=null,qc||(qc=!0,lt.unstable_scheduleCallback(lt.unstable_NormalPriority,g5)))}function Ds(t){function e(i){return is(i,t)}if(0<ia.length){is(ia[0],t);for(var n=1;n<ia.length;n++){var r=ia[n];r.blockedOn===t&&(r.blockedOn=null)}}for(Rn!==null&&is(Rn,t),zn!==null&&is(zn,t),Fn!==null&&is(Fn,t),Cs.forEach(e),ks.forEach(e),n=0;n<On.length;n++)r=On[n],r.blockedOn===t&&(r.blockedOn=null);for(;0<On.length&&(n=On[0],n.blockedOn===null);)_0(n),n.blockedOn===null&&On.shift()}var hi=dn.ReactCurrentBatchConfig,La=!0;function y5(t,e,n,r){var i=W,s=hi.transition;hi.transition=null;try{W=1,Th(t,e,n,r)}finally{W=i,hi.transition=s}}function A5(t,e,n,r){var i=W,s=hi.transition;hi.transition=null;try{W=4,Th(t,e,n,r)}finally{W=i,hi.transition=s}}function Th(t,e,n,r){if(La){var i=Vc(t,e,n,r);if(i===null)dc(t,e,r,Ma,n),sg(t,r);else if(m5(i,t,e,n,r))r.stopPropagation();else if(sg(t,r),e&4&&-1<p5.indexOf(t)){for(;i!==null;){var s=Us(i);if(s!==null&&k0(s),s=Vc(t,e,n,r),s===null&&dc(t,e,r,Ma,n),s===i)break;i=s}i!==null&&r.stopPropagation()}else dc(t,e,r,null,n)}}var Ma=null;function Vc(t,e,n,r){if(Ma=null,t=Eh(r),t=gr(t),t!==null)if(e=kr(t),e===null)t=null;else if(n=e.tag,n===13){if(t=v0(e),t!==null)return t;t=null}else if(n===3){if(e.stateNode.current.memoizedState.isDehydrated)return e.tag===3?e.stateNode.containerInfo:null;t=null}else e!==t&&(t=null);return Ma=t,null}function O0(t){switch(t){case"cancel":case"click":case"close":case"contextmenu":case"copy":case"cut":case"auxclick":case"dblclick":case"dragend":case"dragstart":case"drop":case"focusin":case"focusout":case"input":case"invalid":case"keydown":case"keypress":case"keyup":case"mousedown":case"mouseup":case"paste":case"pause":case"play":case"pointercancel":case"pointerdown":case"pointerup":case"ratechange":case"reset":case"resize":case"seeked":case"submit":case"touchcancel":case"touchend":case"touchstart":case"volumechange":case"change":case"selectionchange":case"textInput":case"compositionstart":case"compositionend":case"compositionupdate":case"beforeblur":case"afterblur":case"beforeinput":case"blur":case"fullscreenchange":case"focus":case"hashchange":case"popstate":case"select":case"selectstart":return 1;case"drag":case"dragenter":case"dragexit":case"dragleave":case"dragover":case"mousemove":case"mouseout":case"mouseover":case"pointermove":case"pointerout":case"pointerover":case"scroll":case"toggle":case"touchmove":case"wheel":case"mouseenter":case"mouseleave":case"pointerenter":case"pointerleave":return 4;case"message":switch(s5()){case Sh:return 1;case I0:return 4;case _a:case o5:return 16;case x0:return 536870912;default:return 16}default:return 16}}var Mn=null,Ch=null,va=null;function L0(){if(va)return va;var t,e=Ch,n=e.length,r,i="value"in Mn?Mn.value:Mn.textContent,s=i.length;for(t=0;t<n&&e[t]===i[t];t++);var o=n-t;for(r=1;r<=o&&e[n-r]===i[s-r];r++);return va=i.slice(t,1<r?1-r:void 0)}function wa(t){var e=t.keyCode;return"charCode"in t?(t=t.charCode,t===0&&e===13&&(t=13)):t=e,t===10&&(t=13),32<=t||t===13?t:0}function sa(){return!0}function ag(){return!1}function ut(t){function e(n,r,i,s,o){this._reactName=n,this._targetInst=i,this.type=r,this.nativeEvent=s,this.target=o,this.currentTarget=null;for(var a in t)t.hasOwnProperty(a)&&(n=t[a],this[a]=n?n(s):s[a]);return this.isDefaultPrevented=(s.defaultPrevented!=null?s.defaultPrevented:s.returnValue===!1)?sa:ag,this.isPropagationStopped=ag,this}return ue(e.prototype,{preventDefault:function(){this.defaultPrevented=!0;var n=this.nativeEvent;n&&(n.preventDefault?n.preventDefault():typeof n.returnValue!="unknown"&&(n.returnValue=!1),this.isDefaultPrevented=sa)},stopPropagation:function(){var n=this.nativeEvent;n&&(n.stopPropagation?n.stopPropagation():typeof n.cancelBubble!="unknown"&&(n.cancelBubble=!0),this.isPropagationStopped=sa)},persist:function(){},isPersistent:sa}),e}var Ei={eventPhase:0,bubbles:0,cancelable:0,timeStamp:function(t){return t.timeStamp||Date.now()},defaultPrevented:0,isTrusted:0},kh=ut(Ei),Vs=ue({},Ei,{view:0,detail:0}),v5=ut(Vs),oc,ac,ss,$a=ue({},Vs,{screenX:0,screenY:0,clientX:0,clientY:0,pageX:0,pageY:0,ctrlKey:0,shiftKey:0,altKey:0,metaKey:0,getModifierState:Dh,button:0,buttons:0,relatedTarget:function(t){return t.relatedTarget===void 0?t.fromElement===t.srcElement?t.toElement:t.fromElement:t.relatedTarget},movementX:function(t){return"movementX"in t?t.movementX:(t!==ss&&(ss&&t.type==="mousemove"?(oc=t.screenX-ss.screenX,ac=t.screenY-ss.screenY):ac=oc=0,ss=t),oc)},movementY:function(t){return"movementY"in t?t.movementY:ac}}),lg=ut($a),w5=ue({},$a,{dataTransfer:0}),E5=ut(w5),S5=ue({},Vs,{relatedTarget:0}),lc=ut(S5),I5=ue({},Ei,{animationName:0,elapsedTime:0,pseudoElement:0}),x5=ut(I5),T5=ue({},Ei,{clipboardData:function(t){return"clipboardData"in t?t.clipboardData:window.clipboardData}}),C5=ut(T5),k5=ue({},Ei,{data:0}),ug=ut(k5),D5={Esc:"Escape",Spacebar:" ",Left:"ArrowLeft",Up:"ArrowUp",Right:"ArrowRight",Down:"ArrowDown",Del:"Delete",Win:"OS",Menu:"ContextMenu",Apps:"ContextMenu",Scroll:"ScrollLock",MozPrintableKey:"Unidentified"},N5={8:"Backspace",9:"Tab",12:"Clear",13:"Enter",16:"Shift",17:"Control",18:"Alt",19:"Pause",20:"CapsLock",27:"Escape",32:" ",33:"PageUp",34:"PageDown",35:"End",36:"Home",37:"ArrowLeft",38:"ArrowUp",39:"ArrowRight",40:"ArrowDown",45:"Insert",46:"Delete",112:"F1",113:"F2",114:"F3",115:"F4",116:"F5",117:"F6",118:"F7",119:"F8",120:"F9",121:"F10",122:"F11",123:"F12",144:"NumLock",145:"ScrollLock",224:"Meta"},P5={Alt:"altKey",Control:"ctrlKey",Meta:"metaKey",Shift:"shiftKey"};function _5(t){var e=this.nativeEvent;return e.getModifierState?e.getModifierState(t):(t=P5[t])?!!e[t]:!1}function Dh(){return _5}var O5=ue({},Vs,{key:function(t){if(t.key){var e=D5[t.key]||t.key;if(e!=="Unidentified")return e}return t.type==="keypress"?(t=wa(t),t===13?"Enter":String.fromCharCode(t)):t.type==="keydown"||t.type==="keyup"?N5[t.keyCode]||"Unidentified":""},code:0,location:0,ctrlKey:0,shiftKey:0,altKey:0,metaKey:0,repeat:0,locale:0,getModifierState:Dh,charCode:function(t){return t.type==="keypress"?wa(t):0},keyCode:function(t){return t.type==="keydown"||t.type==="keyup"?t.keyCode:0},which:function(t){return t.type==="keypress"?wa(t):t.type==="keydown"||t.type==="keyup"?t.keyCode:0}}),L5=ut(O5),M5=ue({},$a,{pointerId:0,width:0,height:0,pressure:0,tangentialPressure:0,tiltX:0,tiltY:0,twist:0,pointerType:0,isPrimary:0}),cg=ut(M5),b5=ue({},Vs,{touches:0,targetTouches:0,changedTouches:0,altKey:0,metaKey:0,ctrlKey:0,shiftKey:0,getModifierState:Dh}),R5=ut(b5),z5=ue({},Ei,{propertyName:0,elapsedTime:0,pseudoElement:0}),F5=ut(z5),B5=ue({},$a,{deltaX:function(t){return"deltaX"in t?t.deltaX:"wheelDeltaX"in t?-t.wheelDeltaX:0},deltaY:function(t){return"deltaY"in t?t.deltaY:"wheelDeltaY"in t?-t.wheelDeltaY:"wheelDelta"in t?-t.wheelDelta:0},deltaZ:0,deltaMode:0}),q5=ut(B5),V5=[9,13,27,32],Nh=ln&&"CompositionEvent"in window,gs=null;ln&&"documentMode"in document&&(gs=document.documentMode);var U5=ln&&"TextEvent"in window&&!gs,M0=ln&&(!Nh||gs&&8<gs&&11>=gs),hg=String.fromCharCode(32),dg=!1;function b0(t,e){switch(t){case"keyup":return V5.indexOf(e.keyCode)!==-1;case"keydown":return e.keyCode!==229;case"keypress":case"mousedown":case"focusout":return!0;default:return!1}}function R0(t){return t=t.detail,typeof t=="object"&&"data"in t?t.data:null}var Yr=!1;function j5(t,e){switch(t){case"compositionend":return R0(e);case"keypress":return e.which!==32?null:(dg=!0,hg);case"textInput":return t=e.data,t===hg&&dg?null:t;default:return null}}function Q5(t,e){if(Yr)return t==="compositionend"||!Nh&&b0(t,e)?(t=L0(),va=Ch=Mn=null,Yr=!1,t):null;switch(t){case"paste":return null;case"keypress":if(!(e.ctrlKey||e.altKey||e.metaKey)||e.ctrlKey&&e.altKey){if(e.char&&1<e.char.length)return e.char;if(e.which)return String.fromCharCode(e.which)}return null;case"compositionend":return M0&&e.locale!=="ko"?null:e.data;default:return null}}var H5={color:!0,date:!0,datetime:!0,"datetime-local":!0,email:!0,month:!0,number:!0,password:!0,range:!0,search:!0,tel:!0,text:!0,time:!0,url:!0,week:!0};function fg(t){var e=t&&t.nodeName&&t.nodeName.toLowerCase();return e==="input"?!!H5[t.type]:e==="textarea"}function z0(t,e,n,r){p0(r),e=ba(e,"onChange"),0<e.length&&(n=new kh("onChange","change",null,n,r),t.push({event:n,listeners:e}))}var ys=null,Ns=null;function K5(t){W0(t,0)}function el(t){var e=ti(t);if(a0(e))return t}function X5(t,e){if(t==="change")return e}var F0=!1;ln&&(ln?(aa="oninput"in document,aa||(uc=document.createElement("div"),uc.setAttribute("oninput","return;"),aa=typeof uc.oninput=="function"),oa=aa):oa=!1,F0=oa&&(!document.documentMode||9<document.documentMode));var oa,aa,uc;function pg(){ys&&(ys.detachEvent("onpropertychange",B0),Ns=ys=null)}function B0(t){if(t.propertyName==="value"&&el(Ns)){var e=[];z0(e,Ns,t,Eh(t)),A0(K5,e)}}function W5(t,e,n){t==="focusin"?(pg(),ys=e,Ns=n,ys.attachEvent("onpropertychange",B0)):t==="focusout"&&pg()}function G5(t){if(t==="selectionchange"||t==="keyup"||t==="keydown")return el(Ns)}function J5(t,e){if(t==="click")return el(e)}function Z5(t,e){if(t==="input"||t==="change")return el(e)}function Y5(t,e){return t===e&&(t!==0||1/t===1/e)||t!==t&&e!==e}var bt=typeof Object.is=="function"?Object.is:Y5;function Ps(t,e){if(bt(t,e))return!0;if(typeof t!="object"||t===null||typeof e!="object"||e===null)return!1;var n=Object.keys(t),r=Object.keys(e);if(n.length!==r.length)return!1;for(r=0;r<n.length;r++){var i=n[r];if(!Ic.call(e,i)||!bt(t[i],e[i]))return!1}return!0}function mg(t){for(;t&&t.firstChild;)t=t.firstChild;return t}function gg(t,e){var n=mg(t);t=0;for(var r;n;){if(n.nodeType===3){if(r=t+n.textContent.length,t<=e&&r>=e)return{node:n,offset:e-t};t=r}e:{for(;n;){if(n.nextSibling){n=n.nextSibling;break e}n=n.parentNode}n=void 0}n=mg(n)}}function q0(t,e){return t&&e?t===e?!0:t&&t.nodeType===3?!1:e&&e.nodeType===3?q0(t,e.parentNode):"contains"in t?t.contains(e):t.compareDocumentPosition?!!(t.compareDocumentPosition(e)&16):!1:!1}function V0(){for(var t=window,e=Da();e instanceof t.HTMLIFrameElement;){try{var n=typeof e.contentWindow.location.href=="string"}catch{n=!1}if(n)t=e.contentWindow;else break;e=Da(t.document)}return e}function Ph(t){var e=t&&t.nodeName&&t.nodeName.toLowerCase();return e&&(e==="input"&&(t.type==="text"||t.type==="search"||t.type==="tel"||t.type==="url"||t.type==="password")||e==="textarea"||t.contentEditable==="true")}function $5(t){var e=V0(),n=t.focusedElem,r=t.selectionRange;if(e!==n&&n&&n.ownerDocument&&q0(n.ownerDocument.documentElement,n)){if(r!==null&&Ph(n)){if(e=r.start,t=r.end,t===void 0&&(t=e),"selectionStart"in n)n.selectionStart=e,n.selectionEnd=Math.min(t,n.value.length);else if(t=(e=n.ownerDocument||document)&&e.defaultView||window,t.getSelection){t=t.getSelection();var i=n.textContent.length,s=Math.min(r.start,i);r=r.end===void 0?s:Math.min(r.end,i),!t.extend&&s>r&&(i=r,r=s,s=i),i=gg(n,s);var o=gg(n,r);i&&o&&(t.rangeCount!==1||t.anchorNode!==i.node||t.anchorOffset!==i.offset||t.focusNode!==o.node||t.focusOffset!==o.offset)&&(e=e.createRange(),e.setStart(i.node,i.offset),t.removeAllRanges(),s>r?(t.addRange(e),t.extend(o.node,o.offset)):(e.setEnd(o.node,o.offset),t.addRange(e)))}}for(e=[],t=n;t=t.parentNode;)t.nodeType===1&&e.push({element:t,left:t.scrollLeft,top:t.scrollTop});for(typeof n.focus=="function"&&n.focus(),n=0;n<e.length;n++)t=e[n],t.element.scrollLeft=t.left,t.element.scrollTop=t.top}}var eE=ln&&"documentMode"in document&&11>=document.documentMode,$r=null,Uc=null,As=null,jc=!1;function yg(t,e,n){var r=n.window===n?n.document:n.nodeType===9?n:n.ownerDocument;jc||$r==null||$r!==Da(r)||(r=$r,"selectionStart"in r&&Ph(r)?r={start:r.selectionStart,end:r.selectionEnd}:(r=(r.ownerDocument&&r.ownerDocument.defaultView||window).getSelection(),r={anchorNode:r.anchorNode,anchorOffset:r.anchorOffset,focusNode:r.focusNode,focusOffset:r.focusOffset}),As&&Ps(As,r)||(As=r,r=ba(Uc,"onSelect"),0<r.length&&(e=new kh("onSelect","select",null,e,n),t.push({event:e,listeners:r}),e.target=$r)))}function la(t,e){var n={};return n[t.toLowerCase()]=e.toLowerCase(),n["Webkit"+t]="webkit"+e,n["Moz"+t]="moz"+e,n}var ei={animationend:la("Animation","AnimationEnd"),animationiteration:la("Animation","AnimationIteration"),animationstart:la("Animation","AnimationStart"),transitionend:la("Transition","TransitionEnd")},cc={},U0={};ln&&(U0=document.createElement("div").style,"AnimationEvent"in window||(delete ei.animationend.animation,delete ei.animationiteration.animation,delete ei.animationstart.animation),"TransitionEvent"in window||delete ei.transitionend.transition);function tl(t){if(cc[t])return cc[t];if(!ei[t])return t;var e=ei[t],n;for(n in e)if(e.hasOwnProperty(n)&&n in U0)return cc[t]=e[n];return t}var j0=tl("animationend"),Q0=tl("animationiteration"),H0=tl("animationstart"),K0=tl("transitionend"),X0=new Map,Ag="abort auxClick cancel canPlay canPlayThrough click close contextMenu copy cut drag dragEnd dragEnter dragExit dragLeave dragOver dragStart drop durationChange emptied encrypted ended error gotPointerCapture input invalid keyDown keyPress keyUp load loadedData loadedMetadata loadStart lostPointerCapture mouseDown mouseMove mouseOut mouseOver mouseUp paste pause play playing pointerCancel pointerDown pointerMove pointerOut pointerOver pointerUp progress rateChange reset resize seeked seeking stalled submit suspend timeUpdate touchCancel touchEnd touchStart volumeChange scroll toggle touchMove waiting wheel".split(" ");function Kn(t,e){X0.set(t,e),Cr(e,[t])}for(ua=0;ua<Ag.length;ua++)ca=Ag[ua],vg=ca.toLowerCase(),wg=ca[0].toUpperCase()+ca.slice(1),Kn(vg,"on"+wg);var ca,vg,wg,ua;Kn(j0,"onAnimationEnd");Kn(Q0,"onAnimationIteration");Kn(H0,"onAnimationStart");Kn("dblclick","onDoubleClick");Kn("focusin","onFocus");Kn("focusout","onBlur");Kn(K0,"onTransitionEnd");pi("onMouseEnter",["mouseout","mouseover"]);pi("onMouseLeave",["mouseout","mouseover"]);pi("onPointerEnter",["pointerout","pointerover"]);pi("onPointerLeave",["pointerout","pointerover"]);Cr("onChange","change click focusin focusout input keydown keyup selectionchange".split(" "));Cr("onSelect","focusout contextmenu dragend focusin keydown keyup mousedown mouseup selectionchange".split(" "));Cr("onBeforeInput",["compositionend","keypress","textInput","paste"]);Cr("onCompositionEnd","compositionend focusout keydown keypress keyup mousedown".split(" "));Cr("onCompositionStart","compositionstart focusout keydown keypress keyup mousedown".split(" "));Cr("onCompositionUpdate","compositionupdate focusout keydown keypress keyup mousedown".split(" "));var fs="abort canplay canplaythrough durationchange emptied encrypted ended error loadeddata loadedmetadata loadstart pause play playing progress ratechange resize seeked seeking stalled suspend timeupdate volumechange waiting".split(" "),tE=new Set("cancel close invalid load scroll toggle".split(" ").concat(fs));function Eg(t,e,n){var r=t.type||"unknown-event";t.currentTarget=n,t5(r,e,void 0,t),t.currentTarget=null}function W0(t,e){e=(e&4)!==0;for(var n=0;n<t.length;n++){var r=t[n],i=r.event;r=r.listeners;e:{var s=void 0;if(e)for(var o=r.length-1;0<=o;o--){var a=r[o],l=a.instance,u=a.currentTarget;if(a=a.listener,l!==s&&i.isPropagationStopped())break e;Eg(i,a,u),s=l}else for(o=0;o<r.length;o++){if(a=r[o],l=a.instance,u=a.currentTarget,a=a.listener,l!==s&&i.isPropagationStopped())break e;Eg(i,a,u),s=l}}}if(Pa)throw t=Fc,Pa=!1,Fc=null,t}function $(t,e){var n=e[Wc];n===void 0&&(n=e[Wc]=new Set);var r=t+"__bubble";n.has(r)||(G0(e,t,2,!1),n.add(r))}function hc(t,e,n){var r=0;e&&(r|=4),G0(n,t,r,e)}var ha="_reactListening"+Math.random().toString(36).slice(2);function _s(t){if(!t[ha]){t[ha]=!0,n0.forEach(function(n){n!=="selectionchange"&&(tE.has(n)||hc(n,!1,t),hc(n,!0,t))});var e=t.nodeType===9?t:t.ownerDocument;e===null||e[ha]||(e[ha]=!0,hc("selectionchange",!1,e))}}function G0(t,e,n,r){switch(O0(e)){case 1:var i=y5;break;case 4:i=A5;break;default:i=Th}n=i.bind(null,e,n,t),i=void 0,!zc||e!=="touchstart"&&e!=="touchmove"&&e!=="wheel"||(i=!0),r?i!==void 0?t.addEventListener(e,n,{capture:!0,passive:i}):t.addEventListener(e,n,!0):i!==void 0?t.addEventListener(e,n,{passive:i}):t.addEventListener(e,n,!1)}function dc(t,e,n,r,i){var s=r;if(!(e&1)&&!(e&2)&&r!==null)e:for(;;){if(r===null)return;var o=r.tag;if(o===3||o===4){var a=r.stateNode.containerInfo;if(a===i||a.nodeType===8&&a.parentNode===i)break;if(o===4)for(o=r.return;o!==null;){var l=o.tag;if((l===3||l===4)&&(l=o.stateNode.containerInfo,l===i||l.nodeType===8&&l.parentNode===i))return;o=o.return}for(;a!==null;){if(o=gr(a),o===null)return;if(l=o.tag,l===5||l===6){r=s=o;continue e}a=a.parentNode}}r=r.return}A0(function(){var u=s,c=Eh(n),h=[];e:{var p=X0.get(t);if(p!==void 0){var g=kh,y=t;switch(t){case"keypress":if(wa(n)===0)break e;case"keydown":case"keyup":g=L5;break;case"focusin":y="focus",g=lc;break;case"focusout":y="blur",g=lc;break;case"beforeblur":case"afterblur":g=lc;break;case"click":if(n.button===2)break e;case"auxclick":case"dblclick":case"mousedown":case"mousemove":case"mouseup":case"mouseout":case"mouseover":case"contextmenu":g=lg;break;case"drag":case"dragend":case"dragenter":case"dragexit":case"dragleave":case"dragover":case"dragstart":case"drop":g=E5;break;case"touchcancel":case"touchend":case"touchmove":case"touchstart":g=R5;break;case j0:case Q0:case H0:g=x5;break;case K0:g=F5;break;case"scroll":g=v5;break;case"wheel":g=q5;break;case"copy":case"cut":case"paste":g=C5;break;case"gotpointercapture":case"lostpointercapture":case"pointercancel":case"pointerdown":case"pointermove":case"pointerout":case"pointerover":case"pointerup":g=cg}var A=(e&4)!==0,P=!A&&t==="scroll",f=A?p!==null?p+"Capture":null:p;A=[];for(var d=u,m;d!==null;){m=d;var v=m.stateNode;if(m.tag===5&&v!==null&&(m=v,f!==null&&(v=Ts(d,f),v!=null&&A.push(Os(d,v,m)))),P)break;d=d.return}0<A.length&&(p=new g(p,y,null,n,c),h.push({event:p,listeners:A}))}}if(!(e&7)){e:{if(p=t==="mouseover"||t==="pointerover",g=t==="mouseout"||t==="pointerout",p&&n!==bc&&(y=n.relatedTarget||n.fromElement)&&(gr(y)||y[un]))break e;if((g||p)&&(p=c.window===c?c:(p=c.ownerDocument)?p.defaultView||p.parentWindow:window,g?(y=n.relatedTarget||n.toElement,g=u,y=y?gr(y):null,y!==null&&(P=kr(y),y!==P||y.tag!==5&&y.tag!==6)&&(y=null)):(g=null,y=u),g!==y)){if(A=lg,v="onMouseLeave",f="onMouseEnter",d="mouse",(t==="pointerout"||t==="pointerover")&&(A=cg,v="onPointerLeave",f="onPointerEnter",d="pointer"),P=g==null?p:ti(g),m=y==null?p:ti(y),p=new A(v,d+"leave",g,n,c),p.target=P,p.relatedTarget=m,v=null,gr(c)===u&&(A=new A(f,d+"enter",y,n,c),A.target=m,A.relatedTarget=P,v=A),P=v,g&&y)t:{for(A=g,f=y,d=0,m=A;m;m=Gr(m))d++;for(m=0,v=f;v;v=Gr(v))m++;for(;0<d-m;)A=Gr(A),d--;for(;0<m-d;)f=Gr(f),m--;for(;d--;){if(A===f||f!==null&&A===f.alternate)break t;A=Gr(A),f=Gr(f)}A=null}else A=null;g!==null&&Sg(h,p,g,A,!1),y!==null&&P!==null&&Sg(h,P,y,A,!0)}}e:{if(p=u?ti(u):window,g=p.nodeName&&p.nodeName.toLowerCase(),g==="select"||g==="input"&&p.type==="file")var S=X5;else if(fg(p))if(F0)S=Z5;else{S=G5;var D=W5}else(g=p.nodeName)&&g.toLowerCase()==="input"&&(p.type==="checkbox"||p.type==="radio")&&(S=J5);if(S&&(S=S(t,u))){z0(h,S,n,c);break e}D&&D(t,p,u),t==="focusout"&&(D=p._wrapperState)&&D.controlled&&p.type==="number"&&Pc(p,"number",p.value)}switch(D=u?ti(u):window,t){case"focusin":(fg(D)||D.contentEditable==="true")&&($r=D,Uc=u,As=null);break;case"focusout":As=Uc=$r=null;break;case"mousedown":jc=!0;break;case"contextmenu":case"mouseup":case"dragend":jc=!1,yg(h,n,c);break;case"selectionchange":if(eE)break;case"keydown":case"keyup":yg(h,n,c)}var T;if(Nh)e:{switch(t){case"compositionstart":var k="onCompositionStart";break e;case"compositionend":k="onCompositionEnd";break e;case"compositionupdate":k="onCompositionUpdate";break e}k=void 0}else Yr?b0(t,n)&&(k="onCompositionEnd"):t==="keydown"&&n.keyCode===229&&(k="onCompositionStart");k&&(M0&&n.locale!=="ko"&&(Yr||k!=="onCompositionStart"?k==="onCompositionEnd"&&Yr&&(T=L0()):(Mn=c,Ch="value"in Mn?Mn.value:Mn.textContent,Yr=!0)),D=ba(u,k),0<D.length&&(k=new ug(k,t,null,n,c),h.push({event:k,listeners:D}),T?k.data=T:(T=R0(n),T!==null&&(k.data=T)))),(T=U5?j5(t,n):Q5(t,n))&&(u=ba(u,"onBeforeInput"),0<u.length&&(c=new ug("onBeforeInput","beforeinput",null,n,c),h.push({event:c,listeners:u}),c.data=T))}W0(h,e)})}function Os(t,e,n){return{instance:t,listener:e,currentTarget:n}}function ba(t,e){for(var n=e+"Capture",r=[];t!==null;){var i=t,s=i.stateNode;i.tag===5&&s!==null&&(i=s,s=Ts(t,n),s!=null&&r.unshift(Os(t,s,i)),s=Ts(t,e),s!=null&&r.push(Os(t,s,i))),t=t.return}return r}function Gr(t){if(t===null)return null;do t=t.return;while(t&&t.tag!==5);return t||null}function Sg(t,e,n,r,i){for(var s=e._reactName,o=[];n!==null&&n!==r;){var a=n,l=a.alternate,u=a.stateNode;if(l!==null&&l===r)break;a.tag===5&&u!==null&&(a=u,i?(l=Ts(n,s),l!=null&&o.unshift(Os(n,l,a))):i||(l=Ts(n,s),l!=null&&o.push(Os(n,l,a)))),n=n.return}o.length!==0&&t.push({event:e,listeners:o})}var nE=/\r\n?/g,rE=/\u0000|\uFFFD/g;function Ig(t){return(typeof t=="string"?t:""+t).replace(nE,`
`).replace(rE,"")}function da(t,e,n){if(e=Ig(e),Ig(t)!==e&&n)throw Error(w(425))}function Ra(){}var Qc=null,Hc=null;function Kc(t,e){return t==="textarea"||t==="noscript"||typeof e.children=="string"||typeof e.children=="number"||typeof e.dangerouslySetInnerHTML=="object"&&e.dangerouslySetInnerHTML!==null&&e.dangerouslySetInnerHTML.__html!=null}var Xc=typeof setTimeout=="function"?setTimeout:void 0,iE=typeof clearTimeout=="function"?clearTimeout:void 0,xg=typeof Promise=="function"?Promise:void 0,sE=typeof queueMicrotask=="function"?queueMicrotask:typeof xg<"u"?function(t){return xg.resolve(null).then(t).catch(oE)}:Xc;function oE(t){setTimeout(function(){throw t})}function fc(t,e){var n=e,r=0;do{var i=n.nextSibling;if(t.removeChild(n),i&&i.nodeType===8)if(n=i.data,n==="/$"){if(r===0){t.removeChild(i),Ds(e);return}r--}else n!=="$"&&n!=="$?"&&n!=="$!"||r++;n=i}while(n);Ds(e)}function Bn(t){for(;t!=null;t=t.nextSibling){var e=t.nodeType;if(e===1||e===3)break;if(e===8){if(e=t.data,e==="$"||e==="$!"||e==="$?")break;if(e==="/$")return null}}return t}function Tg(t){t=t.previousSibling;for(var e=0;t;){if(t.nodeType===8){var n=t.data;if(n==="$"||n==="$!"||n==="$?"){if(e===0)return t;e--}else n==="/$"&&e++}t=t.previousSibling}return null}var Si=Math.random().toString(36).slice(2),Qt="__reactFiber$"+Si,Ls="__reactProps$"+Si,un="__reactContainer$"+Si,Wc="__reactEvents$"+Si,aE="__reactListeners$"+Si,lE="__reactHandles$"+Si;function gr(t){var e=t[Qt];if(e)return e;for(var n=t.parentNode;n;){if(e=n[un]||n[Qt]){if(n=e.alternate,e.child!==null||n!==null&&n.child!==null)for(t=Tg(t);t!==null;){if(n=t[Qt])return n;t=Tg(t)}return e}t=n,n=t.parentNode}return null}function Us(t){return t=t[Qt]||t[un],!t||t.tag!==5&&t.tag!==6&&t.tag!==13&&t.tag!==3?null:t}function ti(t){if(t.tag===5||t.tag===6)return t.stateNode;throw Error(w(33))}function nl(t){return t[Ls]||null}var Gc=[],ni=-1;function Xn(t){return{current:t}}function ee(t){0>ni||(t.current=Gc[ni],Gc[ni]=null,ni--)}function Y(t,e){ni++,Gc[ni]=t.current,t.current=e}var Hn={},Be=Xn(Hn),et=Xn(!1),Er=Hn;function mi(t,e){var n=t.type.contextTypes;if(!n)return Hn;var r=t.stateNode;if(r&&r.__reactInternalMemoizedUnmaskedChildContext===e)return r.__reactInternalMemoizedMaskedChildContext;var i={},s;for(s in n)i[s]=e[s];return r&&(t=t.stateNode,t.__reactInternalMemoizedUnmaskedChildContext=e,t.__reactInternalMemoizedMaskedChildContext=i),i}function tt(t){return t=t.childContextTypes,t!=null}function za(){ee(et),ee(Be)}function Cg(t,e,n){if(Be.current!==Hn)throw Error(w(168));Y(Be,e),Y(et,n)}function J0(t,e,n){var r=t.stateNode;if(e=e.childContextTypes,typeof r.getChildContext!="function")return n;r=r.getChildContext();for(var i in r)if(!(i in e))throw Error(w(108,W2(t)||"Unknown",i));return ue({},n,r)}function Fa(t){return t=(t=t.stateNode)&&t.__reactInternalMemoizedMergedChildContext||Hn,Er=Be.current,Y(Be,t),Y(et,et.current),!0}function kg(t,e,n){var r=t.stateNode;if(!r)throw Error(w(169));n?(t=J0(t,e,Er),r.__reactInternalMemoizedMergedChildContext=t,ee(et),ee(Be),Y(Be,t)):ee(et),Y(et,n)}var rn=null,rl=!1,pc=!1;function Z0(t){rn===null?rn=[t]:rn.push(t)}function uE(t){rl=!0,Z0(t)}function Wn(){if(!pc&&rn!==null){pc=!0;var t=0,e=W;try{var n=rn;for(W=1;t<n.length;t++){var r=n[t];do r=r(!0);while(r!==null)}rn=null,rl=!1}catch(i){throw rn!==null&&(rn=rn.slice(t+1)),S0(Sh,Wn),i}finally{W=e,pc=!1}}return null}var ri=[],ii=0,Ba=null,qa=0,gt=[],yt=0,Sr=null,sn=1,on="";function pr(t,e){ri[ii++]=qa,ri[ii++]=Ba,Ba=t,qa=e}function Y0(t,e,n){gt[yt++]=sn,gt[yt++]=on,gt[yt++]=Sr,Sr=t;var r=sn;t=on;var i=32-Lt(r)-1;r&=~(1<<i),n+=1;var s=32-Lt(e)+i;if(30<s){var o=i-i%5;s=(r&(1<<o)-1).toString(32),r>>=o,i-=o,sn=1<<32-Lt(e)+i|n<<i|r,on=s+t}else sn=1<<s|n<<i|r,on=t}function _h(t){t.return!==null&&(pr(t,1),Y0(t,1,0))}function Oh(t){for(;t===Ba;)Ba=ri[--ii],ri[ii]=null,qa=ri[--ii],ri[ii]=null;for(;t===Sr;)Sr=gt[--yt],gt[yt]=null,on=gt[--yt],gt[yt]=null,sn=gt[--yt],gt[yt]=null}var at=null,ot=null,ne=!1,Ot=null;function $0(t,e){var n=At(5,null,null,0);n.elementType="DELETED",n.stateNode=e,n.return=t,e=t.deletions,e===null?(t.deletions=[n],t.flags|=16):e.push(n)}function Dg(t,e){switch(t.tag){case 5:var n=t.type;return e=e.nodeType!==1||n.toLowerCase()!==e.nodeName.toLowerCase()?null:e,e!==null?(t.stateNode=e,at=t,ot=Bn(e.firstChild),!0):!1;case 6:return e=t.pendingProps===""||e.nodeType!==3?null:e,e!==null?(t.stateNode=e,at=t,ot=null,!0):!1;case 13:return e=e.nodeType!==8?null:e,e!==null?(n=Sr!==null?{id:sn,overflow:on}:null,t.memoizedState={dehydrated:e,treeContext:n,retryLane:1073741824},n=At(18,null,null,0),n.stateNode=e,n.return=t,t.child=n,at=t,ot=null,!0):!1;default:return!1}}function Jc(t){return(t.mode&1)!==0&&(t.flags&128)===0}function Zc(t){if(ne){var e=ot;if(e){var n=e;if(!Dg(t,e)){if(Jc(t))throw Error(w(418));e=Bn(n.nextSibling);var r=at;e&&Dg(t,e)?$0(r,n):(t.flags=t.flags&-4097|2,ne=!1,at=t)}}else{if(Jc(t))throw Error(w(418));t.flags=t.flags&-4097|2,ne=!1,at=t}}}function Ng(t){for(t=t.return;t!==null&&t.tag!==5&&t.tag!==3&&t.tag!==13;)t=t.return;at=t}function fa(t){if(t!==at)return!1;if(!ne)return Ng(t),ne=!0,!1;var e;if((e=t.tag!==3)&&!(e=t.tag!==5)&&(e=t.type,e=e!=="head"&&e!=="body"&&!Kc(t.type,t.memoizedProps)),e&&(e=ot)){if(Jc(t))throw ey(),Error(w(418));for(;e;)$0(t,e),e=Bn(e.nextSibling)}if(Ng(t),t.tag===13){if(t=t.memoizedState,t=t!==null?t.dehydrated:null,!t)throw Error(w(317));e:{for(t=t.nextSibling,e=0;t;){if(t.nodeType===8){var n=t.data;if(n==="/$"){if(e===0){ot=Bn(t.nextSibling);break e}e--}else n!=="$"&&n!=="$!"&&n!=="$?"||e++}t=t.nextSibling}ot=null}}else ot=at?Bn(t.stateNode.nextSibling):null;return!0}function ey(){for(var t=ot;t;)t=Bn(t.nextSibling)}function gi(){ot=at=null,ne=!1}function Lh(t){Ot===null?Ot=[t]:Ot.push(t)}var cE=dn.ReactCurrentBatchConfig;function Pt(t,e){if(t&&t.defaultProps){e=ue({},e),t=t.defaultProps;for(var n in t)e[n]===void 0&&(e[n]=t[n]);return e}return e}var Va=Xn(null),Ua=null,si=null,Mh=null;function bh(){Mh=si=Ua=null}function Rh(t){var e=Va.current;ee(Va),t._currentValue=e}function Yc(t,e,n){for(;t!==null;){var r=t.alternate;if((t.childLanes&e)!==e?(t.childLanes|=e,r!==null&&(r.childLanes|=e)):r!==null&&(r.childLanes&e)!==e&&(r.childLanes|=e),t===n)break;t=t.return}}function di(t,e){Ua=t,Mh=si=null,t=t.dependencies,t!==null&&t.firstContext!==null&&(t.lanes&e&&($e=!0),t.firstContext=null)}function wt(t){var e=t._currentValue;if(Mh!==t)if(t={context:t,memoizedValue:e,next:null},si===null){if(Ua===null)throw Error(w(308));si=t,Ua.dependencies={lanes:0,firstContext:t}}else si=si.next=t;return e}var yr=null;function zh(t){yr===null?yr=[t]:yr.push(t)}function ty(t,e,n,r){var i=e.interleaved;return i===null?(n.next=n,zh(e)):(n.next=i.next,i.next=n),e.interleaved=n,cn(t,r)}function cn(t,e){t.lanes|=e;var n=t.alternate;for(n!==null&&(n.lanes|=e),n=t,t=t.return;t!==null;)t.childLanes|=e,n=t.alternate,n!==null&&(n.childLanes|=e),n=t,t=t.return;return n.tag===3?n.stateNode:null}var _n=!1;function Fh(t){t.updateQueue={baseState:t.memoizedState,firstBaseUpdate:null,lastBaseUpdate:null,shared:{pending:null,interleaved:null,lanes:0},effects:null}}function ny(t,e){t=t.updateQueue,e.updateQueue===t&&(e.updateQueue={baseState:t.baseState,firstBaseUpdate:t.firstBaseUpdate,lastBaseUpdate:t.lastBaseUpdate,shared:t.shared,effects:t.effects})}function an(t,e){return{eventTime:t,lane:e,tag:0,payload:null,callback:null,next:null}}function qn(t,e,n){var r=t.updateQueue;if(r===null)return null;if(r=r.shared,U&2){var i=r.pending;return i===null?e.next=e:(e.next=i.next,i.next=e),r.pending=e,cn(t,n)}return i=r.interleaved,i===null?(e.next=e,zh(r)):(e.next=i.next,i.next=e),r.interleaved=e,cn(t,n)}function Ea(t,e,n){if(e=e.updateQueue,e!==null&&(e=e.shared,(n&4194240)!==0)){var r=e.lanes;r&=t.pendingLanes,n|=r,e.lanes=n,Ih(t,n)}}function Pg(t,e){var n=t.updateQueue,r=t.alternate;if(r!==null&&(r=r.updateQueue,n===r)){var i=null,s=null;if(n=n.firstBaseUpdate,n!==null){do{var o={eventTime:n.eventTime,lane:n.lane,tag:n.tag,payload:n.payload,callback:n.callback,next:null};s===null?i=s=o:s=s.next=o,n=n.next}while(n!==null);s===null?i=s=e:s=s.next=e}else i=s=e;n={baseState:r.baseState,firstBaseUpdate:i,lastBaseUpdate:s,shared:r.shared,effects:r.effects},t.updateQueue=n;return}t=n.lastBaseUpdate,t===null?n.firstBaseUpdate=e:t.next=e,n.lastBaseUpdate=e}function ja(t,e,n,r){var i=t.updateQueue;_n=!1;var s=i.firstBaseUpdate,o=i.lastBaseUpdate,a=i.shared.pending;if(a!==null){i.shared.pending=null;var l=a,u=l.next;l.next=null,o===null?s=u:o.next=u,o=l;var c=t.alternate;c!==null&&(c=c.updateQueue,a=c.lastBaseUpdate,a!==o&&(a===null?c.firstBaseUpdate=u:a.next=u,c.lastBaseUpdate=l))}if(s!==null){var h=i.baseState;o=0,c=u=l=null,a=s;do{var p=a.lane,g=a.eventTime;if((r&p)===p){c!==null&&(c=c.next={eventTime:g,lane:0,tag:a.tag,payload:a.payload,callback:a.callback,next:null});e:{var y=t,A=a;switch(p=e,g=n,A.tag){case 1:if(y=A.payload,typeof y=="function"){h=y.call(g,h,p);break e}h=y;break e;case 3:y.flags=y.flags&-65537|128;case 0:if(y=A.payload,p=typeof y=="function"?y.call(g,h,p):y,p==null)break e;h=ue({},h,p);break e;case 2:_n=!0}}a.callback!==null&&a.lane!==0&&(t.flags|=64,p=i.effects,p===null?i.effects=[a]:p.push(a))}else g={eventTime:g,lane:p,tag:a.tag,payload:a.payload,callback:a.callback,next:null},c===null?(u=c=g,l=h):c=c.next=g,o|=p;if(a=a.next,a===null){if(a=i.shared.pending,a===null)break;p=a,a=p.next,p.next=null,i.lastBaseUpdate=p,i.shared.pending=null}}while(1);if(c===null&&(l=h),i.baseState=l,i.firstBaseUpdate=u,i.lastBaseUpdate=c,e=i.shared.interleaved,e!==null){i=e;do o|=i.lane,i=i.next;while(i!==e)}else s===null&&(i.shared.lanes=0);xr|=o,t.lanes=o,t.memoizedState=h}}function _g(t,e,n){if(t=e.effects,e.effects=null,t!==null)for(e=0;e<t.length;e++){var r=t[e],i=r.callback;if(i!==null){if(r.callback=null,r=n,typeof i!="function")throw Error(w(191,i));i.call(r)}}}var ry=new t0.Component().refs;function $c(t,e,n,r){e=t.memoizedState,n=n(r,e),n=n==null?e:ue({},e,n),t.memoizedState=n,t.lanes===0&&(t.updateQueue.baseState=n)}var il={isMounted:function(t){return(t=t._reactInternals)?kr(t)===t:!1},enqueueSetState:function(t,e,n){t=t._reactInternals;var r=Ge(),i=Un(t),s=an(r,i);s.payload=e,n!=null&&(s.callback=n),e=qn(t,s,i),e!==null&&(Mt(e,t,i,r),Ea(e,t,i))},enqueueReplaceState:function(t,e,n){t=t._reactInternals;var r=Ge(),i=Un(t),s=an(r,i);s.tag=1,s.payload=e,n!=null&&(s.callback=n),e=qn(t,s,i),e!==null&&(Mt(e,t,i,r),Ea(e,t,i))},enqueueForceUpdate:function(t,e){t=t._reactInternals;var n=Ge(),r=Un(t),i=an(n,r);i.tag=2,e!=null&&(i.callback=e),e=qn(t,i,r),e!==null&&(Mt(e,t,r,n),Ea(e,t,r))}};function Og(t,e,n,r,i,s,o){return t=t.stateNode,typeof t.shouldComponentUpdate=="function"?t.shouldComponentUpdate(r,s,o):e.prototype&&e.prototype.isPureReactComponent?!Ps(n,r)||!Ps(i,s):!0}function iy(t,e,n){var r=!1,i=Hn,s=e.contextType;return typeof s=="object"&&s!==null?s=wt(s):(i=tt(e)?Er:Be.current,r=e.contextTypes,s=(r=r!=null)?mi(t,i):Hn),e=new e(n,s),t.memoizedState=e.state!==null&&e.state!==void 0?e.state:null,e.updater=il,t.stateNode=e,e._reactInternals=t,r&&(t=t.stateNode,t.__reactInternalMemoizedUnmaskedChildContext=i,t.__reactInternalMemoizedMaskedChildContext=s),e}function Lg(t,e,n,r){t=e.state,typeof e.componentWillReceiveProps=="function"&&e.componentWillReceiveProps(n,r),typeof e.UNSAFE_componentWillReceiveProps=="function"&&e.UNSAFE_componentWillReceiveProps(n,r),e.state!==t&&il.enqueueReplaceState(e,e.state,null)}function eh(t,e,n,r){var i=t.stateNode;i.props=n,i.state=t.memoizedState,i.refs=ry,Fh(t);var s=e.contextType;typeof s=="object"&&s!==null?i.context=wt(s):(s=tt(e)?Er:Be.current,i.context=mi(t,s)),i.state=t.memoizedState,s=e.getDerivedStateFromProps,typeof s=="function"&&($c(t,e,s,n),i.state=t.memoizedState),typeof e.getDerivedStateFromProps=="function"||typeof i.getSnapshotBeforeUpdate=="function"||typeof i.UNSAFE_componentWillMount!="function"&&typeof i.componentWillMount!="function"||(e=i.state,typeof i.componentWillMount=="function"&&i.componentWillMount(),typeof i.UNSAFE_componentWillMount=="function"&&i.UNSAFE_componentWillMount(),e!==i.state&&il.enqueueReplaceState(i,i.state,null),ja(t,n,i,r),i.state=t.memoizedState),typeof i.componentDidMount=="function"&&(t.flags|=4194308)}function os(t,e,n){if(t=n.ref,t!==null&&typeof t!="function"&&typeof t!="object"){if(n._owner){if(n=n._owner,n){if(n.tag!==1)throw Error(w(309));var r=n.stateNode}if(!r)throw Error(w(147,t));var i=r,s=""+t;return e!==null&&e.ref!==null&&typeof e.ref=="function"&&e.ref._stringRef===s?e.ref:(e=function(o){var a=i.refs;a===ry&&(a=i.refs={}),o===null?delete a[s]:a[s]=o},e._stringRef=s,e)}if(typeof t!="string")throw Error(w(284));if(!n._owner)throw Error(w(290,t))}return t}function pa(t,e){throw t=Object.prototype.toString.call(e),Error(w(31,t==="[object Object]"?"object with keys {"+Object.keys(e).join(", ")+"}":t))}function Mg(t){var e=t._init;return e(t._payload)}function sy(t){function e(f,d){if(t){var m=f.deletions;m===null?(f.deletions=[d],f.flags|=16):m.push(d)}}function n(f,d){if(!t)return null;for(;d!==null;)e(f,d),d=d.sibling;return null}function r(f,d){for(f=new Map;d!==null;)d.key!==null?f.set(d.key,d):f.set(d.index,d),d=d.sibling;return f}function i(f,d){return f=jn(f,d),f.index=0,f.sibling=null,f}function s(f,d,m){return f.index=m,t?(m=f.alternate,m!==null?(m=m.index,m<d?(f.flags|=2,d):m):(f.flags|=2,d)):(f.flags|=1048576,d)}function o(f){return t&&f.alternate===null&&(f.flags|=2),f}function a(f,d,m,v){return d===null||d.tag!==6?(d=Ec(m,f.mode,v),d.return=f,d):(d=i(d,m),d.return=f,d)}function l(f,d,m,v){var S=m.type;return S===Zr?c(f,d,m.props.children,v,m.key):d!==null&&(d.elementType===S||typeof S=="object"&&S!==null&&S.$$typeof===Pn&&Mg(S)===d.type)?(v=i(d,m.props),v.ref=os(f,d,m),v.return=f,v):(v=ka(m.type,m.key,m.props,null,f.mode,v),v.ref=os(f,d,m),v.return=f,v)}function u(f,d,m,v){return d===null||d.tag!==4||d.stateNode.containerInfo!==m.containerInfo||d.stateNode.implementation!==m.implementation?(d=Sc(m,f.mode,v),d.return=f,d):(d=i(d,m.children||[]),d.return=f,d)}function c(f,d,m,v,S){return d===null||d.tag!==7?(d=wr(m,f.mode,v,S),d.return=f,d):(d=i(d,m),d.return=f,d)}function h(f,d,m){if(typeof d=="string"&&d!==""||typeof d=="number")return d=Ec(""+d,f.mode,m),d.return=f,d;if(typeof d=="object"&&d!==null){switch(d.$$typeof){case $o:return m=ka(d.type,d.key,d.props,null,f.mode,m),m.ref=os(f,null,d),m.return=f,m;case Jr:return d=Sc(d,f.mode,m),d.return=f,d;case Pn:var v=d._init;return h(f,v(d._payload),m)}if(hs(d)||ns(d))return d=wr(d,f.mode,m,null),d.return=f,d;pa(f,d)}return null}function p(f,d,m,v){var S=d!==null?d.key:null;if(typeof m=="string"&&m!==""||typeof m=="number")return S!==null?null:a(f,d,""+m,v);if(typeof m=="object"&&m!==null){switch(m.$$typeof){case $o:return m.key===S?l(f,d,m,v):null;case Jr:return m.key===S?u(f,d,m,v):null;case Pn:return S=m._init,p(f,d,S(m._payload),v)}if(hs(m)||ns(m))return S!==null?null:c(f,d,m,v,null);pa(f,m)}return null}function g(f,d,m,v,S){if(typeof v=="string"&&v!==""||typeof v=="number")return f=f.get(m)||null,a(d,f,""+v,S);if(typeof v=="object"&&v!==null){switch(v.$$typeof){case $o:return f=f.get(v.key===null?m:v.key)||null,l(d,f,v,S);case Jr:return f=f.get(v.key===null?m:v.key)||null,u(d,f,v,S);case Pn:var D=v._init;return g(f,d,m,D(v._payload),S)}if(hs(v)||ns(v))return f=f.get(m)||null,c(d,f,v,S,null);pa(d,v)}return null}function y(f,d,m,v){for(var S=null,D=null,T=d,k=d=0,K=null;T!==null&&k<m.length;k++){T.index>k?(K=T,T=null):K=T.sibling;var q=p(f,T,m[k],v);if(q===null){T===null&&(T=K);break}t&&T&&q.alternate===null&&e(f,T),d=s(q,d,k),D===null?S=q:D.sibling=q,D=q,T=K}if(k===m.length)return n(f,T),ne&&pr(f,k),S;if(T===null){for(;k<m.length;k++)T=h(f,m[k],v),T!==null&&(d=s(T,d,k),D===null?S=T:D.sibling=T,D=T);return ne&&pr(f,k),S}for(T=r(f,T);k<m.length;k++)K=g(T,f,k,m[k],v),K!==null&&(t&&K.alternate!==null&&T.delete(K.key===null?k:K.key),d=s(K,d,k),D===null?S=K:D.sibling=K,D=K);return t&&T.forEach(function(ft){return e(f,ft)}),ne&&pr(f,k),S}function A(f,d,m,v){var S=ns(m);if(typeof S!="function")throw Error(w(150));if(m=S.call(m),m==null)throw Error(w(151));for(var D=S=null,T=d,k=d=0,K=null,q=m.next();T!==null&&!q.done;k++,q=m.next()){T.index>k?(K=T,T=null):K=T.sibling;var ft=p(f,T,q.value,v);if(ft===null){T===null&&(T=K);break}t&&T&&ft.alternate===null&&e(f,T),d=s(ft,d,k),D===null?S=ft:D.sibling=ft,D=ft,T=K}if(q.done)return n(f,T),ne&&pr(f,k),S;if(T===null){for(;!q.done;k++,q=m.next())q=h(f,q.value,v),q!==null&&(d=s(q,d,k),D===null?S=q:D.sibling=q,D=q);return ne&&pr(f,k),S}for(T=r(f,T);!q.done;k++,q=m.next())q=g(T,f,k,q.value,v),q!==null&&(t&&q.alternate!==null&&T.delete(q.key===null?k:q.key),d=s(q,d,k),D===null?S=q:D.sibling=q,D=q);return t&&T.forEach(function(kn){return e(f,kn)}),ne&&pr(f,k),S}function P(f,d,m,v){if(typeof m=="object"&&m!==null&&m.type===Zr&&m.key===null&&(m=m.props.children),typeof m=="object"&&m!==null){switch(m.$$typeof){case $o:e:{for(var S=m.key,D=d;D!==null;){if(D.key===S){if(S=m.type,S===Zr){if(D.tag===7){n(f,D.sibling),d=i(D,m.props.children),d.return=f,f=d;break e}}else if(D.elementType===S||typeof S=="object"&&S!==null&&S.$$typeof===Pn&&Mg(S)===D.type){n(f,D.sibling),d=i(D,m.props),d.ref=os(f,D,m),d.return=f,f=d;break e}n(f,D);break}else e(f,D);D=D.sibling}m.type===Zr?(d=wr(m.props.children,f.mode,v,m.key),d.return=f,f=d):(v=ka(m.type,m.key,m.props,null,f.mode,v),v.ref=os(f,d,m),v.return=f,f=v)}return o(f);case Jr:e:{for(D=m.key;d!==null;){if(d.key===D)if(d.tag===4&&d.stateNode.containerInfo===m.containerInfo&&d.stateNode.implementation===m.implementation){n(f,d.sibling),d=i(d,m.children||[]),d.return=f,f=d;break e}else{n(f,d);break}else e(f,d);d=d.sibling}d=Sc(m,f.mode,v),d.return=f,f=d}return o(f);case Pn:return D=m._init,P(f,d,D(m._payload),v)}if(hs(m))return y(f,d,m,v);if(ns(m))return A(f,d,m,v);pa(f,m)}return typeof m=="string"&&m!==""||typeof m=="number"?(m=""+m,d!==null&&d.tag===6?(n(f,d.sibling),d=i(d,m),d.return=f,f=d):(n(f,d),d=Ec(m,f.mode,v),d.return=f,f=d),o(f)):n(f,d)}return P}var yi=sy(!0),oy=sy(!1),js={},Kt=Xn(js),Ms=Xn(js),bs=Xn(js);function Ar(t){if(t===js)throw Error(w(174));return t}function Bh(t,e){switch(Y(bs,e),Y(Ms,t),Y(Kt,js),t=e.nodeType,t){case 9:case 11:e=(e=e.documentElement)?e.namespaceURI:Oc(null,"");break;default:t=t===8?e.parentNode:e,e=t.namespaceURI||null,t=t.tagName,e=Oc(e,t)}ee(Kt),Y(Kt,e)}function Ai(){ee(Kt),ee(Ms),ee(bs)}function ay(t){Ar(bs.current);var e=Ar(Kt.current),n=Oc(e,t.type);e!==n&&(Y(Ms,t),Y(Kt,n))}function qh(t){Ms.current===t&&(ee(Kt),ee(Ms))}var ae=Xn(0);function Qa(t){for(var e=t;e!==null;){if(e.tag===13){var n=e.memoizedState;if(n!==null&&(n=n.dehydrated,n===null||n.data==="$?"||n.data==="$!"))return e}else if(e.tag===19&&e.memoizedProps.revealOrder!==void 0){if(e.flags&128)return e}else if(e.child!==null){e.child.return=e,e=e.child;continue}if(e===t)break;for(;e.sibling===null;){if(e.return===null||e.return===t)return null;e=e.return}e.sibling.return=e.return,e=e.sibling}return null}var mc=[];function Vh(){for(var t=0;t<mc.length;t++)mc[t]._workInProgressVersionPrimary=null;mc.length=0}var Sa=dn.ReactCurrentDispatcher,gc=dn.ReactCurrentBatchConfig,Ir=0,le=null,Ae=null,Se=null,Ha=!1,vs=!1,Rs=0,hE=0;function Re(){throw Error(w(321))}function Uh(t,e){if(e===null)return!1;for(var n=0;n<e.length&&n<t.length;n++)if(!bt(t[n],e[n]))return!1;return!0}function jh(t,e,n,r,i,s){if(Ir=s,le=e,e.memoizedState=null,e.updateQueue=null,e.lanes=0,Sa.current=t===null||t.memoizedState===null?mE:gE,t=n(r,i),vs){s=0;do{if(vs=!1,Rs=0,25<=s)throw Error(w(301));s+=1,Se=Ae=null,e.updateQueue=null,Sa.current=yE,t=n(r,i)}while(vs)}if(Sa.current=Ka,e=Ae!==null&&Ae.next!==null,Ir=0,Se=Ae=le=null,Ha=!1,e)throw Error(w(300));return t}function Qh(){var t=Rs!==0;return Rs=0,t}function jt(){var t={memoizedState:null,baseState:null,baseQueue:null,queue:null,next:null};return Se===null?le.memoizedState=Se=t:Se=Se.next=t,Se}function Et(){if(Ae===null){var t=le.alternate;t=t!==null?t.memoizedState:null}else t=Ae.next;var e=Se===null?le.memoizedState:Se.next;if(e!==null)Se=e,Ae=t;else{if(t===null)throw Error(w(310));Ae=t,t={memoizedState:Ae.memoizedState,baseState:Ae.baseState,baseQueue:Ae.baseQueue,queue:Ae.queue,next:null},Se===null?le.memoizedState=Se=t:Se=Se.next=t}return Se}function zs(t,e){return typeof e=="function"?e(t):e}function yc(t){var e=Et(),n=e.queue;if(n===null)throw Error(w(311));n.lastRenderedReducer=t;var r=Ae,i=r.baseQueue,s=n.pending;if(s!==null){if(i!==null){var o=i.next;i.next=s.next,s.next=o}r.baseQueue=i=s,n.pending=null}if(i!==null){s=i.next,r=r.baseState;var a=o=null,l=null,u=s;do{var c=u.lane;if((Ir&c)===c)l!==null&&(l=l.next={lane:0,action:u.action,hasEagerState:u.hasEagerState,eagerState:u.eagerState,next:null}),r=u.hasEagerState?u.eagerState:t(r,u.action);else{var h={lane:c,action:u.action,hasEagerState:u.hasEagerState,eagerState:u.eagerState,next:null};l===null?(a=l=h,o=r):l=l.next=h,le.lanes|=c,xr|=c}u=u.next}while(u!==null&&u!==s);l===null?o=r:l.next=a,bt(r,e.memoizedState)||($e=!0),e.memoizedState=r,e.baseState=o,e.baseQueue=l,n.lastRenderedState=r}if(t=n.interleaved,t!==null){i=t;do s=i.lane,le.lanes|=s,xr|=s,i=i.next;while(i!==t)}else i===null&&(n.lanes=0);return[e.memoizedState,n.dispatch]}function Ac(t){var e=Et(),n=e.queue;if(n===null)throw Error(w(311));n.lastRenderedReducer=t;var r=n.dispatch,i=n.pending,s=e.memoizedState;if(i!==null){n.pending=null;var o=i=i.next;do s=t(s,o.action),o=o.next;while(o!==i);bt(s,e.memoizedState)||($e=!0),e.memoizedState=s,e.baseQueue===null&&(e.baseState=s),n.lastRenderedState=s}return[s,r]}function ly(){}function uy(t,e){var n=le,r=Et(),i=e(),s=!bt(r.memoizedState,i);if(s&&(r.memoizedState=i,$e=!0),r=r.queue,Hh(dy.bind(null,n,r,t),[t]),r.getSnapshot!==e||s||Se!==null&&Se.memoizedState.tag&1){if(n.flags|=2048,Fs(9,hy.bind(null,n,r,i,e),void 0,null),Ie===null)throw Error(w(349));Ir&30||cy(n,e,i)}return i}function cy(t,e,n){t.flags|=16384,t={getSnapshot:e,value:n},e=le.updateQueue,e===null?(e={lastEffect:null,stores:null},le.updateQueue=e,e.stores=[t]):(n=e.stores,n===null?e.stores=[t]:n.push(t))}function hy(t,e,n,r){e.value=n,e.getSnapshot=r,fy(e)&&py(t)}function dy(t,e,n){return n(function(){fy(e)&&py(t)})}function fy(t){var e=t.getSnapshot;t=t.value;try{var n=e();return!bt(t,n)}catch{return!0}}function py(t){var e=cn(t,1);e!==null&&Mt(e,t,1,-1)}function bg(t){var e=jt();return typeof t=="function"&&(t=t()),e.memoizedState=e.baseState=t,t={pending:null,interleaved:null,lanes:0,dispatch:null,lastRenderedReducer:zs,lastRenderedState:t},e.queue=t,t=t.dispatch=pE.bind(null,le,t),[e.memoizedState,t]}function Fs(t,e,n,r){return t={tag:t,create:e,destroy:n,deps:r,next:null},e=le.updateQueue,e===null?(e={lastEffect:null,stores:null},le.updateQueue=e,e.lastEffect=t.next=t):(n=e.lastEffect,n===null?e.lastEffect=t.next=t:(r=n.next,n.next=t,t.next=r,e.lastEffect=t)),t}function my(){return Et().memoizedState}function Ia(t,e,n,r){var i=jt();le.flags|=t,i.memoizedState=Fs(1|e,n,void 0,r===void 0?null:r)}function sl(t,e,n,r){var i=Et();r=r===void 0?null:r;var s=void 0;if(Ae!==null){var o=Ae.memoizedState;if(s=o.destroy,r!==null&&Uh(r,o.deps)){i.memoizedState=Fs(e,n,s,r);return}}le.flags|=t,i.memoizedState=Fs(1|e,n,s,r)}function Rg(t,e){return Ia(8390656,8,t,e)}function Hh(t,e){return sl(2048,8,t,e)}function gy(t,e){return sl(4,2,t,e)}function yy(t,e){return sl(4,4,t,e)}function Ay(t,e){if(typeof e=="function")return t=t(),e(t),function(){e(null)};if(e!=null)return t=t(),e.current=t,function(){e.current=null}}function vy(t,e,n){return n=n!=null?n.concat([t]):null,sl(4,4,Ay.bind(null,e,t),n)}function Kh(){}function wy(t,e){var n=Et();e=e===void 0?null:e;var r=n.memoizedState;return r!==null&&e!==null&&Uh(e,r[1])?r[0]:(n.memoizedState=[t,e],t)}function Ey(t,e){var n=Et();e=e===void 0?null:e;var r=n.memoizedState;return r!==null&&e!==null&&Uh(e,r[1])?r[0]:(t=t(),n.memoizedState=[t,e],t)}function Sy(t,e,n){return Ir&21?(bt(n,e)||(n=T0(),le.lanes|=n,xr|=n,t.baseState=!0),e):(t.baseState&&(t.baseState=!1,$e=!0),t.memoizedState=n)}function dE(t,e){var n=W;W=n!==0&&4>n?n:4,t(!0);var r=gc.transition;gc.transition={};try{t(!1),e()}finally{W=n,gc.transition=r}}function Iy(){return Et().memoizedState}function fE(t,e,n){var r=Un(t);if(n={lane:r,action:n,hasEagerState:!1,eagerState:null,next:null},xy(t))Ty(e,n);else if(n=ty(t,e,n,r),n!==null){var i=Ge();Mt(n,t,r,i),Cy(n,e,r)}}function pE(t,e,n){var r=Un(t),i={lane:r,action:n,hasEagerState:!1,eagerState:null,next:null};if(xy(t))Ty(e,i);else{var s=t.alternate;if(t.lanes===0&&(s===null||s.lanes===0)&&(s=e.lastRenderedReducer,s!==null))try{var o=e.lastRenderedState,a=s(o,n);if(i.hasEagerState=!0,i.eagerState=a,bt(a,o)){var l=e.interleaved;l===null?(i.next=i,zh(e)):(i.next=l.next,l.next=i),e.interleaved=i;return}}catch{}finally{}n=ty(t,e,i,r),n!==null&&(i=Ge(),Mt(n,t,r,i),Cy(n,e,r))}}function xy(t){var e=t.alternate;return t===le||e!==null&&e===le}function Ty(t,e){vs=Ha=!0;var n=t.pending;n===null?e.next=e:(e.next=n.next,n.next=e),t.pending=e}function Cy(t,e,n){if(n&4194240){var r=e.lanes;r&=t.pendingLanes,n|=r,e.lanes=n,Ih(t,n)}}var Ka={readContext:wt,useCallback:Re,useContext:Re,useEffect:Re,useImperativeHandle:Re,useInsertionEffect:Re,useLayoutEffect:Re,useMemo:Re,useReducer:Re,useRef:Re,useState:Re,useDebugValue:Re,useDeferredValue:Re,useTransition:Re,useMutableSource:Re,useSyncExternalStore:Re,useId:Re,unstable_isNewReconciler:!1},mE={readContext:wt,useCallback:function(t,e){return jt().memoizedState=[t,e===void 0?null:e],t},useContext:wt,useEffect:Rg,useImperativeHandle:function(t,e,n){return n=n!=null?n.concat([t]):null,Ia(4194308,4,Ay.bind(null,e,t),n)},useLayoutEffect:function(t,e){return Ia(4194308,4,t,e)},useInsertionEffect:function(t,e){return Ia(4,2,t,e)},useMemo:function(t,e){var n=jt();return e=e===void 0?null:e,t=t(),n.memoizedState=[t,e],t},useReducer:function(t,e,n){var r=jt();return e=n!==void 0?n(e):e,r.memoizedState=r.baseState=e,t={pending:null,interleaved:null,lanes:0,dispatch:null,lastRenderedReducer:t,lastRenderedState:e},r.queue=t,t=t.dispatch=fE.bind(null,le,t),[r.memoizedState,t]},useRef:function(t){var e=jt();return t={current:t},e.memoizedState=t},useState:bg,useDebugValue:Kh,useDeferredValue:function(t){return jt().memoizedState=t},useTransition:function(){var t=bg(!1),e=t[0];return t=dE.bind(null,t[1]),jt().memoizedState=t,[e,t]},useMutableSource:function(){},useSyncExternalStore:function(t,e,n){var r=le,i=jt();if(ne){if(n===void 0)throw Error(w(407));n=n()}else{if(n=e(),Ie===null)throw Error(w(349));Ir&30||cy(r,e,n)}i.memoizedState=n;var s={value:n,getSnapshot:e};return i.queue=s,Rg(dy.bind(null,r,s,t),[t]),r.flags|=2048,Fs(9,hy.bind(null,r,s,n,e),void 0,null),n},useId:function(){var t=jt(),e=Ie.identifierPrefix;if(ne){var n=on,r=sn;n=(r&~(1<<32-Lt(r)-1)).toString(32)+n,e=":"+e+"R"+n,n=Rs++,0<n&&(e+="H"+n.toString(32)),e+=":"}else n=hE++,e=":"+e+"r"+n.toString(32)+":";return t.memoizedState=e},unstable_isNewReconciler:!1},gE={readContext:wt,useCallback:wy,useContext:wt,useEffect:Hh,useImperativeHandle:vy,useInsertionEffect:gy,useLayoutEffect:yy,useMemo:Ey,useReducer:yc,useRef:my,useState:function(){return yc(zs)},useDebugValue:Kh,useDeferredValue:function(t){var e=Et();return Sy(e,Ae.memoizedState,t)},useTransition:function(){var t=yc(zs)[0],e=Et().memoizedState;return[t,e]},useMutableSource:ly,useSyncExternalStore:uy,useId:Iy,unstable_isNewReconciler:!1},yE={readContext:wt,useCallback:wy,useContext:wt,useEffect:Hh,useImperativeHandle:vy,useInsertionEffect:gy,useLayoutEffect:yy,useMemo:Ey,useReducer:Ac,useRef:my,useState:function(){return Ac(zs)},useDebugValue:Kh,useDeferredValue:function(t){var e=Et();return Ae===null?e.memoizedState=t:Sy(e,Ae.memoizedState,t)},useTransition:function(){var t=Ac(zs)[0],e=Et().memoizedState;return[t,e]},useMutableSource:ly,useSyncExternalStore:uy,useId:Iy,unstable_isNewReconciler:!1};function vi(t,e){try{var n="",r=e;do n+=X2(r),r=r.return;while(r);var i=n}catch(s){i=`
Error generating stack: `+s.message+`
`+s.stack}return{value:t,source:e,stack:i,digest:null}}function vc(t,e,n){return{value:t,source:null,stack:n??null,digest:e??null}}function th(t,e){try{console.error(e.value)}catch(n){setTimeout(function(){throw n})}}var AE=typeof WeakMap=="function"?WeakMap:Map;function ky(t,e,n){n=an(-1,n),n.tag=3,n.payload={element:null};var r=e.value;return n.callback=function(){Wa||(Wa=!0,hh=r),th(t,e)},n}function Dy(t,e,n){n=an(-1,n),n.tag=3;var r=t.type.getDerivedStateFromError;if(typeof r=="function"){var i=e.value;n.payload=function(){return r(i)},n.callback=function(){th(t,e)}}var s=t.stateNode;return s!==null&&typeof s.componentDidCatch=="function"&&(n.callback=function(){th(t,e),typeof r!="function"&&(Vn===null?Vn=new Set([this]):Vn.add(this));var o=e.stack;this.componentDidCatch(e.value,{componentStack:o!==null?o:""})}),n}function zg(t,e,n){var r=t.pingCache;if(r===null){r=t.pingCache=new AE;var i=new Set;r.set(e,i)}else i=r.get(e),i===void 0&&(i=new Set,r.set(e,i));i.has(n)||(i.add(n),t=OE.bind(null,t,e,n),e.then(t,t))}function Fg(t){do{var e;if((e=t.tag===13)&&(e=t.memoizedState,e=e!==null?e.dehydrated!==null:!0),e)return t;t=t.return}while(t!==null);return null}function Bg(t,e,n,r,i){return t.mode&1?(t.flags|=65536,t.lanes=i,t):(t===e?t.flags|=65536:(t.flags|=128,n.flags|=131072,n.flags&=-52805,n.tag===1&&(n.alternate===null?n.tag=17:(e=an(-1,1),e.tag=2,qn(n,e,1))),n.lanes|=1),t)}var vE=dn.ReactCurrentOwner,$e=!1;function We(t,e,n,r){e.child=t===null?oy(e,null,n,r):yi(e,t.child,n,r)}function qg(t,e,n,r,i){n=n.render;var s=e.ref;return di(e,i),r=jh(t,e,n,r,s,i),n=Qh(),t!==null&&!$e?(e.updateQueue=t.updateQueue,e.flags&=-2053,t.lanes&=~i,hn(t,e,i)):(ne&&n&&_h(e),e.flags|=1,We(t,e,r,i),e.child)}function Vg(t,e,n,r,i){if(t===null){var s=n.type;return typeof s=="function"&&!ed(s)&&s.defaultProps===void 0&&n.compare===null&&n.defaultProps===void 0?(e.tag=15,e.type=s,Ny(t,e,s,r,i)):(t=ka(n.type,null,r,e,e.mode,i),t.ref=e.ref,t.return=e,e.child=t)}if(s=t.child,!(t.lanes&i)){var o=s.memoizedProps;if(n=n.compare,n=n!==null?n:Ps,n(o,r)&&t.ref===e.ref)return hn(t,e,i)}return e.flags|=1,t=jn(s,r),t.ref=e.ref,t.return=e,e.child=t}function Ny(t,e,n,r,i){if(t!==null){var s=t.memoizedProps;if(Ps(s,r)&&t.ref===e.ref)if($e=!1,e.pendingProps=r=s,(t.lanes&i)!==0)t.flags&131072&&($e=!0);else return e.lanes=t.lanes,hn(t,e,i)}return nh(t,e,n,r,i)}function Py(t,e,n){var r=e.pendingProps,i=r.children,s=t!==null?t.memoizedState:null;if(r.mode==="hidden")if(!(e.mode&1))e.memoizedState={baseLanes:0,cachePool:null,transitions:null},Y(ai,st),st|=n;else{if(!(n&1073741824))return t=s!==null?s.baseLanes|n:n,e.lanes=e.childLanes=1073741824,e.memoizedState={baseLanes:t,cachePool:null,transitions:null},e.updateQueue=null,Y(ai,st),st|=t,null;e.memoizedState={baseLanes:0,cachePool:null,transitions:null},r=s!==null?s.baseLanes:n,Y(ai,st),st|=r}else s!==null?(r=s.baseLanes|n,e.memoizedState=null):r=n,Y(ai,st),st|=r;return We(t,e,i,n),e.child}function _y(t,e){var n=e.ref;(t===null&&n!==null||t!==null&&t.ref!==n)&&(e.flags|=512,e.flags|=2097152)}function nh(t,e,n,r,i){var s=tt(n)?Er:Be.current;return s=mi(e,s),di(e,i),n=jh(t,e,n,r,s,i),r=Qh(),t!==null&&!$e?(e.updateQueue=t.updateQueue,e.flags&=-2053,t.lanes&=~i,hn(t,e,i)):(ne&&r&&_h(e),e.flags|=1,We(t,e,n,i),e.child)}function Ug(t,e,n,r,i){if(tt(n)){var s=!0;Fa(e)}else s=!1;if(di(e,i),e.stateNode===null)xa(t,e),iy(e,n,r),eh(e,n,r,i),r=!0;else if(t===null){var o=e.stateNode,a=e.memoizedProps;o.props=a;var l=o.context,u=n.contextType;typeof u=="object"&&u!==null?u=wt(u):(u=tt(n)?Er:Be.current,u=mi(e,u));var c=n.getDerivedStateFromProps,h=typeof c=="function"||typeof o.getSnapshotBeforeUpdate=="function";h||typeof o.UNSAFE_componentWillReceiveProps!="function"&&typeof o.componentWillReceiveProps!="function"||(a!==r||l!==u)&&Lg(e,o,r,u),_n=!1;var p=e.memoizedState;o.state=p,ja(e,r,o,i),l=e.memoizedState,a!==r||p!==l||et.current||_n?(typeof c=="function"&&($c(e,n,c,r),l=e.memoizedState),(a=_n||Og(e,n,a,r,p,l,u))?(h||typeof o.UNSAFE_componentWillMount!="function"&&typeof o.componentWillMount!="function"||(typeof o.componentWillMount=="function"&&o.componentWillMount(),typeof o.UNSAFE_componentWillMount=="function"&&o.UNSAFE_componentWillMount()),typeof o.componentDidMount=="function"&&(e.flags|=4194308)):(typeof o.componentDidMount=="function"&&(e.flags|=4194308),e.memoizedProps=r,e.memoizedState=l),o.props=r,o.state=l,o.context=u,r=a):(typeof o.componentDidMount=="function"&&(e.flags|=4194308),r=!1)}else{o=e.stateNode,ny(t,e),a=e.memoizedProps,u=e.type===e.elementType?a:Pt(e.type,a),o.props=u,h=e.pendingProps,p=o.context,l=n.contextType,typeof l=="object"&&l!==null?l=wt(l):(l=tt(n)?Er:Be.current,l=mi(e,l));var g=n.getDerivedStateFromProps;(c=typeof g=="function"||typeof o.getSnapshotBeforeUpdate=="function")||typeof o.UNSAFE_componentWillReceiveProps!="function"&&typeof o.componentWillReceiveProps!="function"||(a!==h||p!==l)&&Lg(e,o,r,l),_n=!1,p=e.memoizedState,o.state=p,ja(e,r,o,i);var y=e.memoizedState;a!==h||p!==y||et.current||_n?(typeof g=="function"&&($c(e,n,g,r),y=e.memoizedState),(u=_n||Og(e,n,u,r,p,y,l)||!1)?(c||typeof o.UNSAFE_componentWillUpdate!="function"&&typeof o.componentWillUpdate!="function"||(typeof o.componentWillUpdate=="function"&&o.componentWillUpdate(r,y,l),typeof o.UNSAFE_componentWillUpdate=="function"&&o.UNSAFE_componentWillUpdate(r,y,l)),typeof o.componentDidUpdate=="function"&&(e.flags|=4),typeof o.getSnapshotBeforeUpdate=="function"&&(e.flags|=1024)):(typeof o.componentDidUpdate!="function"||a===t.memoizedProps&&p===t.memoizedState||(e.flags|=4),typeof o.getSnapshotBeforeUpdate!="function"||a===t.memoizedProps&&p===t.memoizedState||(e.flags|=1024),e.memoizedProps=r,e.memoizedState=y),o.props=r,o.state=y,o.context=l,r=u):(typeof o.componentDidUpdate!="function"||a===t.memoizedProps&&p===t.memoizedState||(e.flags|=4),typeof o.getSnapshotBeforeUpdate!="function"||a===t.memoizedProps&&p===t.memoizedState||(e.flags|=1024),r=!1)}return rh(t,e,n,r,s,i)}function rh(t,e,n,r,i,s){_y(t,e);var o=(e.flags&128)!==0;if(!r&&!o)return i&&kg(e,n,!1),hn(t,e,s);r=e.stateNode,vE.current=e;var a=o&&typeof n.getDerivedStateFromError!="function"?null:r.render();return e.flags|=1,t!==null&&o?(e.child=yi(e,t.child,null,s),e.child=yi(e,null,a,s)):We(t,e,a,s),e.memoizedState=r.state,i&&kg(e,n,!0),e.child}function Oy(t){var e=t.stateNode;e.pendingContext?Cg(t,e.pendingContext,e.pendingContext!==e.context):e.context&&Cg(t,e.context,!1),Bh(t,e.containerInfo)}function jg(t,e,n,r,i){return gi(),Lh(i),e.flags|=256,We(t,e,n,r),e.child}var ih={dehydrated:null,treeContext:null,retryLane:0};function sh(t){return{baseLanes:t,cachePool:null,transitions:null}}function Ly(t,e,n){var r=e.pendingProps,i=ae.current,s=!1,o=(e.flags&128)!==0,a;if((a=o)||(a=t!==null&&t.memoizedState===null?!1:(i&2)!==0),a?(s=!0,e.flags&=-129):(t===null||t.memoizedState!==null)&&(i|=1),Y(ae,i&1),t===null)return Zc(e),t=e.memoizedState,t!==null&&(t=t.dehydrated,t!==null)?(e.mode&1?t.data==="$!"?e.lanes=8:e.lanes=1073741824:e.lanes=1,null):(o=r.children,t=r.fallback,s?(r=e.mode,s=e.child,o={mode:"hidden",children:o},!(r&1)&&s!==null?(s.childLanes=0,s.pendingProps=o):s=ll(o,r,0,null),t=wr(t,r,n,null),s.return=e,t.return=e,s.sibling=t,e.child=s,e.child.memoizedState=sh(n),e.memoizedState=ih,t):Xh(e,o));if(i=t.memoizedState,i!==null&&(a=i.dehydrated,a!==null))return wE(t,e,o,r,a,i,n);if(s){s=r.fallback,o=e.mode,i=t.child,a=i.sibling;var l={mode:"hidden",children:r.children};return!(o&1)&&e.child!==i?(r=e.child,r.childLanes=0,r.pendingProps=l,e.deletions=null):(r=jn(i,l),r.subtreeFlags=i.subtreeFlags&14680064),a!==null?s=jn(a,s):(s=wr(s,o,n,null),s.flags|=2),s.return=e,r.return=e,r.sibling=s,e.child=r,r=s,s=e.child,o=t.child.memoizedState,o=o===null?sh(n):{baseLanes:o.baseLanes|n,cachePool:null,transitions:o.transitions},s.memoizedState=o,s.childLanes=t.childLanes&~n,e.memoizedState=ih,r}return s=t.child,t=s.sibling,r=jn(s,{mode:"visible",children:r.children}),!(e.mode&1)&&(r.lanes=n),r.return=e,r.sibling=null,t!==null&&(n=e.deletions,n===null?(e.deletions=[t],e.flags|=16):n.push(t)),e.child=r,e.memoizedState=null,r}function Xh(t,e){return e=ll({mode:"visible",children:e},t.mode,0,null),e.return=t,t.child=e}function ma(t,e,n,r){return r!==null&&Lh(r),yi(e,t.child,null,n),t=Xh(e,e.pendingProps.children),t.flags|=2,e.memoizedState=null,t}function wE(t,e,n,r,i,s,o){if(n)return e.flags&256?(e.flags&=-257,r=vc(Error(w(422))),ma(t,e,o,r)):e.memoizedState!==null?(e.child=t.child,e.flags|=128,null):(s=r.fallback,i=e.mode,r=ll({mode:"visible",children:r.children},i,0,null),s=wr(s,i,o,null),s.flags|=2,r.return=e,s.return=e,r.sibling=s,e.child=r,e.mode&1&&yi(e,t.child,null,o),e.child.memoizedState=sh(o),e.memoizedState=ih,s);if(!(e.mode&1))return ma(t,e,o,null);if(i.data==="$!"){if(r=i.nextSibling&&i.nextSibling.dataset,r)var a=r.dgst;return r=a,s=Error(w(419)),r=vc(s,r,void 0),ma(t,e,o,r)}if(a=(o&t.childLanes)!==0,$e||a){if(r=Ie,r!==null){switch(o&-o){case 4:i=2;break;case 16:i=8;break;case 64:case 128:case 256:case 512:case 1024:case 2048:case 4096:case 8192:case 16384:case 32768:case 65536:case 131072:case 262144:case 524288:case 1048576:case 2097152:case 4194304:case 8388608:case 16777216:case 33554432:case 67108864:i=32;break;case 536870912:i=268435456;break;default:i=0}i=i&(r.suspendedLanes|o)?0:i,i!==0&&i!==s.retryLane&&(s.retryLane=i,cn(t,i),Mt(r,t,i,-1))}return $h(),r=vc(Error(w(421))),ma(t,e,o,r)}return i.data==="$?"?(e.flags|=128,e.child=t.child,e=LE.bind(null,t),i._reactRetry=e,null):(t=s.treeContext,ot=Bn(i.nextSibling),at=e,ne=!0,Ot=null,t!==null&&(gt[yt++]=sn,gt[yt++]=on,gt[yt++]=Sr,sn=t.id,on=t.overflow,Sr=e),e=Xh(e,r.children),e.flags|=4096,e)}function Qg(t,e,n){t.lanes|=e;var r=t.alternate;r!==null&&(r.lanes|=e),Yc(t.return,e,n)}function wc(t,e,n,r,i){var s=t.memoizedState;s===null?t.memoizedState={isBackwards:e,rendering:null,renderingStartTime:0,last:r,tail:n,tailMode:i}:(s.isBackwards=e,s.rendering=null,s.renderingStartTime=0,s.last=r,s.tail=n,s.tailMode=i)}function My(t,e,n){var r=e.pendingProps,i=r.revealOrder,s=r.tail;if(We(t,e,r.children,n),r=ae.current,r&2)r=r&1|2,e.flags|=128;else{if(t!==null&&t.flags&128)e:for(t=e.child;t!==null;){if(t.tag===13)t.memoizedState!==null&&Qg(t,n,e);else if(t.tag===19)Qg(t,n,e);else if(t.child!==null){t.child.return=t,t=t.child;continue}if(t===e)break e;for(;t.sibling===null;){if(t.return===null||t.return===e)break e;t=t.return}t.sibling.return=t.return,t=t.sibling}r&=1}if(Y(ae,r),!(e.mode&1))e.memoizedState=null;else switch(i){case"forwards":for(n=e.child,i=null;n!==null;)t=n.alternate,t!==null&&Qa(t)===null&&(i=n),n=n.sibling;n=i,n===null?(i=e.child,e.child=null):(i=n.sibling,n.sibling=null),wc(e,!1,i,n,s);break;case"backwards":for(n=null,i=e.child,e.child=null;i!==null;){if(t=i.alternate,t!==null&&Qa(t)===null){e.child=i;break}t=i.sibling,i.sibling=n,n=i,i=t}wc(e,!0,n,null,s);break;case"together":wc(e,!1,null,null,void 0);break;default:e.memoizedState=null}return e.child}function xa(t,e){!(e.mode&1)&&t!==null&&(t.alternate=null,e.alternate=null,e.flags|=2)}function hn(t,e,n){if(t!==null&&(e.dependencies=t.dependencies),xr|=e.lanes,!(n&e.childLanes))return null;if(t!==null&&e.child!==t.child)throw Error(w(153));if(e.child!==null){for(t=e.child,n=jn(t,t.pendingProps),e.child=n,n.return=e;t.sibling!==null;)t=t.sibling,n=n.sibling=jn(t,t.pendingProps),n.return=e;n.sibling=null}return e.child}function EE(t,e,n){switch(e.tag){case 3:Oy(e),gi();break;case 5:ay(e);break;case 1:tt(e.type)&&Fa(e);break;case 4:Bh(e,e.stateNode.containerInfo);break;case 10:var r=e.type._context,i=e.memoizedProps.value;Y(Va,r._currentValue),r._currentValue=i;break;case 13:if(r=e.memoizedState,r!==null)return r.dehydrated!==null?(Y(ae,ae.current&1),e.flags|=128,null):n&e.child.childLanes?Ly(t,e,n):(Y(ae,ae.current&1),t=hn(t,e,n),t!==null?t.sibling:null);Y(ae,ae.current&1);break;case 19:if(r=(n&e.childLanes)!==0,t.flags&128){if(r)return My(t,e,n);e.flags|=128}if(i=e.memoizedState,i!==null&&(i.rendering=null,i.tail=null,i.lastEffect=null),Y(ae,ae.current),r)break;return null;case 22:case 23:return e.lanes=0,Py(t,e,n)}return hn(t,e,n)}var by,oh,Ry,zy;by=function(t,e){for(var n=e.child;n!==null;){if(n.tag===5||n.tag===6)t.appendChild(n.stateNode);else if(n.tag!==4&&n.child!==null){n.child.return=n,n=n.child;continue}if(n===e)break;for(;n.sibling===null;){if(n.return===null||n.return===e)return;n=n.return}n.sibling.return=n.return,n=n.sibling}};oh=function(){};Ry=function(t,e,n,r){var i=t.memoizedProps;if(i!==r){t=e.stateNode,Ar(Kt.current);var s=null;switch(n){case"input":i=Dc(t,i),r=Dc(t,r),s=[];break;case"select":i=ue({},i,{value:void 0}),r=ue({},r,{value:void 0}),s=[];break;case"textarea":i=_c(t,i),r=_c(t,r),s=[];break;default:typeof i.onClick!="function"&&typeof r.onClick=="function"&&(t.onclick=Ra)}Lc(n,r);var o;n=null;for(u in i)if(!r.hasOwnProperty(u)&&i.hasOwnProperty(u)&&i[u]!=null)if(u==="style"){var a=i[u];for(o in a)a.hasOwnProperty(o)&&(n||(n={}),n[o]="")}else u!=="dangerouslySetInnerHTML"&&u!=="children"&&u!=="suppressContentEditableWarning"&&u!=="suppressHydrationWarning"&&u!=="autoFocus"&&(Is.hasOwnProperty(u)?s||(s=[]):(s=s||[]).push(u,null));for(u in r){var l=r[u];if(a=i?.[u],r.hasOwnProperty(u)&&l!==a&&(l!=null||a!=null))if(u==="style")if(a){for(o in a)!a.hasOwnProperty(o)||l&&l.hasOwnProperty(o)||(n||(n={}),n[o]="");for(o in l)l.hasOwnProperty(o)&&a[o]!==l[o]&&(n||(n={}),n[o]=l[o])}else n||(s||(s=[]),s.push(u,n)),n=l;else u==="dangerouslySetInnerHTML"?(l=l?l.__html:void 0,a=a?a.__html:void 0,l!=null&&a!==l&&(s=s||[]).push(u,l)):u==="children"?typeof l!="string"&&typeof l!="number"||(s=s||[]).push(u,""+l):u!=="suppressContentEditableWarning"&&u!=="suppressHydrationWarning"&&(Is.hasOwnProperty(u)?(l!=null&&u==="onScroll"&&$("scroll",t),s||a===l||(s=[])):(s=s||[]).push(u,l))}n&&(s=s||[]).push("style",n);var u=s;(e.updateQueue=u)&&(e.flags|=4)}};zy=function(t,e,n,r){n!==r&&(e.flags|=4)};function as(t,e){if(!ne)switch(t.tailMode){case"hidden":e=t.tail;for(var n=null;e!==null;)e.alternate!==null&&(n=e),e=e.sibling;n===null?t.tail=null:n.sibling=null;break;case"collapsed":n=t.tail;for(var r=null;n!==null;)n.alternate!==null&&(r=n),n=n.sibling;r===null?e||t.tail===null?t.tail=null:t.tail.sibling=null:r.sibling=null}}function ze(t){var e=t.alternate!==null&&t.alternate.child===t.child,n=0,r=0;if(e)for(var i=t.child;i!==null;)n|=i.lanes|i.childLanes,r|=i.subtreeFlags&14680064,r|=i.flags&14680064,i.return=t,i=i.sibling;else for(i=t.child;i!==null;)n|=i.lanes|i.childLanes,r|=i.subtreeFlags,r|=i.flags,i.return=t,i=i.sibling;return t.subtreeFlags|=r,t.childLanes=n,e}function SE(t,e,n){var r=e.pendingProps;switch(Oh(e),e.tag){case 2:case 16:case 15:case 0:case 11:case 7:case 8:case 12:case 9:case 14:return ze(e),null;case 1:return tt(e.type)&&za(),ze(e),null;case 3:return r=e.stateNode,Ai(),ee(et),ee(Be),Vh(),r.pendingContext&&(r.context=r.pendingContext,r.pendingContext=null),(t===null||t.child===null)&&(fa(e)?e.flags|=4:t===null||t.memoizedState.isDehydrated&&!(e.flags&256)||(e.flags|=1024,Ot!==null&&(ph(Ot),Ot=null))),oh(t,e),ze(e),null;case 5:qh(e);var i=Ar(bs.current);if(n=e.type,t!==null&&e.stateNode!=null)Ry(t,e,n,r,i),t.ref!==e.ref&&(e.flags|=512,e.flags|=2097152);else{if(!r){if(e.stateNode===null)throw Error(w(166));return ze(e),null}if(t=Ar(Kt.current),fa(e)){r=e.stateNode,n=e.type;var s=e.memoizedProps;switch(r[Qt]=e,r[Ls]=s,t=(e.mode&1)!==0,n){case"dialog":$("cancel",r),$("close",r);break;case"iframe":case"object":case"embed":$("load",r);break;case"video":case"audio":for(i=0;i<fs.length;i++)$(fs[i],r);break;case"source":$("error",r);break;case"img":case"image":case"link":$("error",r),$("load",r);break;case"details":$("toggle",r);break;case"input":Ym(r,s),$("invalid",r);break;case"select":r._wrapperState={wasMultiple:!!s.multiple},$("invalid",r);break;case"textarea":eg(r,s),$("invalid",r)}Lc(n,s),i=null;for(var o in s)if(s.hasOwnProperty(o)){var a=s[o];o==="children"?typeof a=="string"?r.textContent!==a&&(s.suppressHydrationWarning!==!0&&da(r.textContent,a,t),i=["children",a]):typeof a=="number"&&r.textContent!==""+a&&(s.suppressHydrationWarning!==!0&&da(r.textContent,a,t),i=["children",""+a]):Is.hasOwnProperty(o)&&a!=null&&o==="onScroll"&&$("scroll",r)}switch(n){case"input":ea(r),$m(r,s,!0);break;case"textarea":ea(r),tg(r);break;case"select":case"option":break;default:typeof s.onClick=="function"&&(r.onclick=Ra)}r=i,e.updateQueue=r,r!==null&&(e.flags|=4)}else{o=i.nodeType===9?i:i.ownerDocument,t==="http://www.w3.org/1999/xhtml"&&(t=c0(n)),t==="http://www.w3.org/1999/xhtml"?n==="script"?(t=o.createElement("div"),t.innerHTML="<script><\/script>",t=t.removeChild(t.firstChild)):typeof r.is=="string"?t=o.createElement(n,{is:r.is}):(t=o.createElement(n),n==="select"&&(o=t,r.multiple?o.multiple=!0:r.size&&(o.size=r.size))):t=o.createElementNS(t,n),t[Qt]=e,t[Ls]=r,by(t,e,!1,!1),e.stateNode=t;e:{switch(o=Mc(n,r),n){case"dialog":$("cancel",t),$("close",t),i=r;break;case"iframe":case"object":case"embed":$("load",t),i=r;break;case"video":case"audio":for(i=0;i<fs.length;i++)$(fs[i],t);i=r;break;case"source":$("error",t),i=r;break;case"img":case"image":case"link":$("error",t),$("load",t),i=r;break;case"details":$("toggle",t),i=r;break;case"input":Ym(t,r),i=Dc(t,r),$("invalid",t);break;case"option":i=r;break;case"select":t._wrapperState={wasMultiple:!!r.multiple},i=ue({},r,{value:void 0}),$("invalid",t);break;case"textarea":eg(t,r),i=_c(t,r),$("invalid",t);break;default:i=r}Lc(n,i),a=i;for(s in a)if(a.hasOwnProperty(s)){var l=a[s];s==="style"?f0(t,l):s==="dangerouslySetInnerHTML"?(l=l?l.__html:void 0,l!=null&&h0(t,l)):s==="children"?typeof l=="string"?(n!=="textarea"||l!=="")&&xs(t,l):typeof l=="number"&&xs(t,""+l):s!=="suppressContentEditableWarning"&&s!=="suppressHydrationWarning"&&s!=="autoFocus"&&(Is.hasOwnProperty(s)?l!=null&&s==="onScroll"&&$("scroll",t):l!=null&&yh(t,s,l,o))}switch(n){case"input":ea(t),$m(t,r,!1);break;case"textarea":ea(t),tg(t);break;case"option":r.value!=null&&t.setAttribute("value",""+Qn(r.value));break;case"select":t.multiple=!!r.multiple,s=r.value,s!=null?li(t,!!r.multiple,s,!1):r.defaultValue!=null&&li(t,!!r.multiple,r.defaultValue,!0);break;default:typeof i.onClick=="function"&&(t.onclick=Ra)}switch(n){case"button":case"input":case"select":case"textarea":r=!!r.autoFocus;break e;case"img":r=!0;break e;default:r=!1}}r&&(e.flags|=4)}e.ref!==null&&(e.flags|=512,e.flags|=2097152)}return ze(e),null;case 6:if(t&&e.stateNode!=null)zy(t,e,t.memoizedProps,r);else{if(typeof r!="string"&&e.stateNode===null)throw Error(w(166));if(n=Ar(bs.current),Ar(Kt.current),fa(e)){if(r=e.stateNode,n=e.memoizedProps,r[Qt]=e,(s=r.nodeValue!==n)&&(t=at,t!==null))switch(t.tag){case 3:da(r.nodeValue,n,(t.mode&1)!==0);break;case 5:t.memoizedProps.suppressHydrationWarning!==!0&&da(r.nodeValue,n,(t.mode&1)!==0)}s&&(e.flags|=4)}else r=(n.nodeType===9?n:n.ownerDocument).createTextNode(r),r[Qt]=e,e.stateNode=r}return ze(e),null;case 13:if(ee(ae),r=e.memoizedState,t===null||t.memoizedState!==null&&t.memoizedState.dehydrated!==null){if(ne&&ot!==null&&e.mode&1&&!(e.flags&128))ey(),gi(),e.flags|=98560,s=!1;else if(s=fa(e),r!==null&&r.dehydrated!==null){if(t===null){if(!s)throw Error(w(318));if(s=e.memoizedState,s=s!==null?s.dehydrated:null,!s)throw Error(w(317));s[Qt]=e}else gi(),!(e.flags&128)&&(e.memoizedState=null),e.flags|=4;ze(e),s=!1}else Ot!==null&&(ph(Ot),Ot=null),s=!0;if(!s)return e.flags&65536?e:null}return e.flags&128?(e.lanes=n,e):(r=r!==null,r!==(t!==null&&t.memoizedState!==null)&&r&&(e.child.flags|=8192,e.mode&1&&(t===null||ae.current&1?ve===0&&(ve=3):$h())),e.updateQueue!==null&&(e.flags|=4),ze(e),null);case 4:return Ai(),oh(t,e),t===null&&_s(e.stateNode.containerInfo),ze(e),null;case 10:return Rh(e.type._context),ze(e),null;case 17:return tt(e.type)&&za(),ze(e),null;case 19:if(ee(ae),s=e.memoizedState,s===null)return ze(e),null;if(r=(e.flags&128)!==0,o=s.rendering,o===null)if(r)as(s,!1);else{if(ve!==0||t!==null&&t.flags&128)for(t=e.child;t!==null;){if(o=Qa(t),o!==null){for(e.flags|=128,as(s,!1),r=o.updateQueue,r!==null&&(e.updateQueue=r,e.flags|=4),e.subtreeFlags=0,r=n,n=e.child;n!==null;)s=n,t=r,s.flags&=14680066,o=s.alternate,o===null?(s.childLanes=0,s.lanes=t,s.child=null,s.subtreeFlags=0,s.memoizedProps=null,s.memoizedState=null,s.updateQueue=null,s.dependencies=null,s.stateNode=null):(s.childLanes=o.childLanes,s.lanes=o.lanes,s.child=o.child,s.subtreeFlags=0,s.deletions=null,s.memoizedProps=o.memoizedProps,s.memoizedState=o.memoizedState,s.updateQueue=o.updateQueue,s.type=o.type,t=o.dependencies,s.dependencies=t===null?null:{lanes:t.lanes,firstContext:t.firstContext}),n=n.sibling;return Y(ae,ae.current&1|2),e.child}t=t.sibling}s.tail!==null&&fe()>wi&&(e.flags|=128,r=!0,as(s,!1),e.lanes=4194304)}else{if(!r)if(t=Qa(o),t!==null){if(e.flags|=128,r=!0,n=t.updateQueue,n!==null&&(e.updateQueue=n,e.flags|=4),as(s,!0),s.tail===null&&s.tailMode==="hidden"&&!o.alternate&&!ne)return ze(e),null}else 2*fe()-s.renderingStartTime>wi&&n!==1073741824&&(e.flags|=128,r=!0,as(s,!1),e.lanes=4194304);s.isBackwards?(o.sibling=e.child,e.child=o):(n=s.last,n!==null?n.sibling=o:e.child=o,s.last=o)}return s.tail!==null?(e=s.tail,s.rendering=e,s.tail=e.sibling,s.renderingStartTime=fe(),e.sibling=null,n=ae.current,Y(ae,r?n&1|2:n&1),e):(ze(e),null);case 22:case 23:return Yh(),r=e.memoizedState!==null,t!==null&&t.memoizedState!==null!==r&&(e.flags|=8192),r&&e.mode&1?st&1073741824&&(ze(e),e.subtreeFlags&6&&(e.flags|=8192)):ze(e),null;case 24:return null;case 25:return null}throw Error(w(156,e.tag))}function IE(t,e){switch(Oh(e),e.tag){case 1:return tt(e.type)&&za(),t=e.flags,t&65536?(e.flags=t&-65537|128,e):null;case 3:return Ai(),ee(et),ee(Be),Vh(),t=e.flags,t&65536&&!(t&128)?(e.flags=t&-65537|128,e):null;case 5:return qh(e),null;case 13:if(ee(ae),t=e.memoizedState,t!==null&&t.dehydrated!==null){if(e.alternate===null)throw Error(w(340));gi()}return t=e.flags,t&65536?(e.flags=t&-65537|128,e):null;case 19:return ee(ae),null;case 4:return Ai(),null;case 10:return Rh(e.type._context),null;case 22:case 23:return Yh(),null;case 24:return null;default:return null}}var ga=!1,Fe=!1,xE=typeof WeakSet=="function"?WeakSet:Set,C=null;function oi(t,e){var n=t.ref;if(n!==null)if(typeof n=="function")try{n(null)}catch(r){ce(t,e,r)}else n.current=null}function ah(t,e,n){try{n()}catch(r){ce(t,e,r)}}var Hg=!1;function TE(t,e){if(Qc=La,t=V0(),Ph(t)){if("selectionStart"in t)var n={start:t.selectionStart,end:t.selectionEnd};else e:{n=(n=t.ownerDocument)&&n.defaultView||window;var r=n.getSelection&&n.getSelection();if(r&&r.rangeCount!==0){n=r.anchorNode;var i=r.anchorOffset,s=r.focusNode;r=r.focusOffset;try{n.nodeType,s.nodeType}catch{n=null;break e}var o=0,a=-1,l=-1,u=0,c=0,h=t,p=null;t:for(;;){for(var g;h!==n||i!==0&&h.nodeType!==3||(a=o+i),h!==s||r!==0&&h.nodeType!==3||(l=o+r),h.nodeType===3&&(o+=h.nodeValue.length),(g=h.firstChild)!==null;)p=h,h=g;for(;;){if(h===t)break t;if(p===n&&++u===i&&(a=o),p===s&&++c===r&&(l=o),(g=h.nextSibling)!==null)break;h=p,p=h.parentNode}h=g}n=a===-1||l===-1?null:{start:a,end:l}}else n=null}n=n||{start:0,end:0}}else n=null;for(Hc={focusedElem:t,selectionRange:n},La=!1,C=e;C!==null;)if(e=C,t=e.child,(e.subtreeFlags&1028)!==0&&t!==null)t.return=e,C=t;else for(;C!==null;){e=C;try{var y=e.alternate;if(e.flags&1024)switch(e.tag){case 0:case 11:case 15:break;case 1:if(y!==null){var A=y.memoizedProps,P=y.memoizedState,f=e.stateNode,d=f.getSnapshotBeforeUpdate(e.elementType===e.type?A:Pt(e.type,A),P);f.__reactInternalSnapshotBeforeUpdate=d}break;case 3:var m=e.stateNode.containerInfo;m.nodeType===1?m.textContent="":m.nodeType===9&&m.documentElement&&m.removeChild(m.documentElement);break;case 5:case 6:case 4:case 17:break;default:throw Error(w(163))}}catch(v){ce(e,e.return,v)}if(t=e.sibling,t!==null){t.return=e.return,C=t;break}C=e.return}return y=Hg,Hg=!1,y}function ws(t,e,n){var r=e.updateQueue;if(r=r!==null?r.lastEffect:null,r!==null){var i=r=r.next;do{if((i.tag&t)===t){var s=i.destroy;i.destroy=void 0,s!==void 0&&ah(e,n,s)}i=i.next}while(i!==r)}}function ol(t,e){if(e=e.updateQueue,e=e!==null?e.lastEffect:null,e!==null){var n=e=e.next;do{if((n.tag&t)===t){var r=n.create;n.destroy=r()}n=n.next}while(n!==e)}}function lh(t){var e=t.ref;if(e!==null){var n=t.stateNode;switch(t.tag){case 5:t=n;break;default:t=n}typeof e=="function"?e(t):e.current=t}}function Fy(t){var e=t.alternate;e!==null&&(t.alternate=null,Fy(e)),t.child=null,t.deletions=null,t.sibling=null,t.tag===5&&(e=t.stateNode,e!==null&&(delete e[Qt],delete e[Ls],delete e[Wc],delete e[aE],delete e[lE])),t.stateNode=null,t.return=null,t.dependencies=null,t.memoizedProps=null,t.memoizedState=null,t.pendingProps=null,t.stateNode=null,t.updateQueue=null}function By(t){return t.tag===5||t.tag===3||t.tag===4}function Kg(t){e:for(;;){for(;t.sibling===null;){if(t.return===null||By(t.return))return null;t=t.return}for(t.sibling.return=t.return,t=t.sibling;t.tag!==5&&t.tag!==6&&t.tag!==18;){if(t.flags&2||t.child===null||t.tag===4)continue e;t.child.return=t,t=t.child}if(!(t.flags&2))return t.stateNode}}function uh(t,e,n){var r=t.tag;if(r===5||r===6)t=t.stateNode,e?n.nodeType===8?n.parentNode.insertBefore(t,e):n.insertBefore(t,e):(n.nodeType===8?(e=n.parentNode,e.insertBefore(t,n)):(e=n,e.appendChild(t)),n=n._reactRootContainer,n!=null||e.onclick!==null||(e.onclick=Ra));else if(r!==4&&(t=t.child,t!==null))for(uh(t,e,n),t=t.sibling;t!==null;)uh(t,e,n),t=t.sibling}function ch(t,e,n){var r=t.tag;if(r===5||r===6)t=t.stateNode,e?n.insertBefore(t,e):n.appendChild(t);else if(r!==4&&(t=t.child,t!==null))for(ch(t,e,n),t=t.sibling;t!==null;)ch(t,e,n),t=t.sibling}var Pe=null,_t=!1;function Nn(t,e,n){for(n=n.child;n!==null;)qy(t,e,n),n=n.sibling}function qy(t,e,n){if(Ht&&typeof Ht.onCommitFiberUnmount=="function")try{Ht.onCommitFiberUnmount(Ya,n)}catch{}switch(n.tag){case 5:Fe||oi(n,e);case 6:var r=Pe,i=_t;Pe=null,Nn(t,e,n),Pe=r,_t=i,Pe!==null&&(_t?(t=Pe,n=n.stateNode,t.nodeType===8?t.parentNode.removeChild(n):t.removeChild(n)):Pe.removeChild(n.stateNode));break;case 18:Pe!==null&&(_t?(t=Pe,n=n.stateNode,t.nodeType===8?fc(t.parentNode,n):t.nodeType===1&&fc(t,n),Ds(t)):fc(Pe,n.stateNode));break;case 4:r=Pe,i=_t,Pe=n.stateNode.containerInfo,_t=!0,Nn(t,e,n),Pe=r,_t=i;break;case 0:case 11:case 14:case 15:if(!Fe&&(r=n.updateQueue,r!==null&&(r=r.lastEffect,r!==null))){i=r=r.next;do{var s=i,o=s.destroy;s=s.tag,o!==void 0&&(s&2||s&4)&&ah(n,e,o),i=i.next}while(i!==r)}Nn(t,e,n);break;case 1:if(!Fe&&(oi(n,e),r=n.stateNode,typeof r.componentWillUnmount=="function"))try{r.props=n.memoizedProps,r.state=n.memoizedState,r.componentWillUnmount()}catch(a){ce(n,e,a)}Nn(t,e,n);break;case 21:Nn(t,e,n);break;case 22:n.mode&1?(Fe=(r=Fe)||n.memoizedState!==null,Nn(t,e,n),Fe=r):Nn(t,e,n);break;default:Nn(t,e,n)}}function Xg(t){var e=t.updateQueue;if(e!==null){t.updateQueue=null;var n=t.stateNode;n===null&&(n=t.stateNode=new xE),e.forEach(function(r){var i=ME.bind(null,t,r);n.has(r)||(n.add(r),r.then(i,i))})}}function Nt(t,e){var n=e.deletions;if(n!==null)for(var r=0;r<n.length;r++){var i=n[r];try{var s=t,o=e,a=o;e:for(;a!==null;){switch(a.tag){case 5:Pe=a.stateNode,_t=!1;break e;case 3:Pe=a.stateNode.containerInfo,_t=!0;break e;case 4:Pe=a.stateNode.containerInfo,_t=!0;break e}a=a.return}if(Pe===null)throw Error(w(160));qy(s,o,i),Pe=null,_t=!1;var l=i.alternate;l!==null&&(l.return=null),i.return=null}catch(u){ce(i,e,u)}}if(e.subtreeFlags&12854)for(e=e.child;e!==null;)Vy(e,t),e=e.sibling}function Vy(t,e){var n=t.alternate,r=t.flags;switch(t.tag){case 0:case 11:case 14:case 15:if(Nt(e,t),Ut(t),r&4){try{ws(3,t,t.return),ol(3,t)}catch(A){ce(t,t.return,A)}try{ws(5,t,t.return)}catch(A){ce(t,t.return,A)}}break;case 1:Nt(e,t),Ut(t),r&512&&n!==null&&oi(n,n.return);break;case 5:if(Nt(e,t),Ut(t),r&512&&n!==null&&oi(n,n.return),t.flags&32){var i=t.stateNode;try{xs(i,"")}catch(A){ce(t,t.return,A)}}if(r&4&&(i=t.stateNode,i!=null)){var s=t.memoizedProps,o=n!==null?n.memoizedProps:s,a=t.type,l=t.updateQueue;if(t.updateQueue=null,l!==null)try{a==="input"&&s.type==="radio"&&s.name!=null&&l0(i,s),Mc(a,o);var u=Mc(a,s);for(o=0;o<l.length;o+=2){var c=l[o],h=l[o+1];c==="style"?f0(i,h):c==="dangerouslySetInnerHTML"?h0(i,h):c==="children"?xs(i,h):yh(i,c,h,u)}switch(a){case"input":Nc(i,s);break;case"textarea":u0(i,s);break;case"select":var p=i._wrapperState.wasMultiple;i._wrapperState.wasMultiple=!!s.multiple;var g=s.value;g!=null?li(i,!!s.multiple,g,!1):p!==!!s.multiple&&(s.defaultValue!=null?li(i,!!s.multiple,s.defaultValue,!0):li(i,!!s.multiple,s.multiple?[]:"",!1))}i[Ls]=s}catch(A){ce(t,t.return,A)}}break;case 6:if(Nt(e,t),Ut(t),r&4){if(t.stateNode===null)throw Error(w(162));i=t.stateNode,s=t.memoizedProps;try{i.nodeValue=s}catch(A){ce(t,t.return,A)}}break;case 3:if(Nt(e,t),Ut(t),r&4&&n!==null&&n.memoizedState.isDehydrated)try{Ds(e.containerInfo)}catch(A){ce(t,t.return,A)}break;case 4:Nt(e,t),Ut(t);break;case 13:Nt(e,t),Ut(t),i=t.child,i.flags&8192&&(s=i.memoizedState!==null,i.stateNode.isHidden=s,!s||i.alternate!==null&&i.alternate.memoizedState!==null||(Jh=fe())),r&4&&Xg(t);break;case 22:if(c=n!==null&&n.memoizedState!==null,t.mode&1?(Fe=(u=Fe)||c,Nt(e,t),Fe=u):Nt(e,t),Ut(t),r&8192){if(u=t.memoizedState!==null,(t.stateNode.isHidden=u)&&!c&&t.mode&1)for(C=t,c=t.child;c!==null;){for(h=C=c;C!==null;){switch(p=C,g=p.child,p.tag){case 0:case 11:case 14:case 15:ws(4,p,p.return);break;case 1:oi(p,p.return);var y=p.stateNode;if(typeof y.componentWillUnmount=="function"){r=p,n=p.return;try{e=r,y.props=e.memoizedProps,y.state=e.memoizedState,y.componentWillUnmount()}catch(A){ce(r,n,A)}}break;case 5:oi(p,p.return);break;case 22:if(p.memoizedState!==null){Gg(h);continue}}g!==null?(g.return=p,C=g):Gg(h)}c=c.sibling}e:for(c=null,h=t;;){if(h.tag===5){if(c===null){c=h;try{i=h.stateNode,u?(s=i.style,typeof s.setProperty=="function"?s.setProperty("display","none","important"):s.display="none"):(a=h.stateNode,l=h.memoizedProps.style,o=l!=null&&l.hasOwnProperty("display")?l.display:null,a.style.display=d0("display",o))}catch(A){ce(t,t.return,A)}}}else if(h.tag===6){if(c===null)try{h.stateNode.nodeValue=u?"":h.memoizedProps}catch(A){ce(t,t.return,A)}}else if((h.tag!==22&&h.tag!==23||h.memoizedState===null||h===t)&&h.child!==null){h.child.return=h,h=h.child;continue}if(h===t)break e;for(;h.sibling===null;){if(h.return===null||h.return===t)break e;c===h&&(c=null),h=h.return}c===h&&(c=null),h.sibling.return=h.return,h=h.sibling}}break;case 19:Nt(e,t),Ut(t),r&4&&Xg(t);break;case 21:break;default:Nt(e,t),Ut(t)}}function Ut(t){var e=t.flags;if(e&2){try{e:{for(var n=t.return;n!==null;){if(By(n)){var r=n;break e}n=n.return}throw Error(w(160))}switch(r.tag){case 5:var i=r.stateNode;r.flags&32&&(xs(i,""),r.flags&=-33);var s=Kg(t);ch(t,s,i);break;case 3:case 4:var o=r.stateNode.containerInfo,a=Kg(t);uh(t,a,o);break;default:throw Error(w(161))}}catch(l){ce(t,t.return,l)}t.flags&=-3}e&4096&&(t.flags&=-4097)}function CE(t,e,n){C=t,Uy(t,e,n)}function Uy(t,e,n){for(var r=(t.mode&1)!==0;C!==null;){var i=C,s=i.child;if(i.tag===22&&r){var o=i.memoizedState!==null||ga;if(!o){var a=i.alternate,l=a!==null&&a.memoizedState!==null||Fe;a=ga;var u=Fe;if(ga=o,(Fe=l)&&!u)for(C=i;C!==null;)o=C,l=o.child,o.tag===22&&o.memoizedState!==null?Jg(i):l!==null?(l.return=o,C=l):Jg(i);for(;s!==null;)C=s,Uy(s,e,n),s=s.sibling;C=i,ga=a,Fe=u}Wg(t,e,n)}else i.subtreeFlags&8772&&s!==null?(s.return=i,C=s):Wg(t,e,n)}}function Wg(t){for(;C!==null;){var e=C;if(e.flags&8772){var n=e.alternate;try{if(e.flags&8772)switch(e.tag){case 0:case 11:case 15:Fe||ol(5,e);break;case 1:var r=e.stateNode;if(e.flags&4&&!Fe)if(n===null)r.componentDidMount();else{var i=e.elementType===e.type?n.memoizedProps:Pt(e.type,n.memoizedProps);r.componentDidUpdate(i,n.memoizedState,r.__reactInternalSnapshotBeforeUpdate)}var s=e.updateQueue;s!==null&&_g(e,s,r);break;case 3:var o=e.updateQueue;if(o!==null){if(n=null,e.child!==null)switch(e.child.tag){case 5:n=e.child.stateNode;break;case 1:n=e.child.stateNode}_g(e,o,n)}break;case 5:var a=e.stateNode;if(n===null&&e.flags&4){n=a;var l=e.memoizedProps;switch(e.type){case"button":case"input":case"select":case"textarea":l.autoFocus&&n.focus();break;case"img":l.src&&(n.src=l.src)}}break;case 6:break;case 4:break;case 12:break;case 13:if(e.memoizedState===null){var u=e.alternate;if(u!==null){var c=u.memoizedState;if(c!==null){var h=c.dehydrated;h!==null&&Ds(h)}}}break;case 19:case 17:case 21:case 22:case 23:case 25:break;default:throw Error(w(163))}Fe||e.flags&512&&lh(e)}catch(p){ce(e,e.return,p)}}if(e===t){C=null;break}if(n=e.sibling,n!==null){n.return=e.return,C=n;break}C=e.return}}function Gg(t){for(;C!==null;){var e=C;if(e===t){C=null;break}var n=e.sibling;if(n!==null){n.return=e.return,C=n;break}C=e.return}}function Jg(t){for(;C!==null;){var e=C;try{switch(e.tag){case 0:case 11:case 15:var n=e.return;try{ol(4,e)}catch(l){ce(e,n,l)}break;case 1:var r=e.stateNode;if(typeof r.componentDidMount=="function"){var i=e.return;try{r.componentDidMount()}catch(l){ce(e,i,l)}}var s=e.return;try{lh(e)}catch(l){ce(e,s,l)}break;case 5:var o=e.return;try{lh(e)}catch(l){ce(e,o,l)}}}catch(l){ce(e,e.return,l)}if(e===t){C=null;break}var a=e.sibling;if(a!==null){a.return=e.return,C=a;break}C=e.return}}var kE=Math.ceil,Xa=dn.ReactCurrentDispatcher,Wh=dn.ReactCurrentOwner,vt=dn.ReactCurrentBatchConfig,U=0,Ie=null,me=null,_e=0,st=0,ai=Xn(0),ve=0,Bs=null,xr=0,al=0,Gh=0,Es=null,Ye=null,Jh=0,wi=1/0,nn=null,Wa=!1,hh=null,Vn=null,ya=!1,bn=null,Ga=0,Ss=0,dh=null,Ta=-1,Ca=0;function Ge(){return U&6?fe():Ta!==-1?Ta:Ta=fe()}function Un(t){return t.mode&1?U&2&&_e!==0?_e&-_e:cE.transition!==null?(Ca===0&&(Ca=T0()),Ca):(t=W,t!==0||(t=window.event,t=t===void 0?16:O0(t.type)),t):1}function Mt(t,e,n,r){if(50<Ss)throw Ss=0,dh=null,Error(w(185));qs(t,n,r),(!(U&2)||t!==Ie)&&(t===Ie&&(!(U&2)&&(al|=n),ve===4&&Ln(t,_e)),nt(t,r),n===1&&U===0&&!(e.mode&1)&&(wi=fe()+500,rl&&Wn()))}function nt(t,e){var n=t.callbackNode;d5(t,e);var r=Oa(t,t===Ie?_e:0);if(r===0)n!==null&&ig(n),t.callbackNode=null,t.callbackPriority=0;else if(e=r&-r,t.callbackPriority!==e){if(n!=null&&ig(n),e===1)t.tag===0?uE(Zg.bind(null,t)):Z0(Zg.bind(null,t)),sE(function(){!(U&6)&&Wn()}),n=null;else{switch(C0(r)){case 1:n=Sh;break;case 4:n=I0;break;case 16:n=_a;break;case 536870912:n=x0;break;default:n=_a}n=Jy(n,jy.bind(null,t))}t.callbackPriority=e,t.callbackNode=n}}function jy(t,e){if(Ta=-1,Ca=0,U&6)throw Error(w(327));var n=t.callbackNode;if(fi()&&t.callbackNode!==n)return null;var r=Oa(t,t===Ie?_e:0);if(r===0)return null;if(r&30||r&t.expiredLanes||e)e=Ja(t,r);else{e=r;var i=U;U|=2;var s=Hy();(Ie!==t||_e!==e)&&(nn=null,wi=fe()+500,vr(t,e));do try{PE();break}catch(a){Qy(t,a)}while(1);bh(),Xa.current=s,U=i,me!==null?e=0:(Ie=null,_e=0,e=ve)}if(e!==0){if(e===2&&(i=Bc(t),i!==0&&(r=i,e=fh(t,i))),e===1)throw n=Bs,vr(t,0),Ln(t,r),nt(t,fe()),n;if(e===6)Ln(t,r);else{if(i=t.current.alternate,!(r&30)&&!DE(i)&&(e=Ja(t,r),e===2&&(s=Bc(t),s!==0&&(r=s,e=fh(t,s))),e===1))throw n=Bs,vr(t,0),Ln(t,r),nt(t,fe()),n;switch(t.finishedWork=i,t.finishedLanes=r,e){case 0:case 1:throw Error(w(345));case 2:mr(t,Ye,nn);break;case 3:if(Ln(t,r),(r&130023424)===r&&(e=Jh+500-fe(),10<e)){if(Oa(t,0)!==0)break;if(i=t.suspendedLanes,(i&r)!==r){Ge(),t.pingedLanes|=t.suspendedLanes&i;break}t.timeoutHandle=Xc(mr.bind(null,t,Ye,nn),e);break}mr(t,Ye,nn);break;case 4:if(Ln(t,r),(r&4194240)===r)break;for(e=t.eventTimes,i=-1;0<r;){var o=31-Lt(r);s=1<<o,o=e[o],o>i&&(i=o),r&=~s}if(r=i,r=fe()-r,r=(120>r?120:480>r?480:1080>r?1080:1920>r?1920:3e3>r?3e3:4320>r?4320:1960*kE(r/1960))-r,10<r){t.timeoutHandle=Xc(mr.bind(null,t,Ye,nn),r);break}mr(t,Ye,nn);break;case 5:mr(t,Ye,nn);break;default:throw Error(w(329))}}}return nt(t,fe()),t.callbackNode===n?jy.bind(null,t):null}function fh(t,e){var n=Es;return t.current.memoizedState.isDehydrated&&(vr(t,e).flags|=256),t=Ja(t,e),t!==2&&(e=Ye,Ye=n,e!==null&&ph(e)),t}function ph(t){Ye===null?Ye=t:Ye.push.apply(Ye,t)}function DE(t){for(var e=t;;){if(e.flags&16384){var n=e.updateQueue;if(n!==null&&(n=n.stores,n!==null))for(var r=0;r<n.length;r++){var i=n[r],s=i.getSnapshot;i=i.value;try{if(!bt(s(),i))return!1}catch{return!1}}}if(n=e.child,e.subtreeFlags&16384&&n!==null)n.return=e,e=n;else{if(e===t)break;for(;e.sibling===null;){if(e.return===null||e.return===t)return!0;e=e.return}e.sibling.return=e.return,e=e.sibling}}return!0}function Ln(t,e){for(e&=~Gh,e&=~al,t.suspendedLanes|=e,t.pingedLanes&=~e,t=t.expirationTimes;0<e;){var n=31-Lt(e),r=1<<n;t[n]=-1,e&=~r}}function Zg(t){if(U&6)throw Error(w(327));fi();var e=Oa(t,0);if(!(e&1))return nt(t,fe()),null;var n=Ja(t,e);if(t.tag!==0&&n===2){var r=Bc(t);r!==0&&(e=r,n=fh(t,r))}if(n===1)throw n=Bs,vr(t,0),Ln(t,e),nt(t,fe()),n;if(n===6)throw Error(w(345));return t.finishedWork=t.current.alternate,t.finishedLanes=e,mr(t,Ye,nn),nt(t,fe()),null}function Zh(t,e){var n=U;U|=1;try{return t(e)}finally{U=n,U===0&&(wi=fe()+500,rl&&Wn())}}function Tr(t){bn!==null&&bn.tag===0&&!(U&6)&&fi();var e=U;U|=1;var n=vt.transition,r=W;try{if(vt.transition=null,W=1,t)return t()}finally{W=r,vt.transition=n,U=e,!(U&6)&&Wn()}}function Yh(){st=ai.current,ee(ai)}function vr(t,e){t.finishedWork=null,t.finishedLanes=0;var n=t.timeoutHandle;if(n!==-1&&(t.timeoutHandle=-1,iE(n)),me!==null)for(n=me.return;n!==null;){var r=n;switch(Oh(r),r.tag){case 1:r=r.type.childContextTypes,r!=null&&za();break;case 3:Ai(),ee(et),ee(Be),Vh();break;case 5:qh(r);break;case 4:Ai();break;case 13:ee(ae);break;case 19:ee(ae);break;case 10:Rh(r.type._context);break;case 22:case 23:Yh()}n=n.return}if(Ie=t,me=t=jn(t.current,null),_e=st=e,ve=0,Bs=null,Gh=al=xr=0,Ye=Es=null,yr!==null){for(e=0;e<yr.length;e++)if(n=yr[e],r=n.interleaved,r!==null){n.interleaved=null;var i=r.next,s=n.pending;if(s!==null){var o=s.next;s.next=i,r.next=o}n.pending=r}yr=null}return t}function Qy(t,e){do{var n=me;try{if(bh(),Sa.current=Ka,Ha){for(var r=le.memoizedState;r!==null;){var i=r.queue;i!==null&&(i.pending=null),r=r.next}Ha=!1}if(Ir=0,Se=Ae=le=null,vs=!1,Rs=0,Wh.current=null,n===null||n.return===null){ve=1,Bs=e,me=null;break}e:{var s=t,o=n.return,a=n,l=e;if(e=_e,a.flags|=32768,l!==null&&typeof l=="object"&&typeof l.then=="function"){var u=l,c=a,h=c.tag;if(!(c.mode&1)&&(h===0||h===11||h===15)){var p=c.alternate;p?(c.updateQueue=p.updateQueue,c.memoizedState=p.memoizedState,c.lanes=p.lanes):(c.updateQueue=null,c.memoizedState=null)}var g=Fg(o);if(g!==null){g.flags&=-257,Bg(g,o,a,s,e),g.mode&1&&zg(s,u,e),e=g,l=u;var y=e.updateQueue;if(y===null){var A=new Set;A.add(l),e.updateQueue=A}else y.add(l);break e}else{if(!(e&1)){zg(s,u,e),$h();break e}l=Error(w(426))}}else if(ne&&a.mode&1){var P=Fg(o);if(P!==null){!(P.flags&65536)&&(P.flags|=256),Bg(P,o,a,s,e),Lh(vi(l,a));break e}}s=l=vi(l,a),ve!==4&&(ve=2),Es===null?Es=[s]:Es.push(s),s=o;do{switch(s.tag){case 3:s.flags|=65536,e&=-e,s.lanes|=e;var f=ky(s,l,e);Pg(s,f);break e;case 1:a=l;var d=s.type,m=s.stateNode;if(!(s.flags&128)&&(typeof d.getDerivedStateFromError=="function"||m!==null&&typeof m.componentDidCatch=="function"&&(Vn===null||!Vn.has(m)))){s.flags|=65536,e&=-e,s.lanes|=e;var v=Dy(s,a,e);Pg(s,v);break e}}s=s.return}while(s!==null)}Xy(n)}catch(S){e=S,me===n&&n!==null&&(me=n=n.return);continue}break}while(1)}function Hy(){var t=Xa.current;return Xa.current=Ka,t===null?Ka:t}function $h(){(ve===0||ve===3||ve===2)&&(ve=4),Ie===null||!(xr&268435455)&&!(al&268435455)||Ln(Ie,_e)}function Ja(t,e){var n=U;U|=2;var r=Hy();(Ie!==t||_e!==e)&&(nn=null,vr(t,e));do try{NE();break}catch(i){Qy(t,i)}while(1);if(bh(),U=n,Xa.current=r,me!==null)throw Error(w(261));return Ie=null,_e=0,ve}function NE(){for(;me!==null;)Ky(me)}function PE(){for(;me!==null&&!r5();)Ky(me)}function Ky(t){var e=Gy(t.alternate,t,st);t.memoizedProps=t.pendingProps,e===null?Xy(t):me=e,Wh.current=null}function Xy(t){var e=t;do{var n=e.alternate;if(t=e.return,e.flags&32768){if(n=IE(n,e),n!==null){n.flags&=32767,me=n;return}if(t!==null)t.flags|=32768,t.subtreeFlags=0,t.deletions=null;else{ve=6,me=null;return}}else if(n=SE(n,e,st),n!==null){me=n;return}if(e=e.sibling,e!==null){me=e;return}me=e=t}while(e!==null);ve===0&&(ve=5)}function mr(t,e,n){var r=W,i=vt.transition;try{vt.transition=null,W=1,_E(t,e,n,r)}finally{vt.transition=i,W=r}return null}function _E(t,e,n,r){do fi();while(bn!==null);if(U&6)throw Error(w(327));n=t.finishedWork;var i=t.finishedLanes;if(n===null)return null;if(t.finishedWork=null,t.finishedLanes=0,n===t.current)throw Error(w(177));t.callbackNode=null,t.callbackPriority=0;var s=n.lanes|n.childLanes;if(f5(t,s),t===Ie&&(me=Ie=null,_e=0),!(n.subtreeFlags&2064)&&!(n.flags&2064)||ya||(ya=!0,Jy(_a,function(){return fi(),null})),s=(n.flags&15990)!==0,n.subtreeFlags&15990||s){s=vt.transition,vt.transition=null;var o=W;W=1;var a=U;U|=4,Wh.current=null,TE(t,n),Vy(n,t),$5(Hc),La=!!Qc,Hc=Qc=null,t.current=n,CE(n,t,i),i5(),U=a,W=o,vt.transition=s}else t.current=n;if(ya&&(ya=!1,bn=t,Ga=i),s=t.pendingLanes,s===0&&(Vn=null),a5(n.stateNode,r),nt(t,fe()),e!==null)for(r=t.onRecoverableError,n=0;n<e.length;n++)i=e[n],r(i.value,{componentStack:i.stack,digest:i.digest});if(Wa)throw Wa=!1,t=hh,hh=null,t;return Ga&1&&t.tag!==0&&fi(),s=t.pendingLanes,s&1?t===dh?Ss++:(Ss=0,dh=t):Ss=0,Wn(),null}function fi(){if(bn!==null){var t=C0(Ga),e=vt.transition,n=W;try{if(vt.transition=null,W=16>t?16:t,bn===null)var r=!1;else{if(t=bn,bn=null,Ga=0,U&6)throw Error(w(331));var i=U;for(U|=4,C=t.current;C!==null;){var s=C,o=s.child;if(C.flags&16){var a=s.deletions;if(a!==null){for(var l=0;l<a.length;l++){var u=a[l];for(C=u;C!==null;){var c=C;switch(c.tag){case 0:case 11:case 15:ws(8,c,s)}var h=c.child;if(h!==null)h.return=c,C=h;else for(;C!==null;){c=C;var p=c.sibling,g=c.return;if(Fy(c),c===u){C=null;break}if(p!==null){p.return=g,C=p;break}C=g}}}var y=s.alternate;if(y!==null){var A=y.child;if(A!==null){y.child=null;do{var P=A.sibling;A.sibling=null,A=P}while(A!==null)}}C=s}}if(s.subtreeFlags&2064&&o!==null)o.return=s,C=o;else e:for(;C!==null;){if(s=C,s.flags&2048)switch(s.tag){case 0:case 11:case 15:ws(9,s,s.return)}var f=s.sibling;if(f!==null){f.return=s.return,C=f;break e}C=s.return}}var d=t.current;for(C=d;C!==null;){o=C;var m=o.child;if(o.subtreeFlags&2064&&m!==null)m.return=o,C=m;else e:for(o=d;C!==null;){if(a=C,a.flags&2048)try{switch(a.tag){case 0:case 11:case 15:ol(9,a)}}catch(S){ce(a,a.return,S)}if(a===o){C=null;break e}var v=a.sibling;if(v!==null){v.return=a.return,C=v;break e}C=a.return}}if(U=i,Wn(),Ht&&typeof Ht.onPostCommitFiberRoot=="function")try{Ht.onPostCommitFiberRoot(Ya,t)}catch{}r=!0}return r}finally{W=n,vt.transition=e}}return!1}function Yg(t,e,n){e=vi(n,e),e=ky(t,e,1),t=qn(t,e,1),e=Ge(),t!==null&&(qs(t,1,e),nt(t,e))}function ce(t,e,n){if(t.tag===3)Yg(t,t,n);else for(;e!==null;){if(e.tag===3){Yg(e,t,n);break}else if(e.tag===1){var r=e.stateNode;if(typeof e.type.getDerivedStateFromError=="function"||typeof r.componentDidCatch=="function"&&(Vn===null||!Vn.has(r))){t=vi(n,t),t=Dy(e,t,1),e=qn(e,t,1),t=Ge(),e!==null&&(qs(e,1,t),nt(e,t));break}}e=e.return}}function OE(t,e,n){var r=t.pingCache;r!==null&&r.delete(e),e=Ge(),t.pingedLanes|=t.suspendedLanes&n,Ie===t&&(_e&n)===n&&(ve===4||ve===3&&(_e&130023424)===_e&&500>fe()-Jh?vr(t,0):Gh|=n),nt(t,e)}function Wy(t,e){e===0&&(t.mode&1?(e=ra,ra<<=1,!(ra&130023424)&&(ra=4194304)):e=1);var n=Ge();t=cn(t,e),t!==null&&(qs(t,e,n),nt(t,n))}function LE(t){var e=t.memoizedState,n=0;e!==null&&(n=e.retryLane),Wy(t,n)}function ME(t,e){var n=0;switch(t.tag){case 13:var r=t.stateNode,i=t.memoizedState;i!==null&&(n=i.retryLane);break;case 19:r=t.stateNode;break;default:throw Error(w(314))}r!==null&&r.delete(e),Wy(t,n)}var Gy;Gy=function(t,e,n){if(t!==null)if(t.memoizedProps!==e.pendingProps||et.current)$e=!0;else{if(!(t.lanes&n)&&!(e.flags&128))return $e=!1,EE(t,e,n);$e=!!(t.flags&131072)}else $e=!1,ne&&e.flags&1048576&&Y0(e,qa,e.index);switch(e.lanes=0,e.tag){case 2:var r=e.type;xa(t,e),t=e.pendingProps;var i=mi(e,Be.current);di(e,n),i=jh(null,e,r,t,i,n);var s=Qh();return e.flags|=1,typeof i=="object"&&i!==null&&typeof i.render=="function"&&i.$$typeof===void 0?(e.tag=1,e.memoizedState=null,e.updateQueue=null,tt(r)?(s=!0,Fa(e)):s=!1,e.memoizedState=i.state!==null&&i.state!==void 0?i.state:null,Fh(e),i.updater=il,e.stateNode=i,i._reactInternals=e,eh(e,r,t,n),e=rh(null,e,r,!0,s,n)):(e.tag=0,ne&&s&&_h(e),We(null,e,i,n),e=e.child),e;case 16:r=e.elementType;e:{switch(xa(t,e),t=e.pendingProps,i=r._init,r=i(r._payload),e.type=r,i=e.tag=RE(r),t=Pt(r,t),i){case 0:e=nh(null,e,r,t,n);break e;case 1:e=Ug(null,e,r,t,n);break e;case 11:e=qg(null,e,r,t,n);break e;case 14:e=Vg(null,e,r,Pt(r.type,t),n);break e}throw Error(w(306,r,""))}return e;case 0:return r=e.type,i=e.pendingProps,i=e.elementType===r?i:Pt(r,i),nh(t,e,r,i,n);case 1:return r=e.type,i=e.pendingProps,i=e.elementType===r?i:Pt(r,i),Ug(t,e,r,i,n);case 3:e:{if(Oy(e),t===null)throw Error(w(387));r=e.pendingProps,s=e.memoizedState,i=s.element,ny(t,e),ja(e,r,null,n);var o=e.memoizedState;if(r=o.element,s.isDehydrated)if(s={element:r,isDehydrated:!1,cache:o.cache,pendingSuspenseBoundaries:o.pendingSuspenseBoundaries,transitions:o.transitions},e.updateQueue.baseState=s,e.memoizedState=s,e.flags&256){i=vi(Error(w(423)),e),e=jg(t,e,r,n,i);break e}else if(r!==i){i=vi(Error(w(424)),e),e=jg(t,e,r,n,i);break e}else for(ot=Bn(e.stateNode.containerInfo.firstChild),at=e,ne=!0,Ot=null,n=oy(e,null,r,n),e.child=n;n;)n.flags=n.flags&-3|4096,n=n.sibling;else{if(gi(),r===i){e=hn(t,e,n);break e}We(t,e,r,n)}e=e.child}return e;case 5:return ay(e),t===null&&Zc(e),r=e.type,i=e.pendingProps,s=t!==null?t.memoizedProps:null,o=i.children,Kc(r,i)?o=null:s!==null&&Kc(r,s)&&(e.flags|=32),_y(t,e),We(t,e,o,n),e.child;case 6:return t===null&&Zc(e),null;case 13:return Ly(t,e,n);case 4:return Bh(e,e.stateNode.containerInfo),r=e.pendingProps,t===null?e.child=yi(e,null,r,n):We(t,e,r,n),e.child;case 11:return r=e.type,i=e.pendingProps,i=e.elementType===r?i:Pt(r,i),qg(t,e,r,i,n);case 7:return We(t,e,e.pendingProps,n),e.child;case 8:return We(t,e,e.pendingProps.children,n),e.child;case 12:return We(t,e,e.pendingProps.children,n),e.child;case 10:e:{if(r=e.type._context,i=e.pendingProps,s=e.memoizedProps,o=i.value,Y(Va,r._currentValue),r._currentValue=o,s!==null)if(bt(s.value,o)){if(s.children===i.children&&!et.current){e=hn(t,e,n);break e}}else for(s=e.child,s!==null&&(s.return=e);s!==null;){var a=s.dependencies;if(a!==null){o=s.child;for(var l=a.firstContext;l!==null;){if(l.context===r){if(s.tag===1){l=an(-1,n&-n),l.tag=2;var u=s.updateQueue;if(u!==null){u=u.shared;var c=u.pending;c===null?l.next=l:(l.next=c.next,c.next=l),u.pending=l}}s.lanes|=n,l=s.alternate,l!==null&&(l.lanes|=n),Yc(s.return,n,e),a.lanes|=n;break}l=l.next}}else if(s.tag===10)o=s.type===e.type?null:s.child;else if(s.tag===18){if(o=s.return,o===null)throw Error(w(341));o.lanes|=n,a=o.alternate,a!==null&&(a.lanes|=n),Yc(o,n,e),o=s.sibling}else o=s.child;if(o!==null)o.return=s;else for(o=s;o!==null;){if(o===e){o=null;break}if(s=o.sibling,s!==null){s.return=o.return,o=s;break}o=o.return}s=o}We(t,e,i.children,n),e=e.child}return e;case 9:return i=e.type,r=e.pendingProps.children,di(e,n),i=wt(i),r=r(i),e.flags|=1,We(t,e,r,n),e.child;case 14:return r=e.type,i=Pt(r,e.pendingProps),i=Pt(r.type,i),Vg(t,e,r,i,n);case 15:return Ny(t,e,e.type,e.pendingProps,n);case 17:return r=e.type,i=e.pendingProps,i=e.elementType===r?i:Pt(r,i),xa(t,e),e.tag=1,tt(r)?(t=!0,Fa(e)):t=!1,di(e,n),iy(e,r,i),eh(e,r,i,n),rh(null,e,r,!0,t,n);case 19:return My(t,e,n);case 22:return Py(t,e,n)}throw Error(w(156,e.tag))};function Jy(t,e){return S0(t,e)}function bE(t,e,n,r){this.tag=t,this.key=n,this.sibling=this.child=this.return=this.stateNode=this.type=this.elementType=null,this.index=0,this.ref=null,this.pendingProps=e,this.dependencies=this.memoizedState=this.updateQueue=this.memoizedProps=null,this.mode=r,this.subtreeFlags=this.flags=0,this.deletions=null,this.childLanes=this.lanes=0,this.alternate=null}function At(t,e,n,r){return new bE(t,e,n,r)}function ed(t){return t=t.prototype,!(!t||!t.isReactComponent)}function RE(t){if(typeof t=="function")return ed(t)?1:0;if(t!=null){if(t=t.$$typeof,t===vh)return 11;if(t===wh)return 14}return 2}function jn(t,e){var n=t.alternate;return n===null?(n=At(t.tag,e,t.key,t.mode),n.elementType=t.elementType,n.type=t.type,n.stateNode=t.stateNode,n.alternate=t,t.alternate=n):(n.pendingProps=e,n.type=t.type,n.flags=0,n.subtreeFlags=0,n.deletions=null),n.flags=t.flags&14680064,n.childLanes=t.childLanes,n.lanes=t.lanes,n.child=t.child,n.memoizedProps=t.memoizedProps,n.memoizedState=t.memoizedState,n.updateQueue=t.updateQueue,e=t.dependencies,n.dependencies=e===null?null:{lanes:e.lanes,firstContext:e.firstContext},n.sibling=t.sibling,n.index=t.index,n.ref=t.ref,n}function ka(t,e,n,r,i,s){var o=2;if(r=t,typeof t=="function")ed(t)&&(o=1);else if(typeof t=="string")o=5;else e:switch(t){case Zr:return wr(n.children,i,s,e);case Ah:o=8,i|=8;break;case xc:return t=At(12,n,e,i|2),t.elementType=xc,t.lanes=s,t;case Tc:return t=At(13,n,e,i),t.elementType=Tc,t.lanes=s,t;case Cc:return t=At(19,n,e,i),t.elementType=Cc,t.lanes=s,t;case s0:return ll(n,i,s,e);default:if(typeof t=="object"&&t!==null)switch(t.$$typeof){case r0:o=10;break e;case i0:o=9;break e;case vh:o=11;break e;case wh:o=14;break e;case Pn:o=16,r=null;break e}throw Error(w(130,t==null?t:typeof t,""))}return e=At(o,n,e,i),e.elementType=t,e.type=r,e.lanes=s,e}function wr(t,e,n,r){return t=At(7,t,r,e),t.lanes=n,t}function ll(t,e,n,r){return t=At(22,t,r,e),t.elementType=s0,t.lanes=n,t.stateNode={isHidden:!1},t}function Ec(t,e,n){return t=At(6,t,null,e),t.lanes=n,t}function Sc(t,e,n){return e=At(4,t.children!==null?t.children:[],t.key,e),e.lanes=n,e.stateNode={containerInfo:t.containerInfo,pendingChildren:null,implementation:t.implementation},e}function zE(t,e,n,r,i){this.tag=e,this.containerInfo=t,this.finishedWork=this.pingCache=this.current=this.pendingChildren=null,this.timeoutHandle=-1,this.callbackNode=this.pendingContext=this.context=null,this.callbackPriority=0,this.eventTimes=sc(0),this.expirationTimes=sc(-1),this.entangledLanes=this.finishedLanes=this.mutableReadLanes=this.expiredLanes=this.pingedLanes=this.suspendedLanes=this.pendingLanes=0,this.entanglements=sc(0),this.identifierPrefix=r,this.onRecoverableError=i,this.mutableSourceEagerHydrationData=null}function td(t,e,n,r,i,s,o,a,l){return t=new zE(t,e,n,a,l),e===1?(e=1,s===!0&&(e|=8)):e=0,s=At(3,null,null,e),t.current=s,s.stateNode=t,s.memoizedState={element:r,isDehydrated:n,cache:null,transitions:null,pendingSuspenseBoundaries:null},Fh(s),t}function FE(t,e,n){var r=3<arguments.length&&arguments[3]!==void 0?arguments[3]:null;return{$$typeof:Jr,key:r==null?null:""+r,children:t,containerInfo:e,implementation:n}}function Zy(t){if(!t)return Hn;t=t._reactInternals;e:{if(kr(t)!==t||t.tag!==1)throw Error(w(170));var e=t;do{switch(e.tag){case 3:e=e.stateNode.context;break e;case 1:if(tt(e.type)){e=e.stateNode.__reactInternalMemoizedMergedChildContext;break e}}e=e.return}while(e!==null);throw Error(w(171))}if(t.tag===1){var n=t.type;if(tt(n))return J0(t,n,e)}return e}function Yy(t,e,n,r,i,s,o,a,l){return t=td(n,r,!0,t,i,s,o,a,l),t.context=Zy(null),n=t.current,r=Ge(),i=Un(n),s=an(r,i),s.callback=e??null,qn(n,s,i),t.current.lanes=i,qs(t,i,r),nt(t,r),t}function ul(t,e,n,r){var i=e.current,s=Ge(),o=Un(i);return n=Zy(n),e.context===null?e.context=n:e.pendingContext=n,e=an(s,o),e.payload={element:t},r=r===void 0?null:r,r!==null&&(e.callback=r),t=qn(i,e,o),t!==null&&(Mt(t,i,o,s),Ea(t,i,o)),o}function Za(t){if(t=t.current,!t.child)return null;switch(t.child.tag){case 5:return t.child.stateNode;default:return t.child.stateNode}}function $g(t,e){if(t=t.memoizedState,t!==null&&t.dehydrated!==null){var n=t.retryLane;t.retryLane=n!==0&&n<e?n:e}}function nd(t,e){$g(t,e),(t=t.alternate)&&$g(t,e)}function BE(){return null}var $y=typeof reportError=="function"?reportError:function(t){console.error(t)};function rd(t){this._internalRoot=t}cl.prototype.render=rd.prototype.render=function(t){var e=this._internalRoot;if(e===null)throw Error(w(409));ul(t,e,null,null)};cl.prototype.unmount=rd.prototype.unmount=function(){var t=this._internalRoot;if(t!==null){this._internalRoot=null;var e=t.containerInfo;Tr(function(){ul(null,t,null,null)}),e[un]=null}};function cl(t){this._internalRoot=t}cl.prototype.unstable_scheduleHydration=function(t){if(t){var e=N0();t={blockedOn:null,target:t,priority:e};for(var n=0;n<On.length&&e!==0&&e<On[n].priority;n++);On.splice(n,0,t),n===0&&_0(t)}};function id(t){return!(!t||t.nodeType!==1&&t.nodeType!==9&&t.nodeType!==11)}function hl(t){return!(!t||t.nodeType!==1&&t.nodeType!==9&&t.nodeType!==11&&(t.nodeType!==8||t.nodeValue!==" react-mount-point-unstable "))}function e0(){}function qE(t,e,n,r,i){if(i){if(typeof r=="function"){var s=r;r=function(){var u=Za(o);s.call(u)}}var o=Yy(e,r,t,0,null,!1,!1,"",e0);return t._reactRootContainer=o,t[un]=o.current,_s(t.nodeType===8?t.parentNode:t),Tr(),o}for(;i=t.lastChild;)t.removeChild(i);if(typeof r=="function"){var a=r;r=function(){var u=Za(l);a.call(u)}}var l=td(t,0,!1,null,null,!1,!1,"",e0);return t._reactRootContainer=l,t[un]=l.current,_s(t.nodeType===8?t.parentNode:t),Tr(function(){ul(e,l,n,r)}),l}function dl(t,e,n,r,i){var s=n._reactRootContainer;if(s){var o=s;if(typeof i=="function"){var a=i;i=function(){var l=Za(o);a.call(l)}}ul(e,o,t,i)}else o=qE(n,e,t,i,r);return Za(o)}k0=function(t){switch(t.tag){case 3:var e=t.stateNode;if(e.current.memoizedState.isDehydrated){var n=ds(e.pendingLanes);n!==0&&(Ih(e,n|1),nt(e,fe()),!(U&6)&&(wi=fe()+500,Wn()))}break;case 13:Tr(function(){var r=cn(t,1);if(r!==null){var i=Ge();Mt(r,t,1,i)}}),nd(t,1)}};xh=function(t){if(t.tag===13){var e=cn(t,134217728);if(e!==null){var n=Ge();Mt(e,t,134217728,n)}nd(t,134217728)}};D0=function(t){if(t.tag===13){var e=Un(t),n=cn(t,e);if(n!==null){var r=Ge();Mt(n,t,e,r)}nd(t,e)}};N0=function(){return W};P0=function(t,e){var n=W;try{return W=t,e()}finally{W=n}};Rc=function(t,e,n){switch(e){case"input":if(Nc(t,n),e=n.name,n.type==="radio"&&e!=null){for(n=t;n.parentNode;)n=n.parentNode;for(n=n.querySelectorAll("input[name="+JSON.stringify(""+e)+'][type="radio"]'),e=0;e<n.length;e++){var r=n[e];if(r!==t&&r.form===t.form){var i=nl(r);if(!i)throw Error(w(90));a0(r),Nc(r,i)}}}break;case"textarea":u0(t,n);break;case"select":e=n.value,e!=null&&li(t,!!n.multiple,e,!1)}};g0=Zh;y0=Tr;var VE={usingClientEntryPoint:!1,Events:[Us,ti,nl,p0,m0,Zh]},ls={findFiberByHostInstance:gr,bundleType:0,version:"18.2.0",rendererPackageName:"react-dom"},UE={bundleType:ls.bundleType,version:ls.version,rendererPackageName:ls.rendererPackageName,rendererConfig:ls.rendererConfig,overrideHookState:null,overrideHookStateDeletePath:null,overrideHookStateRenamePath:null,overrideProps:null,overridePropsDeletePath:null,overridePropsRenamePath:null,setErrorHandler:null,setSuspenseHandler:null,scheduleUpdate:null,currentDispatcherRef:dn.ReactCurrentDispatcher,findHostInstanceByFiber:function(t){return t=w0(t),t===null?null:t.stateNode},findFiberByHostInstance:ls.findFiberByHostInstance||BE,findHostInstancesForRefresh:null,scheduleRefresh:null,scheduleRoot:null,setRefreshHandler:null,getCurrentFiber:null,reconcilerVersion:"18.2.0-next-9e3b772b8-20220608"};if(typeof __REACT_DEVTOOLS_GLOBAL_HOOK__<"u"&&(us=__REACT_DEVTOOLS_GLOBAL_HOOK__,!us.isDisabled&&us.supportsFiber))try{Ya=us.inject(UE),Ht=us}catch{}var us;ct.__SECRET_INTERNALS_DO_NOT_USE_OR_YOU_WILL_BE_FIRED=VE;ct.createPortal=function(t,e){var n=2<arguments.length&&arguments[2]!==void 0?arguments[2]:null;if(!id(e))throw Error(w(200));return FE(t,e,null,n)};ct.createRoot=function(t,e){if(!id(t))throw Error(w(299));var n=!1,r="",i=$y;return e!=null&&(e.unstable_strictMode===!0&&(n=!0),e.identifierPrefix!==void 0&&(r=e.identifierPrefix),e.onRecoverableError!==void 0&&(i=e.onRecoverableError)),e=td(t,1,!1,null,null,n,!1,r,i),t[un]=e.current,_s(t.nodeType===8?t.parentNode:t),new rd(e)};ct.findDOMNode=function(t){if(t==null)return null;if(t.nodeType===1)return t;var e=t._reactInternals;if(e===void 0)throw typeof t.render=="function"?Error(w(188)):(t=Object.keys(t).join(","),Error(w(268,t)));return t=w0(e),t=t===null?null:t.stateNode,t};ct.flushSync=function(t){return Tr(t)};ct.hydrate=function(t,e,n){if(!hl(e))throw Error(w(200));return dl(null,t,e,!0,n)};ct.hydrateRoot=function(t,e,n){if(!id(t))throw Error(w(405));var r=n!=null&&n.hydratedSources||null,i=!1,s="",o=$y;if(n!=null&&(n.unstable_strictMode===!0&&(i=!0),n.identifierPrefix!==void 0&&(s=n.identifierPrefix),n.onRecoverableError!==void 0&&(o=n.onRecoverableError)),e=Yy(e,null,t,1,n??null,i,!1,s,o),t[un]=e.current,_s(t),r)for(t=0;t<r.length;t++)n=r[t],i=n._getVersion,i=i(n._source),e.mutableSourceEagerHydrationData==null?e.mutableSourceEagerHydrationData=[n,i]:e.mutableSourceEagerHydrationData.push(n,i);return new cl(e)};ct.render=function(t,e,n){if(!hl(e))throw Error(w(200));return dl(null,t,e,!1,n)};ct.unmountComponentAtNode=function(t){if(!hl(t))throw Error(w(40));return t._reactRootContainer?(Tr(function(){dl(null,null,t,!1,function(){t._reactRootContainer=null,t[un]=null})}),!0):!1};ct.unstable_batchedUpdates=Zh;ct.unstable_renderSubtreeIntoContainer=function(t,e,n,r){if(!hl(n))throw Error(w(200));if(t==null||t._reactInternals===void 0)throw Error(w(38));return dl(t,e,n,!1,r)};ct.version="18.2.0-next-9e3b772b8-20220608"});var r1=kt((qx,n1)=>{"use strict";function t1(){if(!(typeof __REACT_DEVTOOLS_GLOBAL_HOOK__>"u"||typeof __REACT_DEVTOOLS_GLOBAL_HOOK__.checkDCE!="function"))try{__REACT_DEVTOOLS_GLOBAL_HOOK__.checkDCE(t1)}catch(t){console.error(t)}}t1(),n1.exports=e1()});var s1=kt(sd=>{"use strict";var i1=r1();sd.createRoot=i1.createRoot,sd.hydrateRoot=i1.hydrateRoot;var Vx});var Hs=kt((Xx,Al)=>{(function(){"use strict";var t={}.hasOwnProperty,e="[native code]";function n(){for(var r=[],i=0;i<arguments.length;i++){var s=arguments[i];if(s){var o=typeof s;if(o==="string"||o==="number")r.push(s);else if(Array.isArray(s)){if(s.length){var a=n.apply(null,s);a&&r.push(a)}}else if(o==="object"){if(s.toString!==Object.prototype.toString&&!s.toString.toString().includes("[native code]")){r.push(s.toString());continue}for(var l in s)t.call(s,l)&&s[l]&&r.push(l)}}}return r.join(" ")}typeof Al<"u"&&Al.exports?(n.default=n,Al.exports=n):typeof define=="function"&&typeof define.amd=="object"&&define.amd?define("classnames",[],function(){return n}):window.classNames=n})()});var E1=kt(vl=>{"use strict";var xS=it(),TS=Symbol.for("react.element"),CS=Symbol.for("react.fragment"),kS=Object.prototype.hasOwnProperty,DS=xS.__SECRET_INTERNALS_DO_NOT_USE_OR_YOU_WILL_BE_FIRED.ReactCurrentOwner,NS={key:!0,ref:!0,__self:!0,__source:!0};function w1(t,e,n){var r,i={},s=null,o=null;n!==void 0&&(s=""+n),e.key!==void 0&&(s=""+e.key),e.ref!==void 0&&(o=e.ref);for(r in e)kS.call(e,r)&&!NS.hasOwnProperty(r)&&(i[r]=e[r]);if(t&&t.defaultProps)for(r in e=t.defaultProps,e)i[r]===void 0&&(i[r]=e[r]);return{$$typeof:TS,type:t,key:s,ref:o,props:i,_owner:DS.current}}vl.Fragment=CS;vl.jsx=w1;vl.jsxs=w1});var te=kt((Jx,S1)=>{"use strict";S1.exports=E1()});var M1=kt((lT,El)=>{(function(){"use strict";var t={}.hasOwnProperty;function e(){for(var n=[],r=0;r<arguments.length;r++){var i=arguments[r];if(i){var s=typeof i;if(s==="string"||s==="number")n.push(this&&this[i]||i);else if(Array.isArray(i))n.push(e.apply(this,i));else if(s==="object"){if(i.toString!==Object.prototype.toString&&!i.toString.toString().includes("[native code]")){n.push(i.toString());continue}for(var o in i)t.call(i,o)&&i[o]&&n.push(this&&this[o]||o)}}}return n.join(" ")}typeof El<"u"&&El.exports?(e.default=e,El.exports=e):typeof define=="function"&&typeof define.amd=="object"&&define.amd?define("classnames",[],function(){return e}):window.classNames=e})()});var A2=F(it()),v2=F(s1());var dr=F(it());var o1="2a7c91bdda0b58637eedce7fd0d7146cf1d7b086b9ac9d7d595f90f5709e9fa9",jE={logo:"_logo_v7atj_1",container:"_container_v7atj_5",menu:"_menu_v7atj_9"},QE=`._logo_v7atj_1 {
  padding: 10px;
}

._container_v7atj_5 {
  margin: 20px;
}

._menu_v7atj_9 {
  position: relative;
  border-right: 3px solid var(--light-1);
  display: flex;
  flex-direction: column;
}`;(function(){if(typeof document<"u"&&!document.getElementById(o1)){var t=document.createElement("style");t.id=o1,t.textContent=QE,document.head.appendChild(t)}})();var od=jE;function fn(t){return Array.isArray?Array.isArray(t):p1(t)==="[object Array]"}var HE=1/0;function KE(t){if(typeof t=="string")return t;let e=t+"";return e=="0"&&1/t==-HE?"-0":e}function XE(t){return t==null?"":KE(t)}function Xt(t){return typeof t=="string"}function d1(t){return typeof t=="number"}function WE(t){return t===!0||t===!1||GE(t)&&p1(t)=="[object Boolean]"}function f1(t){return typeof t=="object"}function GE(t){return f1(t)&&t!==null}function ht(t){return t!=null}function ad(t){return!t.trim().length}function p1(t){return t==null?t===void 0?"[object Undefined]":"[object Null]":Object.prototype.toString.call(t)}var JE="Incorrect 'index' type",ZE=t=>`Invalid value for key ${t}`,YE=t=>`Pattern length exceeds max of ${t}.`,$E=t=>`Missing ${t} property in key`,eS=t=>`Property 'weight' in key '${t}' must be a positive integer`,a1=Object.prototype.hasOwnProperty,ld=class{constructor(e){this._keys=[],this._keyMap={};let n=0;e.forEach(r=>{let i=m1(r);n+=i.weight,this._keys.push(i),this._keyMap[i.id]=i,n+=i.weight}),this._keys.forEach(r=>{r.weight/=n})}get(e){return this._keyMap[e]}keys(){return this._keys}toJSON(){return JSON.stringify(this._keys)}};function m1(t){let e=null,n=null,r=null,i=1,s=null;if(Xt(t)||fn(t))r=t,e=l1(t),n=ud(t);else{if(!a1.call(t,"name"))throw new Error($E("name"));let o=t.name;if(r=o,a1.call(t,"weight")&&(i=t.weight,i<=0))throw new Error(eS(o));e=l1(o),n=ud(o),s=t.getFn}return{path:e,id:n,weight:i,src:r,getFn:s}}function l1(t){return fn(t)?t:t.split(".")}function ud(t){return fn(t)?t.join("."):t}function tS(t,e){let n=[],r=!1,i=(s,o,a)=>{if(ht(s))if(!o[a])n.push(s);else{let l=o[a],u=s[l];if(!ht(u))return;if(a===o.length-1&&(Xt(u)||d1(u)||WE(u)))n.push(XE(u));else if(fn(u)){r=!0;for(let c=0,h=u.length;c<h;c+=1)i(u[c],o,a+1)}else o.length&&i(u,o,a+1)}};return i(t,Xt(e)?e.split("."):e,0),r?n:n[0]}var nS={includeMatches:!1,findAllMatches:!1,minMatchCharLength:1},rS={isCaseSensitive:!1,includeScore:!1,keys:[],shouldSort:!0,sortFn:(t,e)=>t.score===e.score?t.idx<e.idx?-1:1:t.score<e.score?-1:1},iS={location:0,threshold:.6,distance:100},sS={useExtendedSearch:!1,getFn:tS,ignoreLocation:!1,ignoreFieldNorm:!1,fieldNormWeight:1},M={...rS,...nS,...iS,...sS},oS=/[^ ]+/g;function aS(t=1,e=3){let n=new Map,r=Math.pow(10,e);return{get(i){let s=i.match(oS).length;if(n.has(s))return n.get(s);let o=1/Math.pow(s,.5*t),a=parseFloat(Math.round(o*r)/r);return n.set(s,a),a},clear(){n.clear()}}}var Qs=class{constructor({getFn:e=M.getFn,fieldNormWeight:n=M.fieldNormWeight}={}){this.norm=aS(n,3),this.getFn=e,this.isCreated=!1,this.setIndexRecords()}setSources(e=[]){this.docs=e}setIndexRecords(e=[]){this.records=e}setKeys(e=[]){this.keys=e,this._keysMap={},e.forEach((n,r)=>{this._keysMap[n.id]=r})}create(){this.isCreated||!this.docs.length||(this.isCreated=!0,Xt(this.docs[0])?this.docs.forEach((e,n)=>{this._addString(e,n)}):this.docs.forEach((e,n)=>{this._addObject(e,n)}),this.norm.clear())}add(e){let n=this.size();Xt(e)?this._addString(e,n):this._addObject(e,n)}removeAt(e){this.records.splice(e,1);for(let n=e,r=this.size();n<r;n+=1)this.records[n].i-=1}getValueForItemAtKeyId(e,n){return e[this._keysMap[n]]}size(){return this.records.length}_addString(e,n){if(!ht(e)||ad(e))return;let r={v:e,i:n,n:this.norm.get(e)};this.records.push(r)}_addObject(e,n){let r={i:n,$:{}};this.keys.forEach((i,s)=>{let o=i.getFn?i.getFn(e):this.getFn(e,i.path);if(ht(o)){if(fn(o)){let a=[],l=[{nestedArrIndex:-1,value:o}];for(;l.length;){let{nestedArrIndex:u,value:c}=l.pop();if(ht(c))if(Xt(c)&&!ad(c)){let h={v:c,i:u,n:this.norm.get(c)};a.push(h)}else fn(c)&&c.forEach((h,p)=>{l.push({nestedArrIndex:p,value:h})})}r.$[s]=a}else if(Xt(o)&&!ad(o)){let a={v:o,n:this.norm.get(o)};r.$[s]=a}}}),this.records.push(r)}toJSON(){return{keys:this.keys,records:this.records}}};function g1(t,e,{getFn:n=M.getFn,fieldNormWeight:r=M.fieldNormWeight}={}){let i=new Qs({getFn:n,fieldNormWeight:r});return i.setKeys(t.map(m1)),i.setSources(e),i.create(),i}function lS(t,{getFn:e=M.getFn,fieldNormWeight:n=M.fieldNormWeight}={}){let{keys:r,records:i}=t,s=new Qs({getFn:e,fieldNormWeight:n});return s.setKeys(r),s.setIndexRecords(i),s}function fl(t,{errors:e=0,currentLocation:n=0,expectedLocation:r=0,distance:i=M.distance,ignoreLocation:s=M.ignoreLocation}={}){let o=e/t.length;if(s)return o;let a=Math.abs(r-n);return i?o+a/i:a?1:o}function uS(t=[],e=M.minMatchCharLength){let n=[],r=-1,i=-1,s=0;for(let o=t.length;s<o;s+=1){let a=t[s];a&&r===-1?r=s:!a&&r!==-1&&(i=s-1,i-r+1>=e&&n.push([r,i]),r=-1)}return t[s-1]&&s-r>=e&&n.push([r,s-1]),n}var Dr=32;function cS(t,e,n,{location:r=M.location,distance:i=M.distance,threshold:s=M.threshold,findAllMatches:o=M.findAllMatches,minMatchCharLength:a=M.minMatchCharLength,includeMatches:l=M.includeMatches,ignoreLocation:u=M.ignoreLocation}={}){if(e.length>Dr)throw new Error(YE(Dr));let c=e.length,h=t.length,p=Math.max(0,Math.min(r,h)),g=s,y=p,A=a>1||l,P=A?Array(h):[],f;for(;(f=t.indexOf(e,y))>-1;){let T=fl(e,{currentLocation:f,expectedLocation:p,distance:i,ignoreLocation:u});if(g=Math.min(T,g),y=f+c,A){let k=0;for(;k<c;)P[f+k]=1,k+=1}}y=-1;let d=[],m=1,v=c+h,S=1<<c-1;for(let T=0;T<c;T+=1){let k=0,K=v;for(;k<K;)fl(e,{errors:T,currentLocation:p+K,expectedLocation:p,distance:i,ignoreLocation:u})<=g?k=K:v=K,K=Math.floor((v-k)/2+k);v=K;let q=Math.max(1,p-K+1),ft=o?h:Math.min(p+K,h)+c,kn=Array(ft+2);kn[ft+1]=(1<<T)-1;for(let Ct=ft;Ct>=q;Ct-=1){let jo=Ct-1,Sm=n[t.charAt(jo)];if(A&&(P[jo]=+!!Sm),kn[Ct]=(kn[Ct+1]<<1|1)&Sm,T&&(kn[Ct]|=(d[Ct+1]|d[Ct])<<1|1|d[Ct+1]),kn[Ct]&S&&(m=fl(e,{errors:T,currentLocation:jo,expectedLocation:p,distance:i,ignoreLocation:u}),m<=g)){if(g=m,y=jo,y<=p)break;q=Math.max(1,2*p-y)}}if(fl(e,{errors:T+1,currentLocation:p,expectedLocation:p,distance:i,ignoreLocation:u})>g)break;d=kn}let D={isMatch:y>=0,score:Math.max(.001,m)};if(A){let T=uS(P,a);T.length?l&&(D.indices=T):D.isMatch=!1}return D}function hS(t){let e={};for(let n=0,r=t.length;n<r;n+=1){let i=t.charAt(n);e[i]=(e[i]||0)|1<<r-n-1}return e}var pl=class{constructor(e,{location:n=M.location,threshold:r=M.threshold,distance:i=M.distance,includeMatches:s=M.includeMatches,findAllMatches:o=M.findAllMatches,minMatchCharLength:a=M.minMatchCharLength,isCaseSensitive:l=M.isCaseSensitive,ignoreLocation:u=M.ignoreLocation}={}){if(this.options={location:n,threshold:r,distance:i,includeMatches:s,findAllMatches:o,minMatchCharLength:a,isCaseSensitive:l,ignoreLocation:u},this.pattern=l?e:e.toLowerCase(),this.chunks=[],!this.pattern.length)return;let c=(p,g)=>{this.chunks.push({pattern:p,alphabet:hS(p),startIndex:g})},h=this.pattern.length;if(h>Dr){let p=0,g=h%Dr,y=h-g;for(;p<y;)c(this.pattern.substr(p,Dr),p),p+=Dr;if(g){let A=h-Dr;c(this.pattern.substr(A),A)}}else c(this.pattern,0)}searchIn(e){let{isCaseSensitive:n,includeMatches:r}=this.options;if(n||(e=e.toLowerCase()),this.pattern===e){let y={isMatch:!0,score:0};return r&&(y.indices=[[0,e.length-1]]),y}let{location:i,distance:s,threshold:o,findAllMatches:a,minMatchCharLength:l,ignoreLocation:u}=this.options,c=[],h=0,p=!1;this.chunks.forEach(({pattern:y,alphabet:A,startIndex:P})=>{let{isMatch:f,score:d,indices:m}=cS(e,y,A,{location:i+P,distance:s,threshold:o,findAllMatches:a,minMatchCharLength:l,includeMatches:r,ignoreLocation:u});f&&(p=!0),h+=d,f&&m&&(c=[...c,...m])});let g={isMatch:p,score:p?h/this.chunks.length:1};return p&&r&&(g.indices=c),g}},Wt=class{constructor(e){this.pattern=e}static isMultiMatch(e){return u1(e,this.multiRegex)}static isSingleMatch(e){return u1(e,this.singleRegex)}search(){}};function u1(t,e){let n=t.match(e);return n?n[1]:null}var cd=class extends Wt{constructor(e){super(e)}static get type(){return"exact"}static get multiRegex(){return/^="(.*)"$/}static get singleRegex(){return/^=(.*)$/}search(e){let n=e===this.pattern;return{isMatch:n,score:n?0:1,indices:[0,this.pattern.length-1]}}},hd=class extends Wt{constructor(e){super(e)}static get type(){return"inverse-exact"}static get multiRegex(){return/^!"(.*)"$/}static get singleRegex(){return/^!(.*)$/}search(e){let r=e.indexOf(this.pattern)===-1;return{isMatch:r,score:r?0:1,indices:[0,e.length-1]}}},dd=class extends Wt{constructor(e){super(e)}static get type(){return"prefix-exact"}static get multiRegex(){return/^\^"(.*)"$/}static get singleRegex(){return/^\^(.*)$/}search(e){let n=e.startsWith(this.pattern);return{isMatch:n,score:n?0:1,indices:[0,this.pattern.length-1]}}},fd=class extends Wt{constructor(e){super(e)}static get type(){return"inverse-prefix-exact"}static get multiRegex(){return/^!\^"(.*)"$/}static get singleRegex(){return/^!\^(.*)$/}search(e){let n=!e.startsWith(this.pattern);return{isMatch:n,score:n?0:1,indices:[0,e.length-1]}}},pd=class extends Wt{constructor(e){super(e)}static get type(){return"suffix-exact"}static get multiRegex(){return/^"(.*)"\$$/}static get singleRegex(){return/^(.*)\$$/}search(e){let n=e.endsWith(this.pattern);return{isMatch:n,score:n?0:1,indices:[e.length-this.pattern.length,e.length-1]}}},md=class extends Wt{constructor(e){super(e)}static get type(){return"inverse-suffix-exact"}static get multiRegex(){return/^!"(.*)"\$$/}static get singleRegex(){return/^!(.*)\$$/}search(e){let n=!e.endsWith(this.pattern);return{isMatch:n,score:n?0:1,indices:[0,e.length-1]}}},ml=class extends Wt{constructor(e,{location:n=M.location,threshold:r=M.threshold,distance:i=M.distance,includeMatches:s=M.includeMatches,findAllMatches:o=M.findAllMatches,minMatchCharLength:a=M.minMatchCharLength,isCaseSensitive:l=M.isCaseSensitive,ignoreLocation:u=M.ignoreLocation}={}){super(e),this._bitapSearch=new pl(e,{location:n,threshold:r,distance:i,includeMatches:s,findAllMatches:o,minMatchCharLength:a,isCaseSensitive:l,ignoreLocation:u})}static get type(){return"fuzzy"}static get multiRegex(){return/^"(.*)"$/}static get singleRegex(){return/^(.*)$/}search(e){return this._bitapSearch.searchIn(e)}},gl=class extends Wt{constructor(e){super(e)}static get type(){return"include"}static get multiRegex(){return/^'"(.*)"$/}static get singleRegex(){return/^'(.*)$/}search(e){let n=0,r,i=[],s=this.pattern.length;for(;(r=e.indexOf(this.pattern,n))>-1;)n=r+s,i.push([r,n-1]);let o=!!i.length;return{isMatch:o,score:o?0:1,indices:i}}},gd=[cd,gl,dd,fd,md,pd,hd,ml],c1=gd.length,dS=/ +(?=(?:[^\"]*\"[^\"]*\")*[^\"]*$)/,fS="|";function pS(t,e={}){return t.split(fS).map(n=>{let r=n.trim().split(dS).filter(s=>s&&!!s.trim()),i=[];for(let s=0,o=r.length;s<o;s+=1){let a=r[s],l=!1,u=-1;for(;!l&&++u<c1;){let c=gd[u],h=c.isMultiMatch(a);h&&(i.push(new c(h,e)),l=!0)}if(!l)for(u=-1;++u<c1;){let c=gd[u],h=c.isSingleMatch(a);if(h){i.push(new c(h,e));break}}}return i})}var mS=new Set([ml.type,gl.type]),yd=class{constructor(e,{isCaseSensitive:n=M.isCaseSensitive,includeMatches:r=M.includeMatches,minMatchCharLength:i=M.minMatchCharLength,ignoreLocation:s=M.ignoreLocation,findAllMatches:o=M.findAllMatches,location:a=M.location,threshold:l=M.threshold,distance:u=M.distance}={}){this.query=null,this.options={isCaseSensitive:n,includeMatches:r,minMatchCharLength:i,findAllMatches:o,ignoreLocation:s,location:a,threshold:l,distance:u},this.pattern=n?e:e.toLowerCase(),this.query=pS(this.pattern,this.options)}static condition(e,n){return n.useExtendedSearch}searchIn(e){let n=this.query;if(!n)return{isMatch:!1,score:1};let{includeMatches:r,isCaseSensitive:i}=this.options;e=i?e:e.toLowerCase();let s=0,o=[],a=0;for(let l=0,u=n.length;l<u;l+=1){let c=n[l];o.length=0,s=0;for(let h=0,p=c.length;h<p;h+=1){let g=c[h],{isMatch:y,indices:A,score:P}=g.search(e);if(y){if(s+=1,a+=P,r){let f=g.constructor.type;mS.has(f)?o=[...o,...A]:o.push(A)}}else{a=0,s=0,o.length=0;break}}if(s){let h={isMatch:!0,score:a/s};return r&&(h.indices=o),h}}return{isMatch:!1,score:1}}},Ad=[];function gS(...t){Ad.push(...t)}function vd(t,e){for(let n=0,r=Ad.length;n<r;n+=1){let i=Ad[n];if(i.condition(t,e))return new i(t,e)}return new pl(t,e)}var yl={AND:"$and",OR:"$or"},wd={PATH:"$path",PATTERN:"$val"},Ed=t=>!!(t[yl.AND]||t[yl.OR]),yS=t=>!!t[wd.PATH],AS=t=>!fn(t)&&f1(t)&&!Ed(t),h1=t=>({[yl.AND]:Object.keys(t).map(e=>({[e]:t[e]}))});function y1(t,e,{auto:n=!0}={}){let r=i=>{let s=Object.keys(i),o=yS(i);if(!o&&s.length>1&&!Ed(i))return r(h1(i));if(AS(i)){let l=o?i[wd.PATH]:s[0],u=o?i[wd.PATTERN]:i[l];if(!Xt(u))throw new Error(ZE(l));let c={keyId:ud(l),pattern:u};return n&&(c.searcher=vd(u,e)),c}let a={children:[],operator:s[0]};return s.forEach(l=>{let u=i[l];fn(u)&&u.forEach(c=>{a.children.push(r(c))})}),a};return Ed(t)||(t=h1(t)),r(t)}function vS(t,{ignoreFieldNorm:e=M.ignoreFieldNorm}){t.forEach(n=>{let r=1;n.matches.forEach(({key:i,norm:s,score:o})=>{let a=i?i.weight:null;r*=Math.pow(o===0&&a?Number.EPSILON:o,(a||1)*(e?1:s))}),n.score=r})}function wS(t,e){let n=t.matches;e.matches=[],ht(n)&&n.forEach(r=>{if(!ht(r.indices)||!r.indices.length)return;let{indices:i,value:s}=r,o={indices:i,value:s};r.key&&(o.key=r.key.src),r.idx>-1&&(o.refIndex=r.idx),e.matches.push(o)})}function ES(t,e){e.score=t.score}function SS(t,e,{includeMatches:n=M.includeMatches,includeScore:r=M.includeScore}={}){let i=[];return n&&i.push(wS),r&&i.push(ES),t.map(s=>{let{idx:o}=s,a={item:e[o],refIndex:o};return i.length&&i.forEach(l=>{l(s,a)}),a})}var pn=class{constructor(e,n={},r){this.options={...M,...n},this.options.useExtendedSearch,this._keyStore=new ld(this.options.keys),this.setCollection(e,r)}setCollection(e,n){if(this._docs=e,n&&!(n instanceof Qs))throw new Error(JE);this._myIndex=n||g1(this.options.keys,this._docs,{getFn:this.options.getFn,fieldNormWeight:this.options.fieldNormWeight})}add(e){ht(e)&&(this._docs.push(e),this._myIndex.add(e))}remove(e=()=>!1){let n=[];for(let r=0,i=this._docs.length;r<i;r+=1){let s=this._docs[r];e(s,r)&&(this.removeAt(r),r-=1,i-=1,n.push(s))}return n}removeAt(e){this._docs.splice(e,1),this._myIndex.removeAt(e)}getIndex(){return this._myIndex}search(e,{limit:n=-1}={}){let{includeMatches:r,includeScore:i,shouldSort:s,sortFn:o,ignoreFieldNorm:a}=this.options,l=Xt(e)?Xt(this._docs[0])?this._searchStringList(e):this._searchObjectList(e):this._searchLogical(e);return vS(l,{ignoreFieldNorm:a}),s&&l.sort(o),d1(n)&&n>-1&&(l=l.slice(0,n)),SS(l,this._docs,{includeMatches:r,includeScore:i})}_searchStringList(e){let n=vd(e,this.options),{records:r}=this._myIndex,i=[];return r.forEach(({v:s,i:o,n:a})=>{if(!ht(s))return;let{isMatch:l,score:u,indices:c}=n.searchIn(s);l&&i.push({item:s,idx:o,matches:[{score:u,value:s,norm:a,indices:c}]})}),i}_searchLogical(e){let n=y1(e,this.options),r=(a,l,u)=>{if(!a.children){let{keyId:h,searcher:p}=a,g=this._findMatches({key:this._keyStore.get(h),value:this._myIndex.getValueForItemAtKeyId(l,h),searcher:p});return g&&g.length?[{idx:u,item:l,matches:g}]:[]}let c=[];for(let h=0,p=a.children.length;h<p;h+=1){let g=a.children[h],y=r(g,l,u);if(y.length)c.push(...y);else if(a.operator===yl.AND)return[]}return c},i=this._myIndex.records,s={},o=[];return i.forEach(({$:a,i:l})=>{if(ht(a)){let u=r(n,a,l);u.length&&(s[l]||(s[l]={idx:l,item:a,matches:[]},o.push(s[l])),u.forEach(({matches:c})=>{s[l].matches.push(...c)}))}}),o}_searchObjectList(e){let n=vd(e,this.options),{keys:r,records:i}=this._myIndex,s=[];return i.forEach(({$:o,i:a})=>{if(!ht(o))return;let l=[];r.forEach((u,c)=>{l.push(...this._findMatches({key:u,value:o[c],searcher:n}))}),l.length&&s.push({idx:a,item:o,matches:l})}),s}_findMatches({key:e,value:n,searcher:r}){if(!ht(n))return[];let i=[];if(fn(n))n.forEach(({v:s,i:o,n:a})=>{if(!ht(s))return;let{isMatch:l,score:u,indices:c}=r.searchIn(s);l&&i.push({score:u,key:e,value:s,idx:o,norm:a,indices:c})});else{let{v:s,n:o}=n,{isMatch:a,score:l,indices:u}=r.searchIn(s);a&&i.push({score:l,key:e,value:s,norm:o,indices:u})}return i}};pn.version="6.6.2";pn.createIndex=g1;pn.parseIndex=lS;pn.config=M;pn.parseQuery=y1;gS(yd);var Nr=F(it());var I1=F(Hs());var A1="a28d9083ea3c0cbb72c7bb849b377f8a3ff407ad9a6ad9f57d4bccb2314605c5",IS=`._paragraph_kztwj_1 {
  font-size: 1.4rem;
}
._heading_kztwj_4 {
  font-size: 1.8rem;
}
._subheading_kztwj_7 {
  font-size: 1.6rem;
}
._xLargeHeading_kztwj_10 {
  font-size: 3rem;
}
`;(function(){if(!(typeof document>"u")&&!document.getElementById(A1)){var t=document.createElement("style");t.id=A1,t.textContent=IS,document.head.appendChild(t)}})();var v1={paragraph:"_paragraph_kztwj_1",heading:"_heading_kztwj_4",subheading:"_subheading_kztwj_7",xLargeHeading:"_xLargeHeading_kztwj_10"};var x1=F(te()),G=h=>{var p=h,{type:t,children:e,noWrap:n,bold:r,dark:i,dull:s,style:o,className:a,noSelect:l,lineHeight:u}=p,c=qt(p,["type","children","noWrap","bold","dark","dull","style","className","noSelect","lineHeight"]);return(0,x1.jsx)("div",pt(Ke({className:(0,I1.default)(t&&v1[t],a),style:Ke(pt(Ke({},n?{textOverflow:"ellipsis",whiteSpace:"nowrap",overflow:"hidden"}:{}),{fontWeight:r?"bold":"",color:i?"var(--dark-1)":s?"var(--light-2)":"",userSelect:l?"none":"auto",lineHeight:u}),o)},c),{children:e}))};var V1=F(it());var T1=F(te()),mn=n=>{var r=n,{name:t}=r,e=qt(r,["name"]);return(0,T1.jsx)("span",pt(Ke({className:"material-symbols-outlined"},e),{children:t}))};var D1=F(it());var C1="894801e3d9f40df8091d1836f57b3023f9f17fff6f065175fe93140aabbc709c",PS=`._input_2s1s6_1 {
  font-family: inherit;
  font-size: 1.5rem;
  padding: 5px;
  border-radius: 3px;
  box-sizing: border-box;
  border: none;
  background-color: var(--light-1);
  outline-offset: 2px;
}
._input_2s1s6_1:focus:active {
  outline: 2px solid var(--accent-2);
}
._input_2s1s6_1:focus {
  outline: 2px solid var(--accent-1);
}
`;(function(){if(!(typeof document>"u")&&!document.getElementById(C1)){var t=document.createElement("style");t.id=C1,t.textContent=PS,document.head.appendChild(t)}})();var k1={input:"_input_2s1s6_1"};var P1=F(te()),N1=(0,D1.forwardRef)((r,n)=>{var i=r,{className:t}=i,e=qt(i,["className"]);return(0,P1.jsx)("input",pt(Ke({ref:n},e),{className:k1.input+" "+(t!=null?t:"")}))});var _1="ad6ba2898289bf56a26bd7ee679b2063e461753c9137b1bfa88947a765124acc",_S=`._header_6ivkt_1 {
  text-align: left;
  background-color: var(--dark-2);
  padding: 10px 20px;
  border-bottom: 2px solid var(--light-1);
  position: relative;
}
._heading_6ivkt_8 {
  display: block;
}
._buttonsTray_6ivkt_11 {
  position: absolute;
  height: 100%;
  width: 100%;
  top: 0;
  right: 0;
}
._buttons_6ivkt_11 {
  display: flex;
  height: 100%;
  width: 100%;
  align-items: center;
  padding: 0 10px;
  box-sizing: border-box;
  justify-content: flex-end;
  font-size: 2.2rem;
}
._inputContainer_6ivkt_28 {
  transition: 0.5s all;
  width: 0;
  overflow: hidden;
  display: flex;
  flex-direction: row-reverse; /* Basically start from the right */
  margin-right: 10px;
}
._inputContainer_6ivkt_28 input {
  margin: 10px 4px;
  flex-grow: 1;
  width: 0;
}
._icon_6ivkt_41 {
  padding: 5px 7px;
}
`;(function(){if(!(typeof document>"u")&&!document.getElementById(_1)){var t=document.createElement("style");t.id=_1,t.textContent=_S,document.head.appendChild(t)}})();var Gn={header:"_header_6ivkt_1",heading:"_heading_6ivkt_8",buttonsTray:"_buttonsTray_6ivkt_11",buttons:"_buttons_6ivkt_11",inputContainer:"_inputContainer_6ivkt_28",icon:"_icon_6ivkt_41"};var OS=(t,e)=>{let n=document.createElement("a");n.href=URL.createObjectURL(new Blob([e],{type:"text/plain"})),n.download=t,n.click()},O1=(t,e)=>{OS(t+".tsv",L1(e))},wl=t=>{navigator.clipboard.writeText(L1(t))},L1=t=>t.map(e=>e.front.text+"	"+e.back.text).join(`
`);var z1=F(M1());var b1="8d81ef0cd6c71b58eb6046c6c52d07e7d890a5d4446b9b75b3cc7849bdacc136",LS={button:"_button_rw12i_1",zoomButton:"_zoomButton_rw12i_21"},MS=`._button_rw12i_1 {
  background-color: transparent;
  outline: none;
  color: var(--light-1);
  font-size: inherit;
  cursor: pointer;
  transition: 0.15s all;
  border: 0;
}
._button_rw12i_1:hover {
  background-color: var(--dark-2);
}
._button_rw12i_1:hover:active {
  background-color: var(--dark-1);
}
._button_rw12i_1:disabled {
  color: var(--light-2);
  pointer-events: none;
}

._zoomButton_rw12i_21 {
  background-color: transparent;
}
._zoomButton_rw12i_21:hover {
  background-color: transparent;
  transform: scale(1.2);
}
._zoomButton_rw12i_21:hover:active {
  background-color: transparent;
  transform: scale(1);
}`;(function(){if(typeof document<"u"&&!document.getElementById(b1)){var t=document.createElement("style");t.id=b1,t.textContent=MS,document.head.appendChild(t)}})();var R1=LS;var F1=F(te()),Jn=r=>{var i=r,{className:t,zoomOnHover:e}=i,n=qt(i,["className","zoomOnHover"]);return(0,F1.jsx)("button",pt(Ke({},n),{className:z1.default.bind(R1)("button",{zoomButton:e},t)}))};var B1=F(it()),q1=()=>{let t=()=>{var n,r;(n=e.current)==null||n.focus(),(r=e.current)==null||r.select()},e=(0,B1.useRef)(null);return[e,t]};var St=F(te()),U1=({folderName:t,setSearchInput:e,cards:n,filteredCards:r})=>{let[i,s]=(0,V1.useState)(!1),[o]=q1();return(0,St.jsx)("div",{className:Gn.header,children:(0,St.jsxs)(G,{type:"heading",bold:!0,noWrap:!0,className:Gn.heading,children:[t,(0,St.jsx)("span",{className:Gn.buttonsTray,children:(0,St.jsxs)("div",{className:Gn.buttons,children:[(0,St.jsx)("div",{className:Gn.inputContainer,style:{flexGrow:i?1:0},children:(0,St.jsx)(N1,{placeholder:"Search cards...",onChange:a=>e(a.currentTarget.value),ref:o})}),(0,St.jsx)(Jn,{onMouseDown:()=>{s(!i)},zoomOnHover:!0,disabled:!n.length,className:Gn.icon,children:(0,St.jsx)(mn,{name:"search"})}),(0,St.jsx)(Jn,{onMouseDown:a=>a.shiftKey||a.metaKey?wl(r):O1(t,r),zoomOnHover:!0,disabled:!r.length,className:Gn.icon,children:(0,St.jsx)(mn,{name:"download"})})]})})]})})};var H1=F(Hs());var j1="cbc48dec5416816ba6695b52f3a50ade6066c93206d29acaa16879413dd7ba5c",bS=`._textBoxContainer_1548w_1 {
  display: grid;
  grid-template-columns: 1fr 0 1fr;
  border-top: 2px solid var(--light-1);
  align-items: start;
}

._textAreaContainer_1548w_8 {
  position: relative;
  padding: 10px 10px 20px;
  display: grid;
  gap: 5px;
}
._textAreaContainer_1548w_8 ._language_1548w_14 {
  position: absolute;
  right: 10px;
  bottom: 5px;
}
._textAreaContainer_1548w_8 ._title_1548w_19 {
  font-weight: bold;
  border-bottom: 1px solid var(--light-1);
  width: max-content;
}

._textarea_1548w_25 {
  font-family: inherit;
  font-size: 1.5rem;
  border: none;
  resize: none;
  color: var(--light-1);
  background-color: transparent;
  width: 100%;
  box-sizing: border-box;
  outline: none;
  padding: 0;
}
._buttonRow_1548w_37 {
  display: flex;
  border-top: 1px solid var(--light-1);
}

._buttonRow_1548w_37 button {
  border-radius: 0;
  border: none;
  border-right: 1px solid var(--light-1);
  padding: 5px 10px;
}
._source_1548w_48 {
  flex-grow: 1;
  text-align: right;
  padding-right: 10px;
  margin: auto;
}
`;(function(){if(!(typeof document>"u")&&!document.getElementById(j1)){var t=document.createElement("style");t.id=j1,t.textContent=bS,document.head.appendChild(t)}})();var Zn={textBoxContainer:"_textBoxContainer_1548w_1",textAreaContainer:"_textAreaContainer_1548w_8",language:"_language_1548w_14",title:"_title_1548w_19",textarea:"_textarea_1548w_25",buttonRow:"_buttonRow_1548w_37",source:"_source_1548w_48"};var Ii=F(it());var qe=F(te()),Q1=i=>{var s=i,{className:t,language:e,title:n}=s,r=qt(s,["className","language","title"]);let o=(0,Ii.useRef)(null),[a,l]=(0,Ii.useState)(0),u=()=>{o.current&&l(Math.min(40,o.current.scrollHeight))};return(0,Ii.useLayoutEffect)(u),(0,qe.jsxs)("div",{className:Zn.textAreaContainer,children:[(0,qe.jsxs)(G,{type:"subheading",className:Zn.title,children:[n," (",e,")"]}),(0,qe.jsx)("textarea",pt(Ke({ref:o,style:{height:a},onInput:u},r),{className:(0,H1.default)(Zn.textarea,t)}))]})},K1=({cards:t,saveCard:e,deleteCard:n})=>{let r=t[0];return(0,qe.jsxs)("div",{className:Zn.container,children:[t.length===1&&(0,qe.jsxs)("div",{className:Zn.textBoxContainer,children:[(0,qe.jsx)(Q1,{value:r.front.text,language:r.front.lang,readOnly:!0,title:"Front"}),(0,qe.jsx)("div",{style:{background:"white"}}),(0,qe.jsx)(Q1,{value:r.back.text,language:r.back.lang,readOnly:!0,title:"Back"})]},r.id),(0,qe.jsxs)("div",{className:Zn.buttonRow,children:[r.location==="root"&&(0,qe.jsx)(Jn,{onClick:e,children:(0,qe.jsx)(G,{type:"subheading",children:"Save"})}),(0,qe.jsx)(Jn,{onClick:n,children:(0,qe.jsx)(G,{type:"subheading",children:"Delete"})}),(0,qe.jsx)(G,{type:"paragraph",className:Zn.source,children:t.length===1?`Source: ${r.source}`:`Selected (${t.length}) Cards`})]})]})};var X1="53f8a07d0e64b7fc59c674e9f1432994b91691c63d17d0b588c66aa87c82b956",RS=`._textBox_1xf1n_1 {
  position: sticky;
  bottom: 0;
}

._container_1xf1n_6 {
  position: relative;
  overflow: hidden;
  display: flex;
  flex-direction: column;
}
tr._selected_1xf1n_12 {
  background-color: var(--dark-2);
  font-weight: bold;
}
._table_1xf1n_16 {
  overflow: scroll;
  flex-grow: 1;
}

._tableContainer_1xf1n_21 {
  overflow: scroll;
  flex-grow: 1;
}

._placeholder_1xf1n_26 {
  display: flex;
  align-items: center;
  justify-content: center;
  flex-direction: column;
  flex-grow: 1;
  gap: 20px;
}
`;(function(){if(!(typeof document>"u")&&!document.getElementById(X1)){var t=document.createElement("style");t.id=X1,t.textContent=RS,document.head.appendChild(t)}})();var Ks={textBox:"_textBox_1xf1n_1",container:"_container_1xf1n_6",selected:"_selected_1xf1n_12",table:"_table_1xf1n_16",tableContainer:"_tableContainer_1xf1n_21",placeholder:"_placeholder_1xf1n_26"};var W1="./searchEmpty-6BS5P24J.svg";var G1='data:image/svg+xml,<svg version="1.1" viewBox="0.0 0.0 612.0314960629921 392.3280839895013" fill="none" stroke="none" stroke-linecap="square" stroke-miterlimit="10" xmlns:xlink="http://www.w3.org/1999/xlink" xmlns="http://www.w3.org/2000/svg"><clipPath id="p.0"><path d="m0 0l612.0315 0l0 392.3281l-612.0315 0l0 -392.3281z" clip-rule="nonzero"/></clipPath><g clip-path="url(%23p.0)"><path fill="%23000000" fill-opacity="0.0" d="m0 0l612.0315 0l0 392.3281l-612.0315 0z" fill-rule="evenodd"/><path fill="%23000000" fill-opacity="0.0" d="m13.109371 13.293963l513.4803 0l0 293.03937l-513.4803 0z" fill-rule="evenodd"/><path stroke="%23ffffff" stroke-width="24.0" stroke-linejoin="round" stroke-linecap="butt" d="m13.109371 13.293963l513.4803 0l0 293.03937l-513.4803 0z" fill-rule="evenodd"/><path fill="%23000000" fill-opacity="0.0" d="m85.108925 85.29396l513.4803 0l0 293.03937l-513.4803 0z" fill-rule="evenodd"/><path stroke="%23ffffff" stroke-width="24.0" stroke-linejoin="round" stroke-linecap="butt" d="m85.108925 85.29396l513.4803 0l0 293.03937l-513.4803 0z" fill-rule="evenodd"/></g></svg>';var Z1=F(Hs());var re=F(te()),J1=({image:t,text:e,className:n})=>(0,re.jsxs)("div",{className:Ks.placeholder+" "+n,children:[(0,re.jsx)("img",{src:t,alt:"",height:100}),(0,re.jsx)(G,{type:"heading",children:e})]}),BS=({cards:t,moveCards:e,deleteCards:n})=>{let{activeFolder:r}=Sl(),[i,s]=(0,Nr.useState)([]),[o,a]=(0,Nr.useState)(""),l=Nr.default.useRef(0),u=new pn(t,{keys:["front.text","back.text"]}),c=o.length?u.search(o).map(f=>f.item):[...t].reverse(),h=c.filter(f=>i.includes(f.id)),p=(f,d)=>{if(d===0)return f;let m=c.map(S=>S.id),v=-1;for(let S=f;S<m.length&&S>=0&&i.includes(m[S]);S+=d)v=S;return v},g=(f,d,m)=>Math.sign(f-d)*Math.sign(f-m)<=0,y=(f,d)=>{if(f.shiftKey){let m=c.map(k=>k.id),v=l.current,S=m.indexOf(d),D=p(v,1),T=p(v,-1);s(m.filter((k,K)=>i.includes(k)&&!g(K,T,D)||g(K,v,S)))}else{let m=f.ctrlKey||f.metaKey?[...i]:[];m.includes(d)?s(m.filter(v=>v!==d)):s([...m,d]),l.current=c.findIndex(v=>v.id===d)}},A=f=>{f.key==="Escape"&&(s([]),f.preventDefault()),f.key==="a"&&(f.metaKey||f.ctrlKey)&&(s(c.map(d=>d.id)),f.preventDefault()),f.key==="c"&&(f.metaKey||f.ctrlKey)&&wl(h)};(0,Nr.useEffect)(()=>{let f=i.filter(d=>c.some(m=>m.id===d));f.length<i.length&&s(f)},[c,i]);let P=()=>{let f=i.length===1?c.findIndex(d=>d.id===i[0])+1:c.length;f<c.length&&f>=0?s([c[f].id]):s([])};return(0,re.jsxs)("div",{className:Ks.container,children:[(0,re.jsx)(U1,{folderName:r.name,setSearchInput:a,cards:t,filteredCards:c}),c.length?(0,re.jsx)("div",{className:Ks.tableContainer,onKeyDown:A,children:(0,re.jsxs)("table",{children:[(0,re.jsx)("thead",{children:(0,re.jsxs)("tr",{children:[(0,re.jsx)("th",{children:(0,re.jsx)(G,{type:"subheading",children:"Original"})}),(0,re.jsx)("th",{children:(0,re.jsx)(G,{type:"subheading",children:"Translation"})})]})}),(0,re.jsx)("tbody",{children:c.map(f=>(0,re.jsxs)("tr",{tabIndex:0,onMouseDown:d=>y(d,f.id),className:(0,Z1.default)({[Ks.selected]:i.includes(f.id)}),children:[(0,re.jsx)("td",{children:(0,re.jsx)(G,{type:"paragraph",noWrap:!0,dull:i.length>0&&!i.includes(f.id),children:f.front.text})}),(0,re.jsx)("td",{children:(0,re.jsx)(G,{type:"paragraph",noWrap:!0,dull:i.length>0&&!i.includes(f.id),children:f.back.text})})]},f.id))})]})}):t.length?(0,re.jsx)(J1,{image:W1,text:"No cards match your search"}):(0,re.jsx)(J1,{image:G1,text:"This folder is currently empty"}),h.length>0&&(0,re.jsx)(K1,{cards:h,saveCard:()=>{P(),e(i)},deleteCard:()=>{P(),n(i)}})]})},Y1=BS;var ur=F(it());var $1="08872162a06b3f769c8fa3d13110dd03bd3e43ca9d92e70b1e275ecd3321f763",qS=`._container_mgi7k_1 {
  position: relative;
  border-top: 2px solid var(--light-1);
}

._textBox_mgi7k_6 {
  position: absolute;
  left: 10px;
  bottom: 100%;
  background-color: var(--light-1);
  color: var(--dark-1);
  transform-origin: bottom left;
  padding: 15px;
  display: block;
  width: 450px;
  overflow-wrap: normal;
  border-radius: 10px;
  z-index: 42;
  transition: 0.3s all;
  max-height: 300px;
  overflow: scroll;
}
._open_mgi7k_23 {
  transform: translate(0);
  opacity: 1;
}
._closed_mgi7k_27 {
  transform: translate(0, -10px);
  opacity: 0;
  visibility: hidden;
}

._hotKeyContainer_mgi7k_33 {
  border: 1px solid var(--dark-1);
  border-radius: 5px;
  width: fit-content;
  padding: 2px 5px;
  display: inline-block;
}

._shortcutTable_mgi7k_41 {
  display: grid;
  grid-template-columns: 150px 1.3fr;
  row-gap: 5px;
}
`;(function(){if(!(typeof document>"u")&&!document.getElementById($1)){var t=document.createElement("style");t.id=$1,t.textContent=qS,document.head.appendChild(t)}})();var Pr={container:"_container_mgi7k_1",textBox:"_textBox_mgi7k_6",open:"_open_mgi7k_23",closed:"_closed_mgi7k_27",hotKeyContainer:"_hotKeyContainer_mgi7k_33",shortcutTable:"_shortcutTable_mgi7k_41"};var l2=F(Hs());var Il=F(it());var eA={cards:[{back:{lang:"es",text:"Vale, eso es un peque\xF1o problema."},front:{lang:"en",text:"ok that's a bit of a problem"},id:"LjYGLSSy_7e0TItw_J83d",location:"tchYdlZkZyp76HO2CsL7o",source:"DeepL",timeCreated:1682879242314,hidden:!0},{back:{lang:"es",text:"Vale, eso es un peque\xF1o problema."},front:{lang:"en",text:"ok that's a bit of a problem"},id:"TAyoBlNg319ZPqvpiF62R",location:"root",source:"DeepL",timeCreated:1682879242314,hidden:!0},{back:{lang:"es",text:"ok algunas palabras m\xE1s"},front:{lang:"en",text:"ok some more words"},id:"dysWYkD58Zvk9VdiDIgkz",location:"root",source:"DeepL",timeCreated:1682880024661,hidden:!0},{back:{lang:"es",text:"Hola Jonathan"},front:{lang:"en",text:"hey jonathan"},id:"g0u9MLr61zqKOydPwth-u",location:"root",source:"DeepL",timeCreated:1682880033144},{back:{lang:"es",text:"lol datos falsos"},front:{lang:"en",text:"lol fake data"},id:"t2zeHb1AQnsBI9iaRL2fK",location:"root",source:"DeepL",timeCreated:1682880041231},{back:{lang:"es",text:"uhhh"},front:{lang:"en",text:"uhhh"},id:"Tnl448xwXh8xjFavsWhjM",location:"root",source:"DeepL",timeCreated:1682880051203},{back:{lang:"es",text:"hagamos spam"},front:{lang:"en",text:"let's spam stuff"},id:"G2EIoNxW-H3VP8-m-CLK9",location:"root",source:"DeepL",timeCreated:1682880054244},{back:{lang:"es",text:"Necesito"},front:{lang:"en",text:"I need "},id:"qwdtr6TDsy0Vjrezj0cnp",location:"root",source:"DeepL",timeCreated:1682880056616,hidden:!0},{back:{lang:"es",text:"trabajar de verdad"},front:{lang:"en",text:"to actually to work"},id:"TNhV_YUAwmJKtIP6YWIrO",location:"root",source:"DeepL",timeCreated:1682880061215},{back:{lang:"es",text:"n"},front:{lang:"en",text:"n"},id:"He0JxlVgO67b6me70f0G6",location:"root",source:"DeepL",timeCreated:1682880063076},{back:{lang:"es",text:"como hw"},front:{lang:"en",text:"like hw"},id:"yS9CC9iA0hHMsH8u9F8lN",location:"root",source:"DeepL",timeCreated:1682880065556},{back:{lang:"es",text:"pero uh"},front:{lang:"en",text:"but uh"},id:"uZvWfeKE1ro_9zENFkREi",location:"root",source:"DeepL",timeCreated:1682880068528},{back:{lang:"es",text:"s\xED"},front:{lang:"en",text:"yeah"},id:"s3ncbg58Ka1TyaiEPXBUK",location:"root",source:"DeepL",timeCreated:1682880072142},{back:{lang:"es",text:"idk"},front:{lang:"en",text:"idk"},id:"Xv_28JZ2EHjG72z8o9IvE",location:"root",source:"DeepL",timeCreated:1682880073417},{back:{lang:"es",text:"a"},front:{lang:"en",text:"a"},id:"zgs5lk6UJ18fYflpC8e7S",location:"root",source:"DeepL",timeCreated:1682880082038},{back:{lang:"es",text:"\xA1Est\xE1 bien!"},front:{lang:"en",text:"ok right!"},id:"qSe0fi5vgVkhg09Fh_zhA",location:"root",source:"DeepL",timeCreated:1682880091738},{back:{lang:"es",text:"\xBFalgo m\xE1s?"},front:{lang:"en",text:"some more?"},id:"cvIYivjyHEkfJeDUP-4LW",location:"root",source:"DeepL",timeCreated:1682880096426},{back:{lang:"es",text:"lo antes posible"},front:{lang:"en",text:"asap"},id:"IOqRBefu1cqOqTwruBHl1",location:"root",source:"DeepL",timeCreated:1682880102828},{back:{lang:"es",text:"uno m\xE1s"},front:{lang:"en",text:"loremloremloremloremloremloremloremloremloremloremloremloremloremloremloremloremloremloremloremlorem "},id:"ABENDQFaMMkTsVCQnVJIi",location:"root",source:"DeepL",timeCreated:1682880114230},{back:{lang:"es",text:"Perd\xED tanto tiempo haciendo la animaci\xF3n de la carpeta, pero ahora ni siquiera tenemos carpeta lol"},front:{lang:"en",text:"I wasted so much time doing the folder animation but now we don't even have folder lol"},id:"GmKk1_I9z0RBgkVHWPYZN",location:"root",source:"DeepL",timeCreated:1682880127342}],folders:[{id:"tchYdlZkZyp76HO2CsL7o",name:"Saved"}]};if(!chrome.storage){let t=eA,e=[],n=r=>{let i=r==="cards"||r==="folders";return i||console.warn("Attempted to get data with invalid key",r),i};chrome.storage={},chrome.storage.local={},chrome.storage.local.get=r=>new Promise(i=>{if(r||i({}),typeof r=="string"&&n(r)&&i({[r]:t[r]}),Array.isArray(r)){let s={};for(let o of r)n(o)&&(s[o]=t[o]);i({returnObj:s})}}),chrome.storage.local.set=r=>new Promise(i=>{for(let[s,o]of Object.entries(r))n(s)&&(t[s]=o);i()}),chrome.storage.local.clear=()=>new Promise(r=>{t={},r()}),chrome.storage.local.onChanged={addListener:r=>{e.push(r)},removeListener:r=>{e=e.filter(i=>i!==r)}}}var Xs=(t,e)=>{let[n,r]=(0,Il.useState)();return(0,Il.useEffect)(()=>{gn.get(t).then(s=>r(s!=null?s:e));let i=s=>{var o;t in s&&r((o=s[t].newValue)!=null?o:e)};return chrome.storage.local.onChanged.addListener(i),()=>chrome.storage.local.onChanged.removeListener(i)},[t,e]),n},gn={get:t=>new Promise(e=>{chrome.storage.local.get(t).then(n=>e(n[t]))}),getAll:()=>new Promise(t=>{chrome.storage.local.get(null).then(e=>t(e))}),set:t=>chrome.storage.local.set(t),setPair:(t,e)=>gn.set({[t]:e})};var nA=function(t){let e=[],n=0;for(let r=0;r<t.length;r++){let i=t.charCodeAt(r);i<128?e[n++]=i:i<2048?(e[n++]=i>>6|192,e[n++]=i&63|128):(i&64512)===55296&&r+1<t.length&&(t.charCodeAt(r+1)&64512)===56320?(i=65536+((i&1023)<<10)+(t.charCodeAt(++r)&1023),e[n++]=i>>18|240,e[n++]=i>>12&63|128,e[n++]=i>>6&63|128,e[n++]=i&63|128):(e[n++]=i>>12|224,e[n++]=i>>6&63|128,e[n++]=i&63|128)}return e},VS=function(t){let e=[],n=0,r=0;for(;n<t.length;){let i=t[n++];if(i<128)e[r++]=String.fromCharCode(i);else if(i>191&&i<224){let s=t[n++];e[r++]=String.fromCharCode((i&31)<<6|s&63)}else if(i>239&&i<365){let s=t[n++],o=t[n++],a=t[n++],l=((i&7)<<18|(s&63)<<12|(o&63)<<6|a&63)-65536;e[r++]=String.fromCharCode(55296+(l>>10)),e[r++]=String.fromCharCode(56320+(l&1023))}else{let s=t[n++],o=t[n++];e[r++]=String.fromCharCode((i&15)<<12|(s&63)<<6|o&63)}}return e.join("")},rA={byteToCharMap_:null,charToByteMap_:null,byteToCharMapWebSafe_:null,charToByteMapWebSafe_:null,ENCODED_VALS_BASE:"ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789",get ENCODED_VALS(){return this.ENCODED_VALS_BASE+"+/="},get ENCODED_VALS_WEBSAFE(){return this.ENCODED_VALS_BASE+"-_."},HAS_NATIVE_SUPPORT:typeof atob=="function",encodeByteArray(t,e){if(!Array.isArray(t))throw Error("encodeByteArray takes an array as a parameter");this.init_();let n=e?this.byteToCharMapWebSafe_:this.byteToCharMap_,r=[];for(let i=0;i<t.length;i+=3){let s=t[i],o=i+1<t.length,a=o?t[i+1]:0,l=i+2<t.length,u=l?t[i+2]:0,c=s>>2,h=(s&3)<<4|a>>4,p=(a&15)<<2|u>>6,g=u&63;l||(g=64,o||(p=64)),r.push(n[c],n[h],n[p],n[g])}return r.join("")},encodeString(t,e){return this.HAS_NATIVE_SUPPORT&&!e?btoa(t):this.encodeByteArray(nA(t),e)},decodeString(t,e){return this.HAS_NATIVE_SUPPORT&&!e?atob(t):VS(this.decodeStringToByteArray(t,e))},decodeStringToByteArray(t,e){this.init_();let n=e?this.charToByteMapWebSafe_:this.charToByteMap_,r=[];for(let i=0;i<t.length;){let s=n[t.charAt(i++)],a=i<t.length?n[t.charAt(i)]:0;++i;let u=i<t.length?n[t.charAt(i)]:64;++i;let h=i<t.length?n[t.charAt(i)]:64;if(++i,s==null||a==null||u==null||h==null)throw new Sd;let p=s<<2|a>>4;if(r.push(p),u!==64){let g=a<<4&240|u>>2;if(r.push(g),h!==64){let y=u<<6&192|h;r.push(y)}}}return r},init_(){if(!this.byteToCharMap_){this.byteToCharMap_={},this.charToByteMap_={},this.byteToCharMapWebSafe_={},this.charToByteMapWebSafe_={};for(let t=0;t<this.ENCODED_VALS.length;t++)this.byteToCharMap_[t]=this.ENCODED_VALS.charAt(t),this.charToByteMap_[this.byteToCharMap_[t]]=t,this.byteToCharMapWebSafe_[t]=this.ENCODED_VALS_WEBSAFE.charAt(t),this.charToByteMapWebSafe_[this.byteToCharMapWebSafe_[t]]=t,t>=this.ENCODED_VALS_BASE.length&&(this.charToByteMap_[this.ENCODED_VALS_WEBSAFE.charAt(t)]=t,this.charToByteMapWebSafe_[this.ENCODED_VALS.charAt(t)]=t)}}},Sd=class extends Error{constructor(){super(...arguments),this.name="DecodeBase64StringError"}},US=function(t){let e=nA(t);return rA.encodeByteArray(e,!0)},Ws=function(t){return US(t).replace(/\./g,"")},jS=function(t){try{return rA.decodeString(t,!0)}catch(e){console.error("base64Decode failed: ",e)}return null};function QS(){if(typeof self<"u")return self;if(typeof window<"u")return window;if(typeof global<"u")return global;throw new Error("Unable to locate global object.")}var HS=()=>QS().__FIREBASE_DEFAULTS__,KS=()=>{if(typeof process>"u"||typeof process.env>"u")return;let t=process.env.__FIREBASE_DEFAULTS__;if(t)return JSON.parse(t)},XS=()=>{if(typeof document>"u")return;let t;try{t=document.cookie.match(/__FIREBASE_DEFAULTS__=([^;]+)/)}catch{return}let e=t&&jS(t[1]);return e&&JSON.parse(e)},iA=()=>{try{return HS()||KS()||XS()}catch(t){console.info(`Unable to get __FIREBASE_DEFAULTS__ due to: ${t}`);return}},WS=t=>{var e,n;return(n=(e=iA())===null||e===void 0?void 0:e.emulatorHosts)===null||n===void 0?void 0:n[t]},sA=t=>{let e=WS(t);if(!e)return;let n=e.lastIndexOf(":");if(n<=0||n+1===e.length)throw new Error(`Invalid host ${e} with no separate hostname and port!`);let r=parseInt(e.substring(n+1),10);return e[0]==="["?[e.substring(1,n-1),r]:[e.substring(0,n),r]},oA=()=>{var t;return(t=iA())===null||t===void 0?void 0:t.config};var xl=class{constructor(){this.reject=()=>{},this.resolve=()=>{},this.promise=new Promise((e,n)=>{this.resolve=e,this.reject=n})}wrapCallback(e){return(n,r)=>{n?this.reject(n):this.resolve(r),typeof e=="function"&&(this.promise.catch(()=>{}),e.length===1?e(n):e(n,r))}}};function aA(t,e){if(t.uid)throw new Error('The "uid" field is no longer supported by mockUserToken. Please use "sub" instead for Firebase Auth User ID.');let n={alg:"none",type:"JWT"},r=e||"demo-project",i=t.iat||0,s=t.sub||t.user_id;if(!s)throw new Error("mockUserToken must contain 'sub' or 'user_id' field!");let o=Object.assign({iss:`https://securetoken.google.com/${r}`,aud:r,iat:i,exp:i+3600,auth_time:i,sub:s,user_id:s,firebase:{sign_in_provider:"custom",identities:{}}},t),a="";return[Ws(JSON.stringify(n)),Ws(JSON.stringify(o)),a].join(".")}function Id(){try{return typeof indexedDB=="object"}catch{return!1}}function lA(){return new Promise((t,e)=>{try{let n=!0,r="validate-browser-context-for-indexeddb-analytics-module",i=self.indexedDB.open(r);i.onsuccess=()=>{i.result.close(),n||self.indexedDB.deleteDatabase(r),t(!0)},i.onupgradeneeded=()=>{n=!1},i.onerror=()=>{var s;e(((s=i.error)===null||s===void 0?void 0:s.message)||"")}}catch(n){e(n)}})}var GS="FirebaseError",Rt=class extends Error{constructor(e,n,r){super(n),this.code=e,this.customData=r,this.name=GS,Object.setPrototypeOf(this,Rt.prototype),Error.captureStackTrace&&Error.captureStackTrace(this,Gs.prototype.create)}},Gs=class{constructor(e,n,r){this.service=e,this.serviceName=n,this.errors=r}create(e,...n){let r=n[0]||{},i=`${this.service}/${e}`,s=this.errors[e],o=s?JS(s,r):"Error",a=`${this.serviceName}: ${o} (${i}).`;return new Rt(i,a,r)}};function JS(t,e){return t.replace(ZS,(n,r)=>{let i=e[r];return i!=null?String(i):`<${r}?>`})}var ZS=/\{\$([^}]+)}/g;function Js(t,e){if(t===e)return!0;let n=Object.keys(t),r=Object.keys(e);for(let i of n){if(!r.includes(i))return!1;let s=t[i],o=e[i];if(tA(s)&&tA(o)){if(!Js(s,o))return!1}else if(s!==o)return!1}for(let i of r)if(!n.includes(i))return!1;return!0}function tA(t){return t!==null&&typeof t=="object"}var KT=4*60*60*1e3;function uA(t){return t&&t._delegate?t._delegate:t}var yn=class{constructor(e,n,r){this.name=e,this.instanceFactory=n,this.type=r,this.multipleInstances=!1,this.serviceProps={},this.instantiationMode="LAZY",this.onInstanceCreated=null}setInstantiationMode(e){return this.instantiationMode=e,this}setMultipleInstances(e){return this.multipleInstances=e,this}setServiceProps(e){return this.serviceProps=e,this}setInstanceCreatedCallback(e){return this.onInstanceCreated=e,this}};var _r="[DEFAULT]";var xd=class{constructor(e,n){this.name=e,this.container=n,this.component=null,this.instances=new Map,this.instancesDeferred=new Map,this.instancesOptions=new Map,this.onInitCallbacks=new Map}get(e){let n=this.normalizeInstanceIdentifier(e);if(!this.instancesDeferred.has(n)){let r=new xl;if(this.instancesDeferred.set(n,r),this.isInitialized(n)||this.shouldAutoInitialize())try{let i=this.getOrInitializeService({instanceIdentifier:n});i&&r.resolve(i)}catch{}}return this.instancesDeferred.get(n).promise}getImmediate(e){var n;let r=this.normalizeInstanceIdentifier(e?.identifier),i=(n=e?.optional)!==null&&n!==void 0?n:!1;if(this.isInitialized(r)||this.shouldAutoInitialize())try{return this.getOrInitializeService({instanceIdentifier:r})}catch(s){if(i)return null;throw s}else{if(i)return null;throw Error(`Service ${this.name} is not available`)}}getComponent(){return this.component}setComponent(e){if(e.name!==this.name)throw Error(`Mismatching Component ${e.name} for Provider ${this.name}.`);if(this.component)throw Error(`Component for ${this.name} has already been provided`);if(this.component=e,!!this.shouldAutoInitialize()){if($S(e))try{this.getOrInitializeService({instanceIdentifier:_r})}catch{}for(let[n,r]of this.instancesDeferred.entries()){let i=this.normalizeInstanceIdentifier(n);try{let s=this.getOrInitializeService({instanceIdentifier:i});r.resolve(s)}catch{}}}}clearInstance(e=_r){this.instancesDeferred.delete(e),this.instancesOptions.delete(e),this.instances.delete(e)}async delete(){let e=Array.from(this.instances.values());await Promise.all([...e.filter(n=>"INTERNAL"in n).map(n=>n.INTERNAL.delete()),...e.filter(n=>"_delete"in n).map(n=>n._delete())])}isComponentSet(){return this.component!=null}isInitialized(e=_r){return this.instances.has(e)}getOptions(e=_r){return this.instancesOptions.get(e)||{}}initialize(e={}){let{options:n={}}=e,r=this.normalizeInstanceIdentifier(e.instanceIdentifier);if(this.isInitialized(r))throw Error(`${this.name}(${r}) has already been initialized`);if(!this.isComponentSet())throw Error(`Component ${this.name} has not been registered yet`);let i=this.getOrInitializeService({instanceIdentifier:r,options:n});for(let[s,o]of this.instancesDeferred.entries()){let a=this.normalizeInstanceIdentifier(s);r===a&&o.resolve(i)}return i}onInit(e,n){var r;let i=this.normalizeInstanceIdentifier(n),s=(r=this.onInitCallbacks.get(i))!==null&&r!==void 0?r:new Set;s.add(e),this.onInitCallbacks.set(i,s);let o=this.instances.get(i);return o&&e(o,i),()=>{s.delete(e)}}invokeOnInitCallbacks(e,n){let r=this.onInitCallbacks.get(n);if(r)for(let i of r)try{i(e,n)}catch{}}getOrInitializeService({instanceIdentifier:e,options:n={}}){let r=this.instances.get(e);if(!r&&this.component&&(r=this.component.instanceFactory(this.container,{instanceIdentifier:YS(e),options:n}),this.instances.set(e,r),this.instancesOptions.set(e,n),this.invokeOnInitCallbacks(r,e),this.component.onInstanceCreated))try{this.component.onInstanceCreated(this.container,e,r)}catch{}return r||null}normalizeInstanceIdentifier(e=_r){return this.component?this.component.multipleInstances?e:_r:e}shouldAutoInitialize(){return!!this.component&&this.component.instantiationMode!=="EXPLICIT"}};function YS(t){return t===_r?void 0:t}function $S(t){return t.instantiationMode==="EAGER"}var Tl=class{constructor(e){this.name=e,this.providers=new Map}addComponent(e){let n=this.getProvider(e.name);if(n.isComponentSet())throw new Error(`Component ${e.name} has already been registered with ${this.name}`);n.setComponent(e)}addOrOverwriteComponent(e){this.getProvider(e.name).isComponentSet()&&this.providers.delete(e.name),this.addComponent(e)}getProvider(e){if(this.providers.has(e))return this.providers.get(e);let n=new xd(e,this);return this.providers.set(e,n),n}getProviders(){return Array.from(this.providers.values())}};var e3=[],H;(function(t){t[t.DEBUG=0]="DEBUG",t[t.VERBOSE=1]="VERBOSE",t[t.INFO=2]="INFO",t[t.WARN=3]="WARN",t[t.ERROR=4]="ERROR",t[t.SILENT=5]="SILENT"})(H||(H={}));var t3={debug:H.DEBUG,verbose:H.VERBOSE,info:H.INFO,warn:H.WARN,error:H.ERROR,silent:H.SILENT},n3=H.INFO,r3={[H.DEBUG]:"log",[H.VERBOSE]:"log",[H.INFO]:"info",[H.WARN]:"warn",[H.ERROR]:"error"},i3=(t,e,...n)=>{if(e<t.logLevel)return;let r=new Date().toISOString(),i=r3[e];if(i)console[i](`[${r}]  ${t.name}:`,...n);else throw new Error(`Attempted to log a message with an invalid logType (value: ${e})`)},xi=class{constructor(e){this.name=e,this._logLevel=n3,this._logHandler=i3,this._userLogHandler=null,e3.push(this)}get logLevel(){return this._logLevel}set logLevel(e){if(!(e in H))throw new TypeError(`Invalid value "${e}" assigned to \`logLevel\``);this._logLevel=e}setLogLevel(e){this._logLevel=typeof e=="string"?t3[e]:e}get logHandler(){return this._logHandler}set logHandler(e){if(typeof e!="function")throw new TypeError("Value assigned to `logHandler` must be a function");this._logHandler=e}get userLogHandler(){return this._userLogHandler}set userLogHandler(e){this._userLogHandler=e}debug(...e){this._userLogHandler&&this._userLogHandler(this,H.DEBUG,...e),this._logHandler(this,H.DEBUG,...e)}log(...e){this._userLogHandler&&this._userLogHandler(this,H.VERBOSE,...e),this._logHandler(this,H.VERBOSE,...e)}info(...e){this._userLogHandler&&this._userLogHandler(this,H.INFO,...e),this._logHandler(this,H.INFO,...e)}warn(...e){this._userLogHandler&&this._userLogHandler(this,H.WARN,...e),this._logHandler(this,H.WARN,...e)}error(...e){this._userLogHandler&&this._userLogHandler(this,H.ERROR,...e),this._logHandler(this,H.ERROR,...e)}};var s3=(t,e)=>e.some(n=>t instanceof n),cA,hA;function o3(){return cA||(cA=[IDBDatabase,IDBObjectStore,IDBIndex,IDBCursor,IDBTransaction])}function a3(){return hA||(hA=[IDBCursor.prototype.advance,IDBCursor.prototype.continue,IDBCursor.prototype.continuePrimaryKey])}var dA=new WeakMap,Cd=new WeakMap,fA=new WeakMap,Td=new WeakMap,Dd=new WeakMap;function l3(t){let e=new Promise((n,r)=>{let i=()=>{t.removeEventListener("success",s),t.removeEventListener("error",o)},s=()=>{n(Gt(t.result)),i()},o=()=>{r(t.error),i()};t.addEventListener("success",s),t.addEventListener("error",o)});return e.then(n=>{n instanceof IDBCursor&&dA.set(n,t)}).catch(()=>{}),Dd.set(e,t),e}function u3(t){if(Cd.has(t))return;let e=new Promise((n,r)=>{let i=()=>{t.removeEventListener("complete",s),t.removeEventListener("error",o),t.removeEventListener("abort",o)},s=()=>{n(),i()},o=()=>{r(t.error||new DOMException("AbortError","AbortError")),i()};t.addEventListener("complete",s),t.addEventListener("error",o),t.addEventListener("abort",o)});Cd.set(t,e)}var kd={get(t,e,n){if(t instanceof IDBTransaction){if(e==="done")return Cd.get(t);if(e==="objectStoreNames")return t.objectStoreNames||fA.get(t);if(e==="store")return n.objectStoreNames[1]?void 0:n.objectStore(n.objectStoreNames[0])}return Gt(t[e])},set(t,e,n){return t[e]=n,!0},has(t,e){return t instanceof IDBTransaction&&(e==="done"||e==="store")?!0:e in t}};function pA(t){kd=t(kd)}function c3(t){return t===IDBDatabase.prototype.transaction&&!("objectStoreNames"in IDBTransaction.prototype)?function(e,...n){let r=t.call(Cl(this),e,...n);return fA.set(r,e.sort?e.sort():[e]),Gt(r)}:a3().includes(t)?function(...e){return t.apply(Cl(this),e),Gt(dA.get(this))}:function(...e){return Gt(t.apply(Cl(this),e))}}function h3(t){return typeof t=="function"?c3(t):(t instanceof IDBTransaction&&u3(t),s3(t,o3())?new Proxy(t,kd):t)}function Gt(t){if(t instanceof IDBRequest)return l3(t);if(Td.has(t))return Td.get(t);let e=h3(t);return e!==t&&(Td.set(t,e),Dd.set(e,t)),e}var Cl=t=>Dd.get(t);function gA(t,e,{blocked:n,upgrade:r,blocking:i,terminated:s}={}){let o=indexedDB.open(t,e),a=Gt(o);return r&&o.addEventListener("upgradeneeded",l=>{r(Gt(o.result),l.oldVersion,l.newVersion,Gt(o.transaction),l)}),n&&o.addEventListener("blocked",l=>n(l.oldVersion,l.newVersion,l)),a.then(l=>{s&&l.addEventListener("close",()=>s()),i&&l.addEventListener("versionchange",u=>i(u.oldVersion,u.newVersion,u))}).catch(()=>{}),a}var d3=["get","getKey","getAll","getAllKeys","count"],f3=["put","add","delete","clear"],Nd=new Map;function mA(t,e){if(!(t instanceof IDBDatabase&&!(e in t)&&typeof e=="string"))return;if(Nd.get(e))return Nd.get(e);let n=e.replace(/FromIndex$/,""),r=e!==n,i=f3.includes(n);if(!(n in(r?IDBIndex:IDBObjectStore).prototype)||!(i||d3.includes(n)))return;let s=async function(o,...a){let l=this.transaction(o,i?"readwrite":"readonly"),u=l.store;return r&&(u=u.index(a.shift())),(await Promise.all([u[n](...a),i&&l.done]))[0]};return Nd.set(e,s),s}pA(t=>({...t,get:(e,n,r)=>mA(e,n)||t.get(e,n,r),has:(e,n)=>!!mA(e,n)||t.has(e,n)}));var _d=class{constructor(e){this.container=e}getPlatformInfoString(){return this.container.getProviders().map(n=>{if(p3(n)){let r=n.getImmediate();return`${r.library}/${r.version}`}else return null}).filter(n=>n).join(" ")}};function p3(t){let e=t.getComponent();return e?.type==="VERSION"}var Od="@firebase/app",yA="0.9.9";var Or=new xi("@firebase/app"),m3="@firebase/app-compat",g3="@firebase/analytics-compat",y3="@firebase/analytics",A3="@firebase/app-check-compat",v3="@firebase/app-check",w3="@firebase/auth",E3="@firebase/auth-compat",S3="@firebase/database",I3="@firebase/database-compat",x3="@firebase/functions",T3="@firebase/functions-compat",C3="@firebase/installations",k3="@firebase/installations-compat",D3="@firebase/messaging",N3="@firebase/messaging-compat",P3="@firebase/performance",_3="@firebase/performance-compat",O3="@firebase/remote-config",L3="@firebase/remote-config-compat",M3="@firebase/storage",b3="@firebase/storage-compat",R3="@firebase/firestore",z3="@firebase/firestore-compat",F3="firebase",B3="9.21.0";var Ld="[DEFAULT]",q3={[Od]:"fire-core",[m3]:"fire-core-compat",[y3]:"fire-analytics",[g3]:"fire-analytics-compat",[v3]:"fire-app-check",[A3]:"fire-app-check-compat",[w3]:"fire-auth",[E3]:"fire-auth-compat",[S3]:"fire-rtdb",[I3]:"fire-rtdb-compat",[x3]:"fire-fn",[T3]:"fire-fn-compat",[C3]:"fire-iid",[k3]:"fire-iid-compat",[D3]:"fire-fcm",[N3]:"fire-fcm-compat",[P3]:"fire-perf",[_3]:"fire-perf-compat",[O3]:"fire-rc",[L3]:"fire-rc-compat",[M3]:"fire-gcs",[b3]:"fire-gcs-compat",[R3]:"fire-fst",[z3]:"fire-fst-compat","fire-js":"fire-js",[F3]:"fire-js-all"};var kl=new Map,Md=new Map;function V3(t,e){try{t.container.addComponent(e)}catch(n){Or.debug(`Component ${e.name} failed to register with FirebaseApp ${t.name}`,n)}}function Zs(t){let e=t.name;if(Md.has(e))return Or.debug(`There were multiple attempts to register component ${e}.`),!1;Md.set(e,t);for(let n of kl.values())V3(n,t);return!0}function EA(t,e){let n=t.container.getProvider("heartbeat").getImmediate({optional:!0});return n&&n.triggerHeartbeat(),t.container.getProvider(e)}var U3={["no-app"]:"No Firebase App '{$appName}' has been created - call Firebase App.initializeApp()",["bad-app-name"]:"Illegal App name: '{$appName}",["duplicate-app"]:"Firebase App named '{$appName}' already exists with different options or config",["app-deleted"]:"Firebase App named '{$appName}' already deleted",["no-options"]:"Need to provide options, when not being deployed to hosting via source.",["invalid-app-argument"]:"firebase.{$appName}() takes either no argument or a Firebase App instance.",["invalid-log-argument"]:"First argument to `onLog` must be null or a function.",["idb-open"]:"Error thrown when opening IndexedDB. Original error: {$originalErrorMessage}.",["idb-get"]:"Error thrown when reading from IndexedDB. Original error: {$originalErrorMessage}.",["idb-set"]:"Error thrown when writing to IndexedDB. Original error: {$originalErrorMessage}.",["idb-delete"]:"Error thrown when deleting from IndexedDB. Original error: {$originalErrorMessage}."},Yn=new Gs("app","Firebase",U3);var bd=class{constructor(e,n,r){this._isDeleted=!1,this._options=Object.assign({},e),this._config=Object.assign({},n),this._name=n.name,this._automaticDataCollectionEnabled=n.automaticDataCollectionEnabled,this._container=r,this.container.addComponent(new yn("app",()=>this,"PUBLIC"))}get automaticDataCollectionEnabled(){return this.checkDestroyed(),this._automaticDataCollectionEnabled}set automaticDataCollectionEnabled(e){this.checkDestroyed(),this._automaticDataCollectionEnabled=e}get name(){return this.checkDestroyed(),this._name}get options(){return this.checkDestroyed(),this._options}get config(){return this.checkDestroyed(),this._config}get container(){return this._container}get isDeleted(){return this._isDeleted}set isDeleted(e){this._isDeleted=e}checkDestroyed(){if(this.isDeleted)throw Yn.create("app-deleted",{appName:this._name})}};var SA=B3;function Fd(t,e={}){let n=t;typeof e!="object"&&(e={name:e});let r=Object.assign({name:Ld,automaticDataCollectionEnabled:!1},e),i=r.name;if(typeof i!="string"||!i)throw Yn.create("bad-app-name",{appName:String(i)});if(n||(n=oA()),!n)throw Yn.create("no-options");let s=kl.get(i);if(s){if(Js(n,s.options)&&Js(r,s.config))return s;throw Yn.create("duplicate-app",{appName:i})}let o=new Tl(i);for(let l of Md.values())o.addComponent(l);let a=new bd(n,r,o);return kl.set(i,a),a}function IA(t=Ld){let e=kl.get(t);if(!e&&t===Ld)return Fd();if(!e)throw Yn.create("no-app",{appName:t});return e}function $n(t,e,n){var r;let i=(r=q3[t])!==null&&r!==void 0?r:t;n&&(i+=`-${n}`);let s=i.match(/\s|\//),o=e.match(/\s|\//);if(s||o){let a=[`Unable to register library "${i}" with version "${e}":`];s&&a.push(`library name "${i}" contains illegal characters (whitespace or "/")`),s&&o&&a.push("and"),o&&a.push(`version name "${e}" contains illegal characters (whitespace or "/")`),Or.warn(a.join(" "));return}Zs(new yn(`${i}-version`,()=>({library:i,version:e}),"VERSION"))}var j3="firebase-heartbeat-database",Q3=1,Ys="firebase-heartbeat-store",Pd=null;function xA(){return Pd||(Pd=gA(j3,Q3,{upgrade:(t,e)=>{switch(e){case 0:t.createObjectStore(Ys)}}}).catch(t=>{throw Yn.create("idb-open",{originalErrorMessage:t.message})})),Pd}async function H3(t){try{return(await xA()).transaction(Ys).objectStore(Ys).get(TA(t))}catch(e){if(e instanceof Rt)Or.warn(e.message);else{let n=Yn.create("idb-get",{originalErrorMessage:e?.message});Or.warn(n.message)}}}async function AA(t,e){try{let r=(await xA()).transaction(Ys,"readwrite");return await r.objectStore(Ys).put(e,TA(t)),r.done}catch(n){if(n instanceof Rt)Or.warn(n.message);else{let r=Yn.create("idb-set",{originalErrorMessage:n?.message});Or.warn(r.message)}}}function TA(t){return`${t.name}!${t.options.appId}`}var K3=1024,X3=30*24*60*60*1e3,Rd=class{constructor(e){this.container=e,this._heartbeatsCache=null;let n=this.container.getProvider("app").getImmediate();this._storage=new zd(n),this._heartbeatsCachePromise=this._storage.read().then(r=>(this._heartbeatsCache=r,r))}async triggerHeartbeat(){let n=this.container.getProvider("platform-logger").getImmediate().getPlatformInfoString(),r=vA();if(this._heartbeatsCache===null&&(this._heartbeatsCache=await this._heartbeatsCachePromise),!(this._heartbeatsCache.lastSentHeartbeatDate===r||this._heartbeatsCache.heartbeats.some(i=>i.date===r)))return this._heartbeatsCache.heartbeats.push({date:r,agent:n}),this._heartbeatsCache.heartbeats=this._heartbeatsCache.heartbeats.filter(i=>{let s=new Date(i.date).valueOf();return Date.now()-s<=X3}),this._storage.overwrite(this._heartbeatsCache)}async getHeartbeatsHeader(){if(this._heartbeatsCache===null&&await this._heartbeatsCachePromise,this._heartbeatsCache===null||this._heartbeatsCache.heartbeats.length===0)return"";let e=vA(),{heartbeatsToSend:n,unsentEntries:r}=W3(this._heartbeatsCache.heartbeats),i=Ws(JSON.stringify({version:2,heartbeats:n}));return this._heartbeatsCache.lastSentHeartbeatDate=e,r.length>0?(this._heartbeatsCache.heartbeats=r,await this._storage.overwrite(this._heartbeatsCache)):(this._heartbeatsCache.heartbeats=[],this._storage.overwrite(this._heartbeatsCache)),i}};function vA(){return new Date().toISOString().substring(0,10)}function W3(t,e=K3){let n=[],r=t.slice();for(let i of t){let s=n.find(o=>o.agent===i.agent);if(s){if(s.dates.push(i.date),wA(n)>e){s.dates.pop();break}}else if(n.push({agent:i.agent,dates:[i.date]}),wA(n)>e){n.pop();break}r=r.slice(1)}return{heartbeatsToSend:n,unsentEntries:r}}var zd=class{constructor(e){this.app=e,this._canUseIndexedDBPromise=this.runIndexedDBEnvironmentCheck()}async runIndexedDBEnvironmentCheck(){return Id()?lA().then(()=>!0).catch(()=>!1):!1}async read(){return await this._canUseIndexedDBPromise?await H3(this.app)||{heartbeats:[]}:{heartbeats:[]}}async overwrite(e){var n;if(await this._canUseIndexedDBPromise){let i=await this.read();return AA(this.app,{lastSentHeartbeatDate:(n=e.lastSentHeartbeatDate)!==null&&n!==void 0?n:i.lastSentHeartbeatDate,heartbeats:e.heartbeats})}else return}async add(e){var n;if(await this._canUseIndexedDBPromise){let i=await this.read();return AA(this.app,{lastSentHeartbeatDate:(n=e.lastSentHeartbeatDate)!==null&&n!==void 0?n:i.lastSentHeartbeatDate,heartbeats:[...i.heartbeats,...e.heartbeats]})}else return}};function wA(t){return Ws(JSON.stringify({version:2,heartbeats:t})).length}function G3(t){Zs(new yn("platform-logger",e=>new _d(e),"PRIVATE")),Zs(new yn("heartbeat",e=>new Rd(e),"PRIVATE")),$n(Od,yA,t),$n(Od,yA,"esm2017"),$n("fire-js","")}G3("");var J3="firebase",Z3="9.21.0";$n(J3,Z3,"app");var Y3=typeof globalThis<"u"?globalThis:typeof window<"u"?window:typeof global<"u"?global:typeof self<"u"?self:{},Ft={},I,lf=lf||{},b=Y3||self;function bl(){}function Hl(t){var e=typeof t;return e=e!="object"?e:t?Array.isArray(t)?"array":e:"null",e=="array"||e=="object"&&typeof t.length=="number"}function uo(t){var e=typeof t;return e=="object"&&t!=null||e=="function"}function $3(t){return Object.prototype.hasOwnProperty.call(t,Bd)&&t[Bd]||(t[Bd]=++e6)}var Bd="closure_uid_"+(1e9*Math.random()>>>0),e6=0;function t6(t,e,n){return t.call.apply(t.bind,arguments)}function n6(t,e,n){if(!t)throw Error();if(2<arguments.length){var r=Array.prototype.slice.call(arguments,2);return function(){var i=Array.prototype.slice.call(arguments);return Array.prototype.unshift.apply(i,r),t.apply(e,i)}}return function(){return t.apply(e,arguments)}}function Ve(t,e,n){return Function.prototype.bind&&Function.prototype.bind.toString().indexOf("native code")!=-1?Ve=t6:Ve=n6,Ve.apply(null,arguments)}function Dl(t,e){var n=Array.prototype.slice.call(arguments,1);return function(){var r=n.slice();return r.push.apply(r,arguments),t.apply(this,r)}}function Te(t,e){function n(){}n.prototype=e.prototype,t.$=e.prototype,t.prototype=new n,t.prototype.constructor=t,t.ac=function(r,i,s){for(var o=Array(arguments.length-2),a=2;a<arguments.length;a++)o[a-2]=arguments[a];return e.prototype[i].apply(r,o)}}function er(){this.s=this.s,this.o=this.o}var r6=0;er.prototype.s=!1;er.prototype.ra=function(){!this.s&&(this.s=!0,this.N(),r6!=0)&&$3(this)};er.prototype.N=function(){if(this.o)for(;this.o.length;)this.o.shift()()};var BA=Array.prototype.indexOf?function(t,e){return Array.prototype.indexOf.call(t,e,void 0)}:function(t,e){if(typeof t=="string")return typeof e!="string"||e.length!=1?-1:t.indexOf(e,0);for(let n=0;n<t.length;n++)if(n in t&&t[n]===e)return n;return-1};function uf(t){let e=t.length;if(0<e){let n=Array(e);for(let r=0;r<e;r++)n[r]=t[r];return n}return[]}function CA(t,e){for(let n=1;n<arguments.length;n++){let r=arguments[n];if(Hl(r)){let i=t.length||0,s=r.length||0;t.length=i+s;for(let o=0;o<s;o++)t[i+o]=r[o]}else t.push(r)}}function Ue(t,e){this.type=t,this.g=this.target=e,this.defaultPrevented=!1}Ue.prototype.h=function(){this.defaultPrevented=!0};var i6=function(){if(!b.addEventListener||!Object.defineProperty)return!1;var t=!1,e=Object.defineProperty({},"passive",{get:function(){t=!0}});try{b.addEventListener("test",bl,e),b.removeEventListener("test",bl,e)}catch{}return t}();function Rl(t){return/^[\s\xa0]*$/.test(t)}var kA=String.prototype.trim?function(t){return t.trim()}:function(t){return/^[\s\xa0]*([\s\S]*?)[\s\xa0]*$/.exec(t)[1]};function qd(t,e){return t<e?-1:t>e?1:0}function Kl(){var t=b.navigator;return t&&(t=t.userAgent)?t:""}function Jt(t){return Kl().indexOf(t)!=-1}function cf(t){return cf[" "](t),t}cf[" "]=bl;function qA(t,e,n){return Object.prototype.hasOwnProperty.call(t,e)?t[e]:t[e]=n(e)}var s6=Jt("Opera"),Di=Jt("Trident")||Jt("MSIE"),VA=Jt("Edge"),Hd=VA||Di,UA=Jt("Gecko")&&!(Kl().toLowerCase().indexOf("webkit")!=-1&&!Jt("Edge"))&&!(Jt("Trident")||Jt("MSIE"))&&!Jt("Edge"),o6=Kl().toLowerCase().indexOf("webkit")!=-1&&!Jt("Edge");function jA(){var t=b.document;return t?t.documentMode:void 0}var zl;e:{if(Nl="",Pl=function(){var t=Kl();if(UA)return/rv:([^\);]+)(\)|;)/.exec(t);if(VA)return/Edge\/([\d\.]+)/.exec(t);if(Di)return/\b(?:MSIE|rv)[: ]([^\);]+)(\)|;)/.exec(t);if(o6)return/WebKit\/(\S+)/.exec(t);if(s6)return/(?:Version)[ \/]?(\S+)/.exec(t)}(),Pl&&(Nl=Pl?Pl[1]:""),Di&&(_l=jA(),_l!=null&&_l>parseFloat(Nl))){zl=String(_l);break e}zl=Nl}var Nl,Pl,_l,a6={};function l6(){return qA(a6,9,function(){let t=0,e=kA(String(zl)).split("."),n=kA("9").split("."),r=Math.max(e.length,n.length);for(let o=0;t==0&&o<r;o++){var i=e[o]||"",s=n[o]||"";do{if(i=/(\d*)(\D*)(.*)/.exec(i)||["","","",""],s=/(\d*)(\D*)(.*)/.exec(s)||["","","",""],i[0].length==0&&s[0].length==0)break;t=qd(i[1].length==0?0:parseInt(i[1],10),s[1].length==0?0:parseInt(s[1],10))||qd(i[2].length==0,s[2].length==0)||qd(i[2],s[2]),i=i[3],s=s[3]}while(t==0)}return 0<=t})}var Kd;b.document&&Di?(Vd=jA(),Kd=Vd||parseInt(zl,10)||void 0):Kd=void 0;var Vd,u6=Kd;function io(t,e){if(Ue.call(this,t?t.type:""),this.relatedTarget=this.g=this.target=null,this.button=this.screenY=this.screenX=this.clientY=this.clientX=0,this.key="",this.metaKey=this.shiftKey=this.altKey=this.ctrlKey=!1,this.state=null,this.pointerId=0,this.pointerType="",this.i=null,t){var n=this.type=t.type,r=t.changedTouches&&t.changedTouches.length?t.changedTouches[0]:null;if(this.target=t.target||t.srcElement,this.g=e,e=t.relatedTarget){if(UA){e:{try{cf(e.nodeName);var i=!0;break e}catch{}i=!1}i||(e=null)}}else n=="mouseover"?e=t.fromElement:n=="mouseout"&&(e=t.toElement);this.relatedTarget=e,r?(this.clientX=r.clientX!==void 0?r.clientX:r.pageX,this.clientY=r.clientY!==void 0?r.clientY:r.pageY,this.screenX=r.screenX||0,this.screenY=r.screenY||0):(this.clientX=t.clientX!==void 0?t.clientX:t.pageX,this.clientY=t.clientY!==void 0?t.clientY:t.pageY,this.screenX=t.screenX||0,this.screenY=t.screenY||0),this.button=t.button,this.key=t.key||"",this.ctrlKey=t.ctrlKey,this.altKey=t.altKey,this.shiftKey=t.shiftKey,this.metaKey=t.metaKey,this.pointerId=t.pointerId||0,this.pointerType=typeof t.pointerType=="string"?t.pointerType:c6[t.pointerType]||"",this.state=t.state,this.i=t,t.defaultPrevented&&io.$.h.call(this)}}Te(io,Ue);var c6={2:"touch",3:"pen",4:"mouse"};io.prototype.h=function(){io.$.h.call(this);var t=this.i;t.preventDefault?t.preventDefault():t.returnValue=!1};var co="closure_listenable_"+(1e6*Math.random()|0),h6=0;function d6(t,e,n,r,i){this.listener=t,this.proxy=null,this.src=e,this.type=n,this.capture=!!r,this.la=i,this.key=++h6,this.fa=this.ia=!1}function Xl(t){t.fa=!0,t.listener=null,t.proxy=null,t.src=null,t.la=null}function hf(t,e,n){for(let r in t)e.call(n,t[r],r,t)}function QA(t){let e={};for(let n in t)e[n]=t[n];return e}var DA="constructor hasOwnProperty isPrototypeOf propertyIsEnumerable toLocaleString toString valueOf".split(" ");function HA(t,e){let n,r;for(let i=1;i<arguments.length;i++){r=arguments[i];for(n in r)t[n]=r[n];for(let s=0;s<DA.length;s++)n=DA[s],Object.prototype.hasOwnProperty.call(r,n)&&(t[n]=r[n])}}function Wl(t){this.src=t,this.g={},this.h=0}Wl.prototype.add=function(t,e,n,r,i){var s=t.toString();t=this.g[s],t||(t=this.g[s]=[],this.h++);var o=Wd(t,e,r,i);return-1<o?(e=t[o],n||(e.ia=!1)):(e=new d6(e,this.src,s,!!r,i),e.ia=n,t.push(e)),e};function Xd(t,e){var n=e.type;if(n in t.g){var r=t.g[n],i=BA(r,e),s;(s=0<=i)&&Array.prototype.splice.call(r,i,1),s&&(Xl(e),t.g[n].length==0&&(delete t.g[n],t.h--))}}function Wd(t,e,n,r){for(var i=0;i<t.length;++i){var s=t[i];if(!s.fa&&s.listener==e&&s.capture==!!n&&s.la==r)return i}return-1}var df="closure_lm_"+(1e6*Math.random()|0),Ud={};function KA(t,e,n,r,i){if(r&&r.once)return WA(t,e,n,r,i);if(Array.isArray(e)){for(var s=0;s<e.length;s++)KA(t,e[s],n,r,i);return null}return n=mf(n),t&&t[co]?t.O(e,n,uo(r)?!!r.capture:!!r,i):XA(t,e,n,!1,r,i)}function XA(t,e,n,r,i,s){if(!e)throw Error("Invalid event type");var o=uo(i)?!!i.capture:!!i,a=pf(t);if(a||(t[df]=a=new Wl(t)),n=a.add(e,n,r,o,s),n.proxy)return n;if(r=f6(),n.proxy=r,r.src=t,r.listener=n,t.addEventListener)i6||(i=o),i===void 0&&(i=!1),t.addEventListener(e.toString(),r,i);else if(t.attachEvent)t.attachEvent(JA(e.toString()),r);else if(t.addListener&&t.removeListener)t.addListener(r);else throw Error("addEventListener and attachEvent are unavailable.");return n}function f6(){function t(n){return e.call(t.src,t.listener,n)}let e=p6;return t}function WA(t,e,n,r,i){if(Array.isArray(e)){for(var s=0;s<e.length;s++)WA(t,e[s],n,r,i);return null}return n=mf(n),t&&t[co]?t.P(e,n,uo(r)?!!r.capture:!!r,i):XA(t,e,n,!0,r,i)}function GA(t,e,n,r,i){if(Array.isArray(e))for(var s=0;s<e.length;s++)GA(t,e[s],n,r,i);else r=uo(r)?!!r.capture:!!r,n=mf(n),t&&t[co]?(t=t.i,e=String(e).toString(),e in t.g&&(s=t.g[e],n=Wd(s,n,r,i),-1<n&&(Xl(s[n]),Array.prototype.splice.call(s,n,1),s.length==0&&(delete t.g[e],t.h--)))):t&&(t=pf(t))&&(e=t.g[e.toString()],t=-1,e&&(t=Wd(e,n,r,i)),(n=-1<t?e[t]:null)&&ff(n))}function ff(t){if(typeof t!="number"&&t&&!t.fa){var e=t.src;if(e&&e[co])Xd(e.i,t);else{var n=t.type,r=t.proxy;e.removeEventListener?e.removeEventListener(n,r,t.capture):e.detachEvent?e.detachEvent(JA(n),r):e.addListener&&e.removeListener&&e.removeListener(r),(n=pf(e))?(Xd(n,t),n.h==0&&(n.src=null,e[df]=null)):Xl(t)}}}function JA(t){return t in Ud?Ud[t]:Ud[t]="on"+t}function p6(t,e){if(t.fa)t=!0;else{e=new io(e,this);var n=t.listener,r=t.la||t.src;t.ia&&ff(t),t=n.call(r,e)}return t}function pf(t){return t=t[df],t instanceof Wl?t:null}var jd="__closure_events_fn_"+(1e9*Math.random()>>>0);function mf(t){return typeof t=="function"?t:(t[jd]||(t[jd]=function(e){return t.handleEvent(e)}),t[jd])}function xe(){er.call(this),this.i=new Wl(this),this.S=this,this.J=null}Te(xe,er);xe.prototype[co]=!0;xe.prototype.removeEventListener=function(t,e,n,r){GA(this,t,e,n,r)};function Me(t,e){var n,r=t.J;if(r)for(n=[];r;r=r.J)n.push(r);if(t=t.S,r=e.type||e,typeof e=="string")e=new Ue(e,t);else if(e instanceof Ue)e.target=e.target||t;else{var i=e;e=new Ue(r,t),HA(e,i)}if(i=!0,n)for(var s=n.length-1;0<=s;s--){var o=e.g=n[s];i=Ol(o,r,!0,e)&&i}if(o=e.g=t,i=Ol(o,r,!0,e)&&i,i=Ol(o,r,!1,e)&&i,n)for(s=0;s<n.length;s++)o=e.g=n[s],i=Ol(o,r,!1,e)&&i}xe.prototype.N=function(){if(xe.$.N.call(this),this.i){var t=this.i,e;for(e in t.g){for(var n=t.g[e],r=0;r<n.length;r++)Xl(n[r]);delete t.g[e],t.h--}}this.J=null};xe.prototype.O=function(t,e,n,r){return this.i.add(String(t),e,!1,n,r)};xe.prototype.P=function(t,e,n,r){return this.i.add(String(t),e,!0,n,r)};function Ol(t,e,n,r){if(e=t.i.g[String(e)],!e)return!0;e=e.concat();for(var i=!0,s=0;s<e.length;++s){var o=e[s];if(o&&!o.fa&&o.capture==n){var a=o.listener,l=o.la||o.src;o.ia&&Xd(t.i,o),i=a.call(l,r)!==!1&&i}}return i&&!r.defaultPrevented}var gf=b.JSON.stringify;function m6(){var t=$A;let e=null;return t.g&&(e=t.g,t.g=t.g.next,t.g||(t.h=null),e.next=null),e}var Gd=class{constructor(){this.h=this.g=null}add(e,n){let r=ZA.get();r.set(e,n),this.h?this.h.next=r:this.g=r,this.h=r}},ZA=new class{constructor(t,e){this.i=t,this.j=e,this.h=0,this.g=null}get(){let t;return 0<this.h?(this.h--,t=this.g,this.g=t.next,t.next=null):t=this.i(),t}}(()=>new Jd,t=>t.reset()),Jd=class{constructor(){this.next=this.g=this.h=null}set(e,n){this.h=e,this.g=n,this.next=null}reset(){this.next=this.g=this.h=null}};function g6(t){b.setTimeout(()=>{throw t},0)}function YA(t,e){Zd||y6(),Yd||(Zd(),Yd=!0),$A.add(t,e)}var Zd;function y6(){var t=b.Promise.resolve(void 0);Zd=function(){t.then(A6)}}var Yd=!1,$A=new Gd;function A6(){for(var t;t=m6();){try{t.h.call(t.g)}catch(n){g6(n)}var e=ZA;e.j(t),100>e.h&&(e.h++,t.next=e.g,e.g=t)}Yd=!1}function Gl(t,e){xe.call(this),this.h=t||1,this.g=e||b,this.j=Ve(this.qb,this),this.l=Date.now()}Te(Gl,xe);I=Gl.prototype;I.ga=!1;I.T=null;I.qb=function(){if(this.ga){var t=Date.now()-this.l;0<t&&t<.8*this.h?this.T=this.g.setTimeout(this.j,this.h-t):(this.T&&(this.g.clearTimeout(this.T),this.T=null),Me(this,"tick"),this.ga&&(yf(this),this.start()))}};I.start=function(){this.ga=!0,this.T||(this.T=this.g.setTimeout(this.j,this.h),this.l=Date.now())};function yf(t){t.ga=!1,t.T&&(t.g.clearTimeout(t.T),t.T=null)}I.N=function(){Gl.$.N.call(this),yf(this),delete this.g};function Af(t,e,n){if(typeof t=="function")n&&(t=Ve(t,n));else if(t&&typeof t.handleEvent=="function")t=Ve(t.handleEvent,t);else throw Error("Invalid listener argument");return 2147483647<Number(e)?-1:b.setTimeout(t,e||0)}function ev(t){t.g=Af(()=>{t.g=null,t.i&&(t.i=!1,ev(t))},t.j);let e=t.h;t.h=null,t.m.apply(null,e)}var $d=class extends er{constructor(e,n){super(),this.m=e,this.j=n,this.h=null,this.i=!1,this.g=null}l(e){this.h=arguments,this.g?this.i=!0:ev(this)}N(){super.N(),this.g&&(b.clearTimeout(this.g),this.g=null,this.i=!1,this.h=null)}};function so(t){er.call(this),this.h=t,this.g={}}Te(so,er);var NA=[];function tv(t,e,n,r){Array.isArray(n)||(n&&(NA[0]=n.toString()),n=NA);for(var i=0;i<n.length;i++){var s=KA(e,n[i],r||t.handleEvent,!1,t.h||t);if(!s)break;t.g[s.key]=s}}function nv(t){hf(t.g,function(e,n){this.g.hasOwnProperty(n)&&ff(e)},t),t.g={}}so.prototype.N=function(){so.$.N.call(this),nv(this)};so.prototype.handleEvent=function(){throw Error("EventHandler.handleEvent not implemented")};function Jl(){this.g=!0}Jl.prototype.Ea=function(){this.g=!1};function v6(t,e,n,r,i,s){t.info(function(){if(t.g)if(s)for(var o="",a=s.split("&"),l=0;l<a.length;l++){var u=a[l].split("=");if(1<u.length){var c=u[0];u=u[1];var h=c.split("_");o=2<=h.length&&h[1]=="type"?o+(c+"="+u+"&"):o+(c+"=redacted&")}}else o=null;else o=s;return"XMLHTTP REQ ("+r+") [attempt "+i+"]: "+e+`
`+n+`
`+o})}function w6(t,e,n,r,i,s,o){t.info(function(){return"XMLHTTP RESP ("+r+") [ attempt "+i+"]: "+e+`
`+n+`
`+s+" "+o})}function Ci(t,e,n,r){t.info(function(){return"XMLHTTP TEXT ("+e+"): "+S6(t,n)+(r?" "+r:"")})}function E6(t,e){t.info(function(){return"TIMEOUT: "+e})}Jl.prototype.info=function(){};function S6(t,e){if(!t.g)return e;if(!e)return null;try{var n=JSON.parse(e);if(n){for(t=0;t<n.length;t++)if(Array.isArray(n[t])){var r=n[t];if(!(2>r.length)){var i=r[1];if(Array.isArray(i)&&!(1>i.length)){var s=i[0];if(s!="noop"&&s!="stop"&&s!="close")for(var o=1;o<i.length;o++)i[o]=""}}}}return gf(n)}catch{return e}}var Rr={},PA=null;function Zl(){return PA=PA||new xe}Rr.Ta="serverreachability";function rv(t){Ue.call(this,Rr.Ta,t)}Te(rv,Ue);function oo(t){let e=Zl();Me(e,new rv(e))}Rr.STAT_EVENT="statevent";function iv(t,e){Ue.call(this,Rr.STAT_EVENT,t),this.stat=e}Te(iv,Ue);function Ze(t){let e=Zl();Me(e,new iv(e,t))}Rr.Ua="timingevent";function sv(t,e){Ue.call(this,Rr.Ua,t),this.size=e}Te(sv,Ue);function ho(t,e){if(typeof t!="function")throw Error("Fn must not be null and must be a function");return b.setTimeout(function(){t()},e)}var Yl={NO_ERROR:0,rb:1,Eb:2,Db:3,yb:4,Cb:5,Fb:6,Qa:7,TIMEOUT:8,Ib:9},ov={wb:"complete",Sb:"success",Ra:"error",Qa:"abort",Kb:"ready",Lb:"readystatechange",TIMEOUT:"timeout",Gb:"incrementaldata",Jb:"progress",zb:"downloadprogress",$b:"uploadprogress"};function vf(){}vf.prototype.h=null;function _A(t){return t.h||(t.h=t.i())}function av(){}var fo={OPEN:"a",vb:"b",Ra:"c",Hb:"d"};function wf(){Ue.call(this,"d")}Te(wf,Ue);function Ef(){Ue.call(this,"c")}Te(Ef,Ue);var ef;function $l(){}Te($l,vf);$l.prototype.g=function(){return new XMLHttpRequest};$l.prototype.i=function(){return{}};ef=new $l;function po(t,e,n,r){this.l=t,this.j=e,this.m=n,this.W=r||1,this.U=new so(this),this.P=I6,t=Hd?125:void 0,this.V=new Gl(t),this.I=null,this.i=!1,this.s=this.A=this.v=this.L=this.G=this.Y=this.B=null,this.F=[],this.g=null,this.C=0,this.o=this.u=null,this.aa=-1,this.J=!1,this.O=0,this.M=null,this.ca=this.K=this.ba=this.S=!1,this.h=new lv}function lv(){this.i=null,this.g="",this.h=!1}var I6=45e3,tf={},Fl={};I=po.prototype;I.setTimeout=function(t){this.P=t};function nf(t,e,n){t.L=1,t.v=tu(wn(e)),t.s=n,t.S=!0,uv(t,null)}function uv(t,e){t.G=Date.now(),mo(t),t.A=wn(t.v);var n=t.A,r=t.W;Array.isArray(r)||(r=[String(r)]),yv(n.i,"t",r),t.C=0,n=t.l.I,t.h=new lv,t.g=Fv(t.l,n?e:null,!t.s),0<t.O&&(t.M=new $d(Ve(t.Pa,t,t.g),t.O)),tv(t.U,t.g,"readystatechange",t.nb),e=t.I?QA(t.I):{},t.s?(t.u||(t.u="POST"),e["Content-Type"]="application/x-www-form-urlencoded",t.g.ha(t.A,t.u,t.s,e)):(t.u="GET",t.g.ha(t.A,t.u,null,e)),oo(),v6(t.j,t.u,t.A,t.m,t.W,t.s)}I.nb=function(t){t=t.target;let e=this.M;e&&An(t)==3?e.l():this.Pa(t)};I.Pa=function(t){try{if(t==this.g)e:{let c=An(this.g);var e=this.g.Ia();let h=this.g.da();if(!(3>c)&&(c!=3||Hd||this.g&&(this.h.h||this.g.ja()||bA(this.g)))){this.J||c!=4||e==7||(e==8||0>=h?oo(3):oo(2)),eu(this);var n=this.g.da();this.aa=n;t:if(cv(this)){var r=bA(this.g);t="";var i=r.length,s=An(this.g)==4;if(!this.h.i){if(typeof TextDecoder>"u"){Lr(this),ro(this);var o="";break t}this.h.i=new b.TextDecoder}for(e=0;e<i;e++)this.h.h=!0,t+=this.h.i.decode(r[e],{stream:s&&e==i-1});r.splice(0,i),this.h.g+=t,this.C=0,o=this.h.g}else o=this.g.ja();if(this.i=n==200,w6(this.j,this.u,this.A,this.m,this.W,c,n),this.i){if(this.ba&&!this.K){t:{if(this.g){var a,l=this.g;if((a=l.g?l.g.getResponseHeader("X-HTTP-Initial-Response"):null)&&!Rl(a)){var u=a;break t}}u=null}if(n=u)Ci(this.j,this.m,n,"Initial handshake response via X-HTTP-Initial-Response"),this.K=!0,rf(this,n);else{this.i=!1,this.o=3,Ze(12),Lr(this),ro(this);break e}}this.S?(hv(this,c,o),Hd&&this.i&&c==3&&(tv(this.U,this.V,"tick",this.mb),this.V.start())):(Ci(this.j,this.m,o,null),rf(this,o)),c==4&&Lr(this),this.i&&!this.J&&(c==4?Mv(this.l,this):(this.i=!1,mo(this)))}else n==400&&0<o.indexOf("Unknown SID")?(this.o=3,Ze(12)):(this.o=0,Ze(13)),Lr(this),ro(this)}}}catch{}finally{}};function cv(t){return t.g?t.u=="GET"&&t.L!=2&&t.l.Ha:!1}function hv(t,e,n){let r=!0,i;for(;!t.J&&t.C<n.length;)if(i=x6(t,n),i==Fl){e==4&&(t.o=4,Ze(14),r=!1),Ci(t.j,t.m,null,"[Incomplete Response]");break}else if(i==tf){t.o=4,Ze(15),Ci(t.j,t.m,n,"[Invalid Chunk]"),r=!1;break}else Ci(t.j,t.m,i,null),rf(t,i);cv(t)&&i!=Fl&&i!=tf&&(t.h.g="",t.C=0),e!=4||n.length!=0||t.h.h||(t.o=1,Ze(16),r=!1),t.i=t.i&&r,r?0<n.length&&!t.ca&&(t.ca=!0,e=t.l,e.g==t&&e.ca&&!e.L&&(e.j.info("Great, no buffering proxy detected. Bytes received: "+n.length),Df(e),e.L=!0,Ze(11))):(Ci(t.j,t.m,n,"[Invalid Chunked Response]"),Lr(t),ro(t))}I.mb=function(){if(this.g){var t=An(this.g),e=this.g.ja();this.C<e.length&&(eu(this),hv(this,t,e),this.i&&t!=4&&mo(this))}};function x6(t,e){var n=t.C,r=e.indexOf(`
`,n);return r==-1?Fl:(n=Number(e.substring(n,r)),isNaN(n)?tf:(r+=1,r+n>e.length?Fl:(e=e.substr(r,n),t.C=r+n,e)))}I.cancel=function(){this.J=!0,Lr(this)};function mo(t){t.Y=Date.now()+t.P,dv(t,t.P)}function dv(t,e){if(t.B!=null)throw Error("WatchDog timer not null");t.B=ho(Ve(t.lb,t),e)}function eu(t){t.B&&(b.clearTimeout(t.B),t.B=null)}I.lb=function(){this.B=null;let t=Date.now();0<=t-this.Y?(E6(this.j,this.A),this.L!=2&&(oo(),Ze(17)),Lr(this),this.o=2,ro(this)):dv(this,this.Y-t)};function ro(t){t.l.H==0||t.J||Mv(t.l,t)}function Lr(t){eu(t);var e=t.M;e&&typeof e.ra=="function"&&e.ra(),t.M=null,yf(t.V),nv(t.U),t.g&&(e=t.g,t.g=null,e.abort(),e.ra())}function rf(t,e){try{var n=t.l;if(n.H!=0&&(n.g==t||sf(n.h,t))){if(!t.K&&sf(n.h,t)&&n.H==3){try{var r=n.Ja.g.parse(e)}catch{r=null}if(Array.isArray(r)&&r.length==3){var i=r;if(i[0]==0){e:if(!n.u){if(n.g)if(n.g.G+3e3<t.G)Vl(n),iu(n);else break e;kf(n),Ze(18)}}else n.Fa=i[1],0<n.Fa-n.V&&37500>i[2]&&n.M&&n.A==0&&!n.v&&(n.v=ho(Ve(n.ib,n),6e3));if(1>=wv(n.h)&&n.na){try{n.na()}catch{}n.na=void 0}}else Mr(n,11)}else if((t.K||n.g==t)&&Vl(n),!Rl(e))for(i=n.Ja.g.parse(e),e=0;e<i.length;e++){let u=i[e];if(n.V=u[0],u=u[1],n.H==2)if(u[0]=="c"){n.J=u[1],n.oa=u[2];let c=u[3];c!=null&&(n.qa=c,n.j.info("VER="+n.qa));let h=u[4];h!=null&&(n.Ga=h,n.j.info("SVER="+n.Ga));let p=u[5];p!=null&&typeof p=="number"&&0<p&&(r=1.5*p,n.K=r,n.j.info("backChannelRequestTimeoutMs_="+r)),r=n;let g=t.g;if(g){let y=g.g?g.g.getResponseHeader("X-Client-Wire-Protocol"):null;if(y){var s=r.h;s.g||y.indexOf("spdy")==-1&&y.indexOf("quic")==-1&&y.indexOf("h2")==-1||(s.j=s.l,s.g=new Set,s.h&&(Sf(s,s.h),s.h=null))}if(r.F){let A=g.g?g.g.getResponseHeader("X-HTTP-Session-Id"):null;A&&(r.Da=A,ie(r.G,r.F,A))}}n.H=3,n.l&&n.l.Ba(),n.ca&&(n.S=Date.now()-t.G,n.j.info("Handshake RTT: "+n.S+"ms")),r=n;var o=t;if(r.wa=zv(r,r.I?r.oa:null,r.Y),o.K){Ev(r.h,o);var a=o,l=r.K;l&&a.setTimeout(l),a.B&&(eu(a),mo(a)),r.g=o}else Ov(r);0<n.i.length&&su(n)}else u[0]!="stop"&&u[0]!="close"||Mr(n,7);else n.H==3&&(u[0]=="stop"||u[0]=="close"?u[0]=="stop"?Mr(n,7):Cf(n):u[0]!="noop"&&n.l&&n.l.Aa(u),n.A=0)}}oo(4)}catch{}}function T6(t){if(t.Z&&typeof t.Z=="function")return t.Z();if(typeof Map<"u"&&t instanceof Map||typeof Set<"u"&&t instanceof Set)return Array.from(t.values());if(typeof t=="string")return t.split("");if(Hl(t)){for(var e=[],n=t.length,r=0;r<n;r++)e.push(t[r]);return e}e=[],n=0;for(r in t)e[n++]=t[r];return e}function C6(t){if(t.sa&&typeof t.sa=="function")return t.sa();if(!t.Z||typeof t.Z!="function"){if(typeof Map<"u"&&t instanceof Map)return Array.from(t.keys());if(!(typeof Set<"u"&&t instanceof Set)){if(Hl(t)||typeof t=="string"){var e=[];t=t.length;for(var n=0;n<t;n++)e.push(n);return e}e=[],n=0;for(let r in t)e[n++]=r;return e}}}function fv(t,e){if(t.forEach&&typeof t.forEach=="function")t.forEach(e,void 0);else if(Hl(t)||typeof t=="string")Array.prototype.forEach.call(t,e,void 0);else for(var n=C6(t),r=T6(t),i=r.length,s=0;s<i;s++)e.call(void 0,r[s],n&&n[s],t)}var pv=RegExp("^(?:([^:/?#.]+):)?(?://(?:([^\\\\/?#]*)@)?([^\\\\/?#]*?)(?::([0-9]+))?(?=[\\\\/?#]|$))?([^?#]+)?(?:\\?([^#]*))?(?:#([\\s\\S]*))?$");function k6(t,e){if(t){t=t.split("&");for(var n=0;n<t.length;n++){var r=t[n].indexOf("="),i=null;if(0<=r){var s=t[n].substring(0,r);i=t[n].substring(r+1)}else s=t[n];e(s,i?decodeURIComponent(i.replace(/\+/g," ")):"")}}}function br(t,e){if(this.g=this.s=this.j="",this.m=null,this.o=this.l="",this.h=!1,t instanceof br){this.h=e!==void 0?e:t.h,Bl(this,t.j),this.s=t.s,this.g=t.g,ql(this,t.m),this.l=t.l,e=t.i;var n=new ao;n.i=e.i,e.g&&(n.g=new Map(e.g),n.h=e.h),OA(this,n),this.o=t.o}else t&&(n=String(t).match(pv))?(this.h=!!e,Bl(this,n[1]||"",!0),this.s=to(n[2]||""),this.g=to(n[3]||"",!0),ql(this,n[4]),this.l=to(n[5]||"",!0),OA(this,n[6]||"",!0),this.o=to(n[7]||"")):(this.h=!!e,this.i=new ao(null,this.h))}br.prototype.toString=function(){var t=[],e=this.j;e&&t.push(no(e,LA,!0),":");var n=this.g;return(n||e=="file")&&(t.push("//"),(e=this.s)&&t.push(no(e,LA,!0),"@"),t.push(encodeURIComponent(String(n)).replace(/%25([0-9a-fA-F]{2})/g,"%$1")),n=this.m,n!=null&&t.push(":",String(n))),(n=this.l)&&(this.g&&n.charAt(0)!="/"&&t.push("/"),t.push(no(n,n.charAt(0)=="/"?P6:N6,!0))),(n=this.i.toString())&&t.push("?",n),(n=this.o)&&t.push("#",no(n,O6)),t.join("")};function wn(t){return new br(t)}function Bl(t,e,n){t.j=n?to(e,!0):e,t.j&&(t.j=t.j.replace(/:$/,""))}function ql(t,e){if(e){if(e=Number(e),isNaN(e)||0>e)throw Error("Bad port number "+e);t.m=e}else t.m=null}function OA(t,e,n){e instanceof ao?(t.i=e,L6(t.i,t.h)):(n||(e=no(e,_6)),t.i=new ao(e,t.h))}function ie(t,e,n){t.i.set(e,n)}function tu(t){return ie(t,"zx",Math.floor(2147483648*Math.random()).toString(36)+Math.abs(Math.floor(2147483648*Math.random())^Date.now()).toString(36)),t}function to(t,e){return t?e?decodeURI(t.replace(/%25/g,"%2525")):decodeURIComponent(t):""}function no(t,e,n){return typeof t=="string"?(t=encodeURI(t).replace(e,D6),n&&(t=t.replace(/%25([0-9a-fA-F]{2})/g,"%$1")),t):null}function D6(t){return t=t.charCodeAt(0),"%"+(t>>4&15).toString(16)+(t&15).toString(16)}var LA=/[#\/\?@]/g,N6=/[#\?:]/g,P6=/[#\?]/g,_6=/[#\?@]/g,O6=/#/g;function ao(t,e){this.h=this.g=null,this.i=t||null,this.j=!!e}function tr(t){t.g||(t.g=new Map,t.h=0,t.i&&k6(t.i,function(e,n){t.add(decodeURIComponent(e.replace(/\+/g," ")),n)}))}I=ao.prototype;I.add=function(t,e){tr(this),this.i=null,t=Ni(this,t);var n=this.g.get(t);return n||this.g.set(t,n=[]),n.push(e),this.h+=1,this};function mv(t,e){tr(t),e=Ni(t,e),t.g.has(e)&&(t.i=null,t.h-=t.g.get(e).length,t.g.delete(e))}function gv(t,e){return tr(t),e=Ni(t,e),t.g.has(e)}I.forEach=function(t,e){tr(this),this.g.forEach(function(n,r){n.forEach(function(i){t.call(e,i,r,this)},this)},this)};I.sa=function(){tr(this);let t=Array.from(this.g.values()),e=Array.from(this.g.keys()),n=[];for(let r=0;r<e.length;r++){let i=t[r];for(let s=0;s<i.length;s++)n.push(e[r])}return n};I.Z=function(t){tr(this);let e=[];if(typeof t=="string")gv(this,t)&&(e=e.concat(this.g.get(Ni(this,t))));else{t=Array.from(this.g.values());for(let n=0;n<t.length;n++)e=e.concat(t[n])}return e};I.set=function(t,e){return tr(this),this.i=null,t=Ni(this,t),gv(this,t)&&(this.h-=this.g.get(t).length),this.g.set(t,[e]),this.h+=1,this};I.get=function(t,e){return t?(t=this.Z(t),0<t.length?String(t[0]):e):e};function yv(t,e,n){mv(t,e),0<n.length&&(t.i=null,t.g.set(Ni(t,e),uf(n)),t.h+=n.length)}I.toString=function(){if(this.i)return this.i;if(!this.g)return"";let t=[],e=Array.from(this.g.keys());for(var n=0;n<e.length;n++){var r=e[n];let s=encodeURIComponent(String(r)),o=this.Z(r);for(r=0;r<o.length;r++){var i=s;o[r]!==""&&(i+="="+encodeURIComponent(String(o[r]))),t.push(i)}}return this.i=t.join("&")};function Ni(t,e){return e=String(e),t.j&&(e=e.toLowerCase()),e}function L6(t,e){e&&!t.j&&(tr(t),t.i=null,t.g.forEach(function(n,r){var i=r.toLowerCase();r!=i&&(mv(this,r),yv(this,i,n))},t)),t.j=e}var M6=class{constructor(t,e){this.h=t,this.g=e}};function Av(t){this.l=t||b6,b.PerformanceNavigationTiming?(t=b.performance.getEntriesByType("navigation"),t=0<t.length&&(t[0].nextHopProtocol=="hq"||t[0].nextHopProtocol=="h2")):t=!!(b.g&&b.g.Ka&&b.g.Ka()&&b.g.Ka().ec),this.j=t?this.l:1,this.g=null,1<this.j&&(this.g=new Set),this.h=null,this.i=[]}var b6=10;function vv(t){return t.h?!0:t.g?t.g.size>=t.j:!1}function wv(t){return t.h?1:t.g?t.g.size:0}function sf(t,e){return t.h?t.h==e:t.g?t.g.has(e):!1}function Sf(t,e){t.g?t.g.add(e):t.h=e}function Ev(t,e){t.h&&t.h==e?t.h=null:t.g&&t.g.has(e)&&t.g.delete(e)}Av.prototype.cancel=function(){if(this.i=Sv(this),this.h)this.h.cancel(),this.h=null;else if(this.g&&this.g.size!==0){for(let t of this.g.values())t.cancel();this.g.clear()}};function Sv(t){if(t.h!=null)return t.i.concat(t.h.F);if(t.g!=null&&t.g.size!==0){let e=t.i;for(let n of t.g.values())e=e.concat(n.F);return e}return uf(t.i)}function If(){}If.prototype.stringify=function(t){return b.JSON.stringify(t,void 0)};If.prototype.parse=function(t){return b.JSON.parse(t,void 0)};function R6(){this.g=new If}function z6(t,e,n){let r=n||"";try{fv(t,function(i,s){let o=i;uo(i)&&(o=gf(i)),e.push(r+s+"="+encodeURIComponent(o))})}catch(i){throw e.push(r+"type="+encodeURIComponent("_badmap")),i}}function F6(t,e){let n=new Jl;if(b.Image){let r=new Image;r.onload=Dl(Ll,n,r,"TestLoadImage: loaded",!0,e),r.onerror=Dl(Ll,n,r,"TestLoadImage: error",!1,e),r.onabort=Dl(Ll,n,r,"TestLoadImage: abort",!1,e),r.ontimeout=Dl(Ll,n,r,"TestLoadImage: timeout",!1,e),b.setTimeout(function(){r.ontimeout&&r.ontimeout()},1e4),r.src=t}else e(!1)}function Ll(t,e,n,r,i){try{e.onload=null,e.onerror=null,e.onabort=null,e.ontimeout=null,i(r)}catch{}}function go(t){this.l=t.fc||null,this.j=t.ob||!1}Te(go,vf);go.prototype.g=function(){return new nu(this.l,this.j)};go.prototype.i=function(t){return function(){return t}}({});function nu(t,e){xe.call(this),this.F=t,this.u=e,this.m=void 0,this.readyState=xf,this.status=0,this.responseType=this.responseText=this.response=this.statusText="",this.onreadystatechange=null,this.v=new Headers,this.h=null,this.C="GET",this.B="",this.g=!1,this.A=this.j=this.l=null}Te(nu,xe);var xf=0;I=nu.prototype;I.open=function(t,e){if(this.readyState!=xf)throw this.abort(),Error("Error reopening a connection");this.C=t,this.B=e,this.readyState=1,lo(this)};I.send=function(t){if(this.readyState!=1)throw this.abort(),Error("need to call open() first. ");this.g=!0;let e={headers:this.v,method:this.C,credentials:this.m,cache:void 0};t&&(e.body=t),(this.F||b).fetch(new Request(this.B,e)).then(this.$a.bind(this),this.ka.bind(this))};I.abort=function(){this.response=this.responseText="",this.v=new Headers,this.status=0,this.j&&this.j.cancel("Request was aborted.").catch(()=>{}),1<=this.readyState&&this.g&&this.readyState!=4&&(this.g=!1,yo(this)),this.readyState=xf};I.$a=function(t){if(this.g&&(this.l=t,this.h||(this.status=this.l.status,this.statusText=this.l.statusText,this.h=t.headers,this.readyState=2,lo(this)),this.g&&(this.readyState=3,lo(this),this.g)))if(this.responseType==="arraybuffer")t.arrayBuffer().then(this.Ya.bind(this),this.ka.bind(this));else if(typeof b.ReadableStream<"u"&&"body"in t){if(this.j=t.body.getReader(),this.u){if(this.responseType)throw Error('responseType must be empty for "streamBinaryChunks" mode responses.');this.response=[]}else this.response=this.responseText="",this.A=new TextDecoder;Iv(this)}else t.text().then(this.Za.bind(this),this.ka.bind(this))};function Iv(t){t.j.read().then(t.Xa.bind(t)).catch(t.ka.bind(t))}I.Xa=function(t){if(this.g){if(this.u&&t.value)this.response.push(t.value);else if(!this.u){var e=t.value?t.value:new Uint8Array(0);(e=this.A.decode(e,{stream:!t.done}))&&(this.response=this.responseText+=e)}t.done?yo(this):lo(this),this.readyState==3&&Iv(this)}};I.Za=function(t){this.g&&(this.response=this.responseText=t,yo(this))};I.Ya=function(t){this.g&&(this.response=t,yo(this))};I.ka=function(){this.g&&yo(this)};function yo(t){t.readyState=4,t.l=null,t.j=null,t.A=null,lo(t)}I.setRequestHeader=function(t,e){this.v.append(t,e)};I.getResponseHeader=function(t){return this.h&&this.h.get(t.toLowerCase())||""};I.getAllResponseHeaders=function(){if(!this.h)return"";let t=[],e=this.h.entries();for(var n=e.next();!n.done;)n=n.value,t.push(n[0]+": "+n[1]),n=e.next();return t.join(`\r
`)};function lo(t){t.onreadystatechange&&t.onreadystatechange.call(t)}Object.defineProperty(nu.prototype,"withCredentials",{get:function(){return this.m==="include"},set:function(t){this.m=t?"include":"same-origin"}});var B6=b.JSON.parse;function he(t){xe.call(this),this.headers=new Map,this.u=t||null,this.h=!1,this.C=this.g=null,this.I="",this.m=0,this.j="",this.l=this.G=this.v=this.F=!1,this.B=0,this.A=null,this.K=xv,this.L=this.M=!1}Te(he,xe);var xv="",q6=/^https?$/i,V6=["POST","PUT"];I=he.prototype;I.Oa=function(t){this.M=t};I.ha=function(t,e,n,r){if(this.g)throw Error("[goog.net.XhrIo] Object is active with another request="+this.I+"; newUri="+t);e=e?e.toUpperCase():"GET",this.I=t,this.j="",this.m=0,this.F=!1,this.h=!0,this.g=this.u?this.u.g():ef.g(),this.C=this.u?_A(this.u):_A(ef),this.g.onreadystatechange=Ve(this.La,this);try{this.G=!0,this.g.open(e,String(t),!0),this.G=!1}catch(s){MA(this,s);return}if(t=n||"",n=new Map(this.headers),r)if(Object.getPrototypeOf(r)===Object.prototype)for(var i in r)n.set(i,r[i]);else if(typeof r.keys=="function"&&typeof r.get=="function")for(let s of r.keys())n.set(s,r.get(s));else throw Error("Unknown input type for opt_headers: "+String(r));r=Array.from(n.keys()).find(s=>s.toLowerCase()=="content-type"),i=b.FormData&&t instanceof b.FormData,!(0<=BA(V6,e))||r||i||n.set("Content-Type","application/x-www-form-urlencoded;charset=utf-8");for(let[s,o]of n)this.g.setRequestHeader(s,o);this.K&&(this.g.responseType=this.K),"withCredentials"in this.g&&this.g.withCredentials!==this.M&&(this.g.withCredentials=this.M);try{kv(this),0<this.B&&((this.L=U6(this.g))?(this.g.timeout=this.B,this.g.ontimeout=Ve(this.ua,this)):this.A=Af(this.ua,this.B,this)),this.v=!0,this.g.send(t),this.v=!1}catch(s){MA(this,s)}};function U6(t){return Di&&l6()&&typeof t.timeout=="number"&&t.ontimeout!==void 0}I.ua=function(){typeof lf<"u"&&this.g&&(this.j="Timed out after "+this.B+"ms, aborting",this.m=8,Me(this,"timeout"),this.abort(8))};function MA(t,e){t.h=!1,t.g&&(t.l=!0,t.g.abort(),t.l=!1),t.j=e,t.m=5,Tv(t),ru(t)}function Tv(t){t.F||(t.F=!0,Me(t,"complete"),Me(t,"error"))}I.abort=function(t){this.g&&this.h&&(this.h=!1,this.l=!0,this.g.abort(),this.l=!1,this.m=t||7,Me(this,"complete"),Me(this,"abort"),ru(this))};I.N=function(){this.g&&(this.h&&(this.h=!1,this.l=!0,this.g.abort(),this.l=!1),ru(this,!0)),he.$.N.call(this)};I.La=function(){this.s||(this.G||this.v||this.l?Cv(this):this.kb())};I.kb=function(){Cv(this)};function Cv(t){if(t.h&&typeof lf<"u"&&(!t.C[1]||An(t)!=4||t.da()!=2)){if(t.v&&An(t)==4)Af(t.La,0,t);else if(Me(t,"readystatechange"),An(t)==4){t.h=!1;try{let a=t.da();e:switch(a){case 200:case 201:case 202:case 204:case 206:case 304:case 1223:var e=!0;break e;default:e=!1}var n;if(!(n=e)){var r;if(r=a===0){var i=String(t.I).match(pv)[1]||null;if(!i&&b.self&&b.self.location){var s=b.self.location.protocol;i=s.substr(0,s.length-1)}r=!q6.test(i?i.toLowerCase():"")}n=r}if(n)Me(t,"complete"),Me(t,"success");else{t.m=6;try{var o=2<An(t)?t.g.statusText:""}catch{o=""}t.j=o+" ["+t.da()+"]",Tv(t)}}finally{ru(t)}}}}function ru(t,e){if(t.g){kv(t);let n=t.g,r=t.C[0]?bl:null;t.g=null,t.C=null,e||Me(t,"ready");try{n.onreadystatechange=r}catch{}}}function kv(t){t.g&&t.L&&(t.g.ontimeout=null),t.A&&(b.clearTimeout(t.A),t.A=null)}function An(t){return t.g?t.g.readyState:0}I.da=function(){try{return 2<An(this)?this.g.status:-1}catch{return-1}};I.ja=function(){try{return this.g?this.g.responseText:""}catch{return""}};I.Wa=function(t){if(this.g){var e=this.g.responseText;return t&&e.indexOf(t)==0&&(e=e.substring(t.length)),B6(e)}};function bA(t){try{if(!t.g)return null;if("response"in t.g)return t.g.response;switch(t.K){case xv:case"text":return t.g.responseText;case"arraybuffer":if("mozResponseArrayBuffer"in t.g)return t.g.mozResponseArrayBuffer}return null}catch{return null}}I.Ia=function(){return this.m};I.Sa=function(){return typeof this.j=="string"?this.j:String(this.j)};function Dv(t){let e="";return hf(t,function(n,r){e+=r,e+=":",e+=n,e+=`\r
`}),e}function Tf(t,e,n){e:{for(r in n){var r=!1;break e}r=!0}r||(n=Dv(n),typeof t=="string"?n!=null&&encodeURIComponent(String(n)):ie(t,e,n))}function $s(t,e,n){return n&&n.internalChannelParams&&n.internalChannelParams[t]||e}function Nv(t){this.Ga=0,this.i=[],this.j=new Jl,this.oa=this.wa=this.G=this.Y=this.g=this.Da=this.F=this.ma=this.o=this.U=this.s=null,this.fb=this.W=0,this.cb=$s("failFast",!1,t),this.M=this.v=this.u=this.m=this.l=null,this.aa=!0,this.ta=this.Fa=this.V=-1,this.ba=this.A=this.C=0,this.ab=$s("baseRetryDelayMs",5e3,t),this.hb=$s("retryDelaySeedMs",1e4,t),this.eb=$s("forwardChannelMaxRetries",2,t),this.xa=$s("forwardChannelRequestTimeoutMs",2e4,t),this.va=t&&t.xmlHttpFactory||void 0,this.Ha=t&&t.dc||!1,this.K=void 0,this.I=t&&t.supportsCrossDomainXhr||!1,this.J="",this.h=new Av(t&&t.concurrentRequestLimit),this.Ja=new R6,this.P=t&&t.fastHandshake||!1,this.O=t&&t.encodeInitMessageHeaders||!1,this.P&&this.O&&(this.O=!1),this.bb=t&&t.bc||!1,t&&t.Ea&&this.j.Ea(),t&&t.forceLongPolling&&(this.aa=!1),this.ca=!this.P&&this.aa&&t&&t.detectBufferingProxy||!1,this.na=void 0,this.S=0,this.L=!1,this.pa=this.B=null}I=Nv.prototype;I.qa=8;I.H=1;function Cf(t){if(Pv(t),t.H==3){var e=t.W++,n=wn(t.G);ie(n,"SID",t.J),ie(n,"RID",e),ie(n,"TYPE","terminate"),Ao(t,n),e=new po(t,t.j,e,void 0),e.L=2,e.v=tu(wn(n)),n=!1,b.navigator&&b.navigator.sendBeacon&&(n=b.navigator.sendBeacon(e.v.toString(),"")),!n&&b.Image&&(new Image().src=e.v,n=!0),n||(e.g=Fv(e.l,null),e.g.ha(e.v)),e.G=Date.now(),mo(e)}Rv(t)}function iu(t){t.g&&(Df(t),t.g.cancel(),t.g=null)}function Pv(t){iu(t),t.u&&(b.clearTimeout(t.u),t.u=null),Vl(t),t.h.cancel(),t.m&&(typeof t.m=="number"&&b.clearTimeout(t.m),t.m=null)}function su(t){vv(t.h)||t.m||(t.m=!0,YA(t.Na,t),t.C=0)}function j6(t,e){return wv(t.h)>=t.h.j-(t.m?1:0)?!1:t.m?(t.i=e.F.concat(t.i),!0):t.H==1||t.H==2||t.C>=(t.cb?0:t.eb)?!1:(t.m=ho(Ve(t.Na,t,e),bv(t,t.C)),t.C++,!0)}I.Na=function(t){if(this.m)if(this.m=null,this.H==1){if(!t){this.W=Math.floor(1e5*Math.random()),t=this.W++;let i=new po(this,this.j,t,void 0),s=this.s;if(this.U&&(s?(s=QA(s),HA(s,this.U)):s=this.U),this.o!==null||this.O||(i.I=s,s=null),this.P)e:{for(var e=0,n=0;n<this.i.length;n++){t:{var r=this.i[n];if("__data__"in r.g&&(r=r.g.__data__,typeof r=="string")){r=r.length;break t}r=void 0}if(r===void 0)break;if(e+=r,4096<e){e=n;break e}if(e===4096||n===this.i.length-1){e=n+1;break e}}e=1e3}else e=1e3;e=_v(this,i,e),n=wn(this.G),ie(n,"RID",t),ie(n,"CVER",22),this.F&&ie(n,"X-HTTP-Session-Id",this.F),Ao(this,n),s&&(this.O?e="headers="+encodeURIComponent(String(Dv(s)))+"&"+e:this.o&&Tf(n,this.o,s)),Sf(this.h,i),this.bb&&ie(n,"TYPE","init"),this.P?(ie(n,"$req",e),ie(n,"SID","null"),i.ba=!0,nf(i,n,null)):nf(i,n,e),this.H=2}}else this.H==3&&(t?RA(this,t):this.i.length==0||vv(this.h)||RA(this))};function RA(t,e){var n;e?n=e.m:n=t.W++;let r=wn(t.G);ie(r,"SID",t.J),ie(r,"RID",n),ie(r,"AID",t.V),Ao(t,r),t.o&&t.s&&Tf(r,t.o,t.s),n=new po(t,t.j,n,t.C+1),t.o===null&&(n.I=t.s),e&&(t.i=e.F.concat(t.i)),e=_v(t,n,1e3),n.setTimeout(Math.round(.5*t.xa)+Math.round(.5*t.xa*Math.random())),Sf(t.h,n),nf(n,r,e)}function Ao(t,e){t.ma&&hf(t.ma,function(n,r){ie(e,r,n)}),t.l&&fv({},function(n,r){ie(e,r,n)})}function _v(t,e,n){n=Math.min(t.i.length,n);var r=t.l?Ve(t.l.Va,t.l,t):null;e:{var i=t.i;let s=-1;for(;;){let o=["count="+n];s==-1?0<n?(s=i[0].h,o.push("ofs="+s)):s=0:o.push("ofs="+s);let a=!0;for(let l=0;l<n;l++){let u=i[l].h,c=i[l].g;if(u-=s,0>u)s=Math.max(0,i[l].h-100),a=!1;else try{z6(c,o,"req"+u+"_")}catch{r&&r(c)}}if(a){r=o.join("&");break e}}}return t=t.i.splice(0,n),e.F=t,r}function Ov(t){t.g||t.u||(t.ba=1,YA(t.Ma,t),t.A=0)}function kf(t){return t.g||t.u||3<=t.A?!1:(t.ba++,t.u=ho(Ve(t.Ma,t),bv(t,t.A)),t.A++,!0)}I.Ma=function(){if(this.u=null,Lv(this),this.ca&&!(this.L||this.g==null||0>=this.S)){var t=2*this.S;this.j.info("BP detection timer enabled: "+t),this.B=ho(Ve(this.jb,this),t)}};I.jb=function(){this.B&&(this.B=null,this.j.info("BP detection timeout reached."),this.j.info("Buffering proxy detected and switch to long-polling!"),this.M=!1,this.L=!0,Ze(10),iu(this),Lv(this))};function Df(t){t.B!=null&&(b.clearTimeout(t.B),t.B=null)}function Lv(t){t.g=new po(t,t.j,"rpc",t.ba),t.o===null&&(t.g.I=t.s),t.g.O=0;var e=wn(t.wa);ie(e,"RID","rpc"),ie(e,"SID",t.J),ie(e,"CI",t.M?"0":"1"),ie(e,"AID",t.V),ie(e,"TYPE","xmlhttp"),Ao(t,e),t.o&&t.s&&Tf(e,t.o,t.s),t.K&&t.g.setTimeout(t.K);var n=t.g;t=t.oa,n.L=1,n.v=tu(wn(e)),n.s=null,n.S=!0,uv(n,t)}I.ib=function(){this.v!=null&&(this.v=null,iu(this),kf(this),Ze(19))};function Vl(t){t.v!=null&&(b.clearTimeout(t.v),t.v=null)}function Mv(t,e){var n=null;if(t.g==e){Vl(t),Df(t),t.g=null;var r=2}else if(sf(t.h,e))n=e.F,Ev(t.h,e),r=1;else return;if(t.H!=0){if(t.ta=e.aa,e.i)if(r==1){n=e.s?e.s.length:0,e=Date.now()-e.G;var i=t.C;r=Zl(),Me(r,new sv(r,n)),su(t)}else Ov(t);else if(i=e.o,i==3||i==0&&0<t.ta||!(r==1&&j6(t,e)||r==2&&kf(t)))switch(n&&0<n.length&&(e=t.h,e.i=e.i.concat(n)),i){case 1:Mr(t,5);break;case 4:Mr(t,10);break;case 3:Mr(t,6);break;default:Mr(t,2)}}}function bv(t,e){let n=t.ab+Math.floor(Math.random()*t.hb);return t.l||(n*=2),n*e}function Mr(t,e){if(t.j.info("Error code "+e),e==2){var n=null;t.l&&(n=null);var r=Ve(t.pb,t);n||(n=new br("//www.google.com/images/cleardot.gif"),b.location&&b.location.protocol=="http"||Bl(n,"https"),tu(n)),F6(n.toString(),r)}else Ze(2);t.H=0,t.l&&t.l.za(e),Rv(t),Pv(t)}I.pb=function(t){t?(this.j.info("Successfully pinged google.com"),Ze(2)):(this.j.info("Failed to ping google.com"),Ze(1))};function Rv(t){if(t.H=0,t.pa=[],t.l){let e=Sv(t.h);(e.length!=0||t.i.length!=0)&&(CA(t.pa,e),CA(t.pa,t.i),t.h.i.length=0,uf(t.i),t.i.length=0),t.l.ya()}}function zv(t,e,n){var r=n instanceof br?wn(n):new br(n,void 0);if(r.g!="")e&&(r.g=e+"."+r.g),ql(r,r.m);else{var i=b.location;r=i.protocol,e=e?e+"."+i.hostname:i.hostname,i=+i.port;var s=new br(null,void 0);r&&Bl(s,r),e&&(s.g=e),i&&ql(s,i),n&&(s.l=n),r=s}return n=t.F,e=t.Da,n&&e&&ie(r,n,e),ie(r,"VER",t.qa),Ao(t,r),r}function Fv(t,e,n){if(e&&!t.I)throw Error("Can't create secondary domain capable XhrIo object.");return e=n&&t.Ha&&!t.va?new he(new go({ob:!0})):new he(t.va),e.Oa(t.I),e}function Bv(){}I=Bv.prototype;I.Ba=function(){};I.Aa=function(){};I.za=function(){};I.ya=function(){};I.Va=function(){};function Ul(){if(Di&&!(10<=Number(u6)))throw Error("Environmental error: no available transport.")}Ul.prototype.g=function(t,e){return new dt(t,e)};function dt(t,e){xe.call(this),this.g=new Nv(e),this.l=t,this.h=e&&e.messageUrlParams||null,t=e&&e.messageHeaders||null,e&&e.clientProtocolHeaderRequired&&(t?t["X-Client-Protocol"]="webchannel":t={"X-Client-Protocol":"webchannel"}),this.g.s=t,t=e&&e.initMessageHeaders||null,e&&e.messageContentType&&(t?t["X-WebChannel-Content-Type"]=e.messageContentType:t={"X-WebChannel-Content-Type":e.messageContentType}),e&&e.Ca&&(t?t["X-WebChannel-Client-Profile"]=e.Ca:t={"X-WebChannel-Client-Profile":e.Ca}),this.g.U=t,(t=e&&e.cc)&&!Rl(t)&&(this.g.o=t),this.A=e&&e.supportsCrossDomainXhr||!1,this.v=e&&e.sendRawJson||!1,(e=e&&e.httpSessionIdParam)&&!Rl(e)&&(this.g.F=e,t=this.h,t!==null&&e in t&&(t=this.h,e in t&&delete t[e])),this.j=new Pi(this)}Te(dt,xe);dt.prototype.m=function(){this.g.l=this.j,this.A&&(this.g.I=!0);var t=this.g,e=this.l,n=this.h||void 0;Ze(0),t.Y=e,t.ma=n||{},t.M=t.aa,t.G=zv(t,null,t.Y),su(t)};dt.prototype.close=function(){Cf(this.g)};dt.prototype.u=function(t){var e=this.g;if(typeof t=="string"){var n={};n.__data__=t,t=n}else this.v&&(n={},n.__data__=gf(t),t=n);e.i.push(new M6(e.fb++,t)),e.H==3&&su(e)};dt.prototype.N=function(){this.g.l=null,delete this.j,Cf(this.g),delete this.g,dt.$.N.call(this)};function qv(t){wf.call(this);var e=t.__sm__;if(e){e:{for(let n in e){t=n;break e}t=void 0}(this.i=t)&&(t=this.i,e=e!==null&&t in e?e[t]:void 0),this.data=e}else this.data=t}Te(qv,wf);function Vv(){Ef.call(this),this.status=1}Te(Vv,Ef);function Pi(t){this.g=t}Te(Pi,Bv);Pi.prototype.Ba=function(){Me(this.g,"a")};Pi.prototype.Aa=function(t){Me(this.g,new qv(t))};Pi.prototype.za=function(t){Me(this.g,new Vv)};Pi.prototype.ya=function(){Me(this.g,"b")};function Q6(){this.blockSize=-1}function zt(){this.blockSize=-1,this.blockSize=64,this.g=Array(4),this.m=Array(this.blockSize),this.i=this.h=0,this.reset()}Te(zt,Q6);zt.prototype.reset=function(){this.g[0]=1732584193,this.g[1]=4023233417,this.g[2]=2562383102,this.g[3]=271733878,this.i=this.h=0};function Qd(t,e,n){n||(n=0);var r=Array(16);if(typeof e=="string")for(var i=0;16>i;++i)r[i]=e.charCodeAt(n++)|e.charCodeAt(n++)<<8|e.charCodeAt(n++)<<16|e.charCodeAt(n++)<<24;else for(i=0;16>i;++i)r[i]=e[n++]|e[n++]<<8|e[n++]<<16|e[n++]<<24;e=t.g[0],n=t.g[1],i=t.g[2];var s=t.g[3],o=e+(s^n&(i^s))+r[0]+3614090360&4294967295;e=n+(o<<7&4294967295|o>>>25),o=s+(i^e&(n^i))+r[1]+3905402710&4294967295,s=e+(o<<12&4294967295|o>>>20),o=i+(n^s&(e^n))+r[2]+606105819&4294967295,i=s+(o<<17&4294967295|o>>>15),o=n+(e^i&(s^e))+r[3]+3250441966&4294967295,n=i+(o<<22&4294967295|o>>>10),o=e+(s^n&(i^s))+r[4]+4118548399&4294967295,e=n+(o<<7&4294967295|o>>>25),o=s+(i^e&(n^i))+r[5]+1200080426&4294967295,s=e+(o<<12&4294967295|o>>>20),o=i+(n^s&(e^n))+r[6]+2821735955&4294967295,i=s+(o<<17&4294967295|o>>>15),o=n+(e^i&(s^e))+r[7]+4249261313&4294967295,n=i+(o<<22&4294967295|o>>>10),o=e+(s^n&(i^s))+r[8]+1770035416&4294967295,e=n+(o<<7&4294967295|o>>>25),o=s+(i^e&(n^i))+r[9]+2336552879&4294967295,s=e+(o<<12&4294967295|o>>>20),o=i+(n^s&(e^n))+r[10]+4294925233&4294967295,i=s+(o<<17&4294967295|o>>>15),o=n+(e^i&(s^e))+r[11]+2304563134&4294967295,n=i+(o<<22&4294967295|o>>>10),o=e+(s^n&(i^s))+r[12]+1804603682&4294967295,e=n+(o<<7&4294967295|o>>>25),o=s+(i^e&(n^i))+r[13]+4254626195&4294967295,s=e+(o<<12&4294967295|o>>>20),o=i+(n^s&(e^n))+r[14]+2792965006&4294967295,i=s+(o<<17&4294967295|o>>>15),o=n+(e^i&(s^e))+r[15]+1236535329&4294967295,n=i+(o<<22&4294967295|o>>>10),o=e+(i^s&(n^i))+r[1]+4129170786&4294967295,e=n+(o<<5&4294967295|o>>>27),o=s+(n^i&(e^n))+r[6]+3225465664&4294967295,s=e+(o<<9&4294967295|o>>>23),o=i+(e^n&(s^e))+r[11]+643717713&4294967295,i=s+(o<<14&4294967295|o>>>18),o=n+(s^e&(i^s))+r[0]+3921069994&4294967295,n=i+(o<<20&4294967295|o>>>12),o=e+(i^s&(n^i))+r[5]+3593408605&4294967295,e=n+(o<<5&4294967295|o>>>27),o=s+(n^i&(e^n))+r[10]+38016083&4294967295,s=e+(o<<9&4294967295|o>>>23),o=i+(e^n&(s^e))+r[15]+3634488961&4294967295,i=s+(o<<14&4294967295|o>>>18),o=n+(s^e&(i^s))+r[4]+3889429448&4294967295,n=i+(o<<20&4294967295|o>>>12),o=e+(i^s&(n^i))+r[9]+568446438&4294967295,e=n+(o<<5&4294967295|o>>>27),o=s+(n^i&(e^n))+r[14]+3275163606&4294967295,s=e+(o<<9&4294967295|o>>>23),o=i+(e^n&(s^e))+r[3]+4107603335&4294967295,i=s+(o<<14&4294967295|o>>>18),o=n+(s^e&(i^s))+r[8]+1163531501&4294967295,n=i+(o<<20&4294967295|o>>>12),o=e+(i^s&(n^i))+r[13]+2850285829&4294967295,e=n+(o<<5&4294967295|o>>>27),o=s+(n^i&(e^n))+r[2]+4243563512&4294967295,s=e+(o<<9&4294967295|o>>>23),o=i+(e^n&(s^e))+r[7]+1735328473&4294967295,i=s+(o<<14&4294967295|o>>>18),o=n+(s^e&(i^s))+r[12]+2368359562&4294967295,n=i+(o<<20&4294967295|o>>>12),o=e+(n^i^s)+r[5]+4294588738&4294967295,e=n+(o<<4&4294967295|o>>>28),o=s+(e^n^i)+r[8]+2272392833&4294967295,s=e+(o<<11&4294967295|o>>>21),o=i+(s^e^n)+r[11]+1839030562&4294967295,i=s+(o<<16&4294967295|o>>>16),o=n+(i^s^e)+r[14]+4259657740&4294967295,n=i+(o<<23&4294967295|o>>>9),o=e+(n^i^s)+r[1]+2763975236&4294967295,e=n+(o<<4&4294967295|o>>>28),o=s+(e^n^i)+r[4]+1272893353&4294967295,s=e+(o<<11&4294967295|o>>>21),o=i+(s^e^n)+r[7]+4139469664&4294967295,i=s+(o<<16&4294967295|o>>>16),o=n+(i^s^e)+r[10]+3200236656&4294967295,n=i+(o<<23&4294967295|o>>>9),o=e+(n^i^s)+r[13]+681279174&4294967295,e=n+(o<<4&4294967295|o>>>28),o=s+(e^n^i)+r[0]+3936430074&4294967295,s=e+(o<<11&4294967295|o>>>21),o=i+(s^e^n)+r[3]+3572445317&4294967295,i=s+(o<<16&4294967295|o>>>16),o=n+(i^s^e)+r[6]+76029189&4294967295,n=i+(o<<23&4294967295|o>>>9),o=e+(n^i^s)+r[9]+3654602809&4294967295,e=n+(o<<4&4294967295|o>>>28),o=s+(e^n^i)+r[12]+3873151461&4294967295,s=e+(o<<11&4294967295|o>>>21),o=i+(s^e^n)+r[15]+530742520&4294967295,i=s+(o<<16&4294967295|o>>>16),o=n+(i^s^e)+r[2]+3299628645&4294967295,n=i+(o<<23&4294967295|o>>>9),o=e+(i^(n|~s))+r[0]+4096336452&4294967295,e=n+(o<<6&4294967295|o>>>26),o=s+(n^(e|~i))+r[7]+1126891415&4294967295,s=e+(o<<10&4294967295|o>>>22),o=i+(e^(s|~n))+r[14]+2878612391&4294967295,i=s+(o<<15&4294967295|o>>>17),o=n+(s^(i|~e))+r[5]+4237533241&4294967295,n=i+(o<<21&4294967295|o>>>11),o=e+(i^(n|~s))+r[12]+1700485571&4294967295,e=n+(o<<6&4294967295|o>>>26),o=s+(n^(e|~i))+r[3]+2399980690&4294967295,s=e+(o<<10&4294967295|o>>>22),o=i+(e^(s|~n))+r[10]+4293915773&4294967295,i=s+(o<<15&4294967295|o>>>17),o=n+(s^(i|~e))+r[1]+2240044497&4294967295,n=i+(o<<21&4294967295|o>>>11),o=e+(i^(n|~s))+r[8]+1873313359&4294967295,e=n+(o<<6&4294967295|o>>>26),o=s+(n^(e|~i))+r[15]+4264355552&4294967295,s=e+(o<<10&4294967295|o>>>22),o=i+(e^(s|~n))+r[6]+2734768916&4294967295,i=s+(o<<15&4294967295|o>>>17),o=n+(s^(i|~e))+r[13]+1309151649&4294967295,n=i+(o<<21&4294967295|o>>>11),o=e+(i^(n|~s))+r[4]+4149444226&4294967295,e=n+(o<<6&4294967295|o>>>26),o=s+(n^(e|~i))+r[11]+3174756917&4294967295,s=e+(o<<10&4294967295|o>>>22),o=i+(e^(s|~n))+r[2]+718787259&4294967295,i=s+(o<<15&4294967295|o>>>17),o=n+(s^(i|~e))+r[9]+3951481745&4294967295,t.g[0]=t.g[0]+e&4294967295,t.g[1]=t.g[1]+(i+(o<<21&4294967295|o>>>11))&4294967295,t.g[2]=t.g[2]+i&4294967295,t.g[3]=t.g[3]+s&4294967295}zt.prototype.j=function(t,e){e===void 0&&(e=t.length);for(var n=e-this.blockSize,r=this.m,i=this.h,s=0;s<e;){if(i==0)for(;s<=n;)Qd(this,t,s),s+=this.blockSize;if(typeof t=="string"){for(;s<e;)if(r[i++]=t.charCodeAt(s++),i==this.blockSize){Qd(this,r),i=0;break}}else for(;s<e;)if(r[i++]=t[s++],i==this.blockSize){Qd(this,r),i=0;break}}this.h=i,this.i+=e};zt.prototype.l=function(){var t=Array((56>this.h?this.blockSize:2*this.blockSize)-this.h);t[0]=128;for(var e=1;e<t.length-8;++e)t[e]=0;var n=8*this.i;for(e=t.length-8;e<t.length;++e)t[e]=n&255,n/=256;for(this.j(t),t=Array(16),e=n=0;4>e;++e)for(var r=0;32>r;r+=8)t[n++]=this.g[e]>>>r&255;return t};function J(t,e){this.h=e;for(var n=[],r=!0,i=t.length-1;0<=i;i--){var s=t[i]|0;r&&s==e||(n[i]=s,r=!1)}this.g=n}var H6={};function Nf(t){return-128<=t&&128>t?qA(H6,t,function(e){return new J([e|0],0>e?-1:0)}):new J([t|0],0>t?-1:0)}function Zt(t){if(isNaN(t)||!isFinite(t))return ki;if(0>t)return Le(Zt(-t));for(var e=[],n=1,r=0;t>=n;r++)e[r]=t/n|0,n*=of;return new J(e,0)}function Uv(t,e){if(t.length==0)throw Error("number format error: empty string");if(e=e||10,2>e||36<e)throw Error("radix out of range: "+e);if(t.charAt(0)=="-")return Le(Uv(t.substring(1),e));if(0<=t.indexOf("-"))throw Error('number format error: interior "-" character');for(var n=Zt(Math.pow(e,8)),r=ki,i=0;i<t.length;i+=8){var s=Math.min(8,t.length-i),o=parseInt(t.substring(i,i+s),e);8>s?(s=Zt(Math.pow(e,s)),r=r.R(s).add(Zt(o))):(r=r.R(n),r=r.add(Zt(o)))}return r}var of=4294967296,ki=Nf(0),af=Nf(1),zA=Nf(16777216);I=J.prototype;I.ea=function(){if(It(this))return-Le(this).ea();for(var t=0,e=1,n=0;n<this.g.length;n++){var r=this.D(n);t+=(0<=r?r:of+r)*e,e*=of}return t};I.toString=function(t){if(t=t||10,2>t||36<t)throw Error("radix out of range: "+t);if(vn(this))return"0";if(It(this))return"-"+Le(this).toString(t);for(var e=Zt(Math.pow(t,6)),n=this,r="";;){var i=Ql(n,e).g;n=jl(n,i.R(e));var s=((0<n.g.length?n.g[0]:n.h)>>>0).toString(t);if(n=i,vn(n))return s+r;for(;6>s.length;)s="0"+s;r=s+r}};I.D=function(t){return 0>t?0:t<this.g.length?this.g[t]:this.h};function vn(t){if(t.h!=0)return!1;for(var e=0;e<t.g.length;e++)if(t.g[e]!=0)return!1;return!0}function It(t){return t.h==-1}I.X=function(t){return t=jl(this,t),It(t)?-1:vn(t)?0:1};function Le(t){for(var e=t.g.length,n=[],r=0;r<e;r++)n[r]=~t.g[r];return new J(n,~t.h).add(af)}I.abs=function(){return It(this)?Le(this):this};I.add=function(t){for(var e=Math.max(this.g.length,t.g.length),n=[],r=0,i=0;i<=e;i++){var s=r+(this.D(i)&65535)+(t.D(i)&65535),o=(s>>>16)+(this.D(i)>>>16)+(t.D(i)>>>16);r=o>>>16,s&=65535,o&=65535,n[i]=o<<16|s}return new J(n,n[n.length-1]&-2147483648?-1:0)};function jl(t,e){return t.add(Le(e))}I.R=function(t){if(vn(this)||vn(t))return ki;if(It(this))return It(t)?Le(this).R(Le(t)):Le(Le(this).R(t));if(It(t))return Le(this.R(Le(t)));if(0>this.X(zA)&&0>t.X(zA))return Zt(this.ea()*t.ea());for(var e=this.g.length+t.g.length,n=[],r=0;r<2*e;r++)n[r]=0;for(r=0;r<this.g.length;r++)for(var i=0;i<t.g.length;i++){var s=this.D(r)>>>16,o=this.D(r)&65535,a=t.D(i)>>>16,l=t.D(i)&65535;n[2*r+2*i]+=o*l,Ml(n,2*r+2*i),n[2*r+2*i+1]+=s*l,Ml(n,2*r+2*i+1),n[2*r+2*i+1]+=o*a,Ml(n,2*r+2*i+1),n[2*r+2*i+2]+=s*a,Ml(n,2*r+2*i+2)}for(r=0;r<e;r++)n[r]=n[2*r+1]<<16|n[2*r];for(r=e;r<2*e;r++)n[r]=0;return new J(n,0)};function Ml(t,e){for(;(t[e]&65535)!=t[e];)t[e+1]+=t[e]>>>16,t[e]&=65535,e++}function eo(t,e){this.g=t,this.h=e}function Ql(t,e){if(vn(e))throw Error("division by zero");if(vn(t))return new eo(ki,ki);if(It(t))return e=Ql(Le(t),e),new eo(Le(e.g),Le(e.h));if(It(e))return e=Ql(t,Le(e)),new eo(Le(e.g),e.h);if(30<t.g.length){if(It(t)||It(e))throw Error("slowDivide_ only works with positive integers.");for(var n=af,r=e;0>=r.X(t);)n=FA(n),r=FA(r);var i=Ti(n,1),s=Ti(r,1);for(r=Ti(r,2),n=Ti(n,2);!vn(r);){var o=s.add(r);0>=o.X(t)&&(i=i.add(n),s=o),r=Ti(r,1),n=Ti(n,1)}return e=jl(t,i.R(e)),new eo(i,e)}for(i=ki;0<=t.X(e);){for(n=Math.max(1,Math.floor(t.ea()/e.ea())),r=Math.ceil(Math.log(n)/Math.LN2),r=48>=r?1:Math.pow(2,r-48),s=Zt(n),o=s.R(e);It(o)||0<o.X(t);)n-=r,s=Zt(n),o=s.R(e);vn(s)&&(s=af),i=i.add(s),t=jl(t,o)}return new eo(i,t)}I.gb=function(t){return Ql(this,t).h};I.and=function(t){for(var e=Math.max(this.g.length,t.g.length),n=[],r=0;r<e;r++)n[r]=this.D(r)&t.D(r);return new J(n,this.h&t.h)};I.or=function(t){for(var e=Math.max(this.g.length,t.g.length),n=[],r=0;r<e;r++)n[r]=this.D(r)|t.D(r);return new J(n,this.h|t.h)};I.xor=function(t){for(var e=Math.max(this.g.length,t.g.length),n=[],r=0;r<e;r++)n[r]=this.D(r)^t.D(r);return new J(n,this.h^t.h)};function FA(t){for(var e=t.g.length+1,n=[],r=0;r<e;r++)n[r]=t.D(r)<<1|t.D(r-1)>>>31;return new J(n,t.h)}function Ti(t,e){var n=e>>5;e%=32;for(var r=t.g.length-n,i=[],s=0;s<r;s++)i[s]=0<e?t.D(s+n)>>>e|t.D(s+n+1)<<32-e:t.D(s+n);return new J(i,t.h)}Ul.prototype.createWebChannel=Ul.prototype.g;dt.prototype.send=dt.prototype.u;dt.prototype.open=dt.prototype.m;dt.prototype.close=dt.prototype.close;Yl.NO_ERROR=0;Yl.TIMEOUT=8;Yl.HTTP_ERROR=6;ov.COMPLETE="complete";av.EventType=fo;fo.OPEN="a";fo.CLOSE="b";fo.ERROR="c";fo.MESSAGE="d";xe.prototype.listen=xe.prototype.O;he.prototype.listenOnce=he.prototype.P;he.prototype.getLastError=he.prototype.Sa;he.prototype.getLastErrorCode=he.prototype.Ia;he.prototype.getStatus=he.prototype.da;he.prototype.getResponseJson=he.prototype.Wa;he.prototype.getResponseText=he.prototype.ja;he.prototype.send=he.prototype.ha;he.prototype.setWithCredentials=he.prototype.Oa;zt.prototype.digest=zt.prototype.l;zt.prototype.reset=zt.prototype.reset;zt.prototype.update=zt.prototype.j;J.prototype.add=J.prototype.add;J.prototype.multiply=J.prototype.R;J.prototype.modulo=J.prototype.gb;J.prototype.compare=J.prototype.X;J.prototype.toNumber=J.prototype.ea;J.prototype.toString=J.prototype.toString;J.prototype.getBits=J.prototype.D;J.fromNumber=Zt;J.fromString=Uv;var jv=Ft.createWebChannelTransport=function(){return new Ul},Qv=Ft.getStatEventTarget=function(){return Zl()},ou=Ft.ErrorCode=Yl,Hv=Ft.EventType=ov,Kv=Ft.Event=Rr,Pf=Ft.Stat={xb:0,Ab:1,Bb:2,Ub:3,Zb:4,Wb:5,Xb:6,Vb:7,Tb:8,Yb:9,PROXY:10,NOPROXY:11,Rb:12,Nb:13,Ob:14,Mb:15,Pb:16,Qb:17,tb:18,sb:19,ub:20},Xv=Ft.FetchXmlHttpFactory=go,vo=Ft.WebChannel=av,Wv=Ft.XhrIo=he,Gv=Ft.Md5=zt,zr=Ft.Integer=J;var Jv="@firebase/firestore";var Ce=class{constructor(e){this.uid=e}isAuthenticated(){return this.uid!=null}toKey(){return this.isAuthenticated()?"uid:"+this.uid:"anonymous-user"}isEqual(e){return e.uid===this.uid}};Ce.UNAUTHENTICATED=new Ce(null),Ce.GOOGLE_CREDENTIALS=new Ce("google-credentials-uid"),Ce.FIRST_PARTY=new Ce("first-party-uid"),Ce.MOCK_USER=new Ce("mock-user");var Gi="9.21.0";var Vr=new xi("@firebase/firestore");function Zv(){return Vr.logLevel}function N(t,...e){if(Vr.logLevel<=H.DEBUG){let n=e.map(sm);Vr.debug(`Firestore (${Gi}): ${t}`,...n)}}function In(t,...e){if(Vr.logLevel<=H.ERROR){let n=e.map(sm);Vr.error(`Firestore (${Gi}): ${t}`,...n)}}function zi(t,...e){if(Vr.logLevel<=H.WARN){let n=e.map(sm);Vr.warn(`Firestore (${Gi}): ${t}`,...n)}}function sm(t){if(typeof t=="string")return t;try{return e=t,JSON.stringify(e)}catch{return t}var e}function z(t="Unexpected state"){let e=`FIRESTORE (${Gi}) INTERNAL ASSERTION FAILED: `+t;throw In(e),new Error(e)}function Ee(t,e){t||z()}function Q(t,e){return t}var x={OK:"ok",CANCELLED:"cancelled",UNKNOWN:"unknown",INVALID_ARGUMENT:"invalid-argument",DEADLINE_EXCEEDED:"deadline-exceeded",NOT_FOUND:"not-found",ALREADY_EXISTS:"already-exists",PERMISSION_DENIED:"permission-denied",UNAUTHENTICATED:"unauthenticated",RESOURCE_EXHAUSTED:"resource-exhausted",FAILED_PRECONDITION:"failed-precondition",ABORTED:"aborted",OUT_OF_RANGE:"out-of-range",UNIMPLEMENTED:"unimplemented",INTERNAL:"internal",UNAVAILABLE:"unavailable",DATA_LOSS:"data-loss"},O=class extends Rt{constructor(e,n){super(e,n),this.code=e,this.message=n,this.toString=()=>`${this.name}: [code=${this.code}]: ${this.message}`}};var En=class{constructor(){this.promise=new Promise((e,n)=>{this.resolve=e,this.reject=n})}};var hu=class{constructor(e,n){this.user=n,this.type="OAuth",this.headers=new Map,this.headers.set("Authorization",`Bearer ${e}`)}},Rf=class{getToken(){return Promise.resolve(null)}invalidateToken(){}start(e,n){e.enqueueRetryable(()=>n(Ce.UNAUTHENTICATED))}shutdown(){}},zf=class{constructor(e){this.token=e,this.changeListener=null}getToken(){return Promise.resolve(this.token)}invalidateToken(){}start(e,n){this.changeListener=n,e.enqueueRetryable(()=>n(this.token.user))}shutdown(){this.changeListener=null}},Ff=class{constructor(e){this.t=e,this.currentUser=Ce.UNAUTHENTICATED,this.i=0,this.forceRefresh=!1,this.auth=null}start(e,n){let r=this.i,i=l=>this.i!==r?(r=this.i,n(l)):Promise.resolve(),s=new En;this.o=()=>{this.i++,this.currentUser=this.u(),s.resolve(),s=new En,e.enqueueRetryable(()=>i(this.currentUser))};let o=()=>{let l=s;e.enqueueRetryable(async()=>{await l.promise,await i(this.currentUser)})},a=l=>{N("FirebaseAuthCredentialsProvider","Auth detected"),this.auth=l,this.auth.addAuthTokenListener(this.o),o()};this.t.onInit(l=>a(l)),setTimeout(()=>{if(!this.auth){let l=this.t.getImmediate({optional:!0});l?a(l):(N("FirebaseAuthCredentialsProvider","Auth not yet detected"),s.resolve(),s=new En)}},0),o()}getToken(){let e=this.i,n=this.forceRefresh;return this.forceRefresh=!1,this.auth?this.auth.getToken(n).then(r=>this.i!==e?(N("FirebaseAuthCredentialsProvider","getToken aborted due to token change."),this.getToken()):r?(Ee(typeof r.accessToken=="string"),new hu(r.accessToken,this.currentUser)):null):Promise.resolve(null)}invalidateToken(){this.forceRefresh=!0}shutdown(){this.auth&&this.auth.removeAuthTokenListener(this.o)}u(){let e=this.auth&&this.auth.getUid();return Ee(e===null||typeof e=="string"),new Ce(e)}},Bf=class{constructor(e,n,r){this.h=e,this.l=n,this.m=r,this.type="FirstParty",this.user=Ce.FIRST_PARTY,this.g=new Map}p(){return this.m?this.m():null}get headers(){this.g.set("X-Goog-AuthUser",this.h);let e=this.p();return e&&this.g.set("Authorization",e),this.l&&this.g.set("X-Goog-Iam-Authorization-Token",this.l),this.g}},qf=class{constructor(e,n,r){this.h=e,this.l=n,this.m=r}getToken(){return Promise.resolve(new Bf(this.h,this.l,this.m))}start(e,n){e.enqueueRetryable(()=>n(Ce.FIRST_PARTY))}shutdown(){}invalidateToken(){}},Vf=class{constructor(e){this.value=e,this.type="AppCheck",this.headers=new Map,e&&e.length>0&&this.headers.set("x-firebase-appcheck",this.value)}},Uf=class{constructor(e){this.I=e,this.forceRefresh=!1,this.appCheck=null,this.T=null}start(e,n){let r=s=>{s.error!=null&&N("FirebaseAppCheckTokenProvider",`Error getting App Check token; using placeholder token instead. Error: ${s.error.message}`);let o=s.token!==this.T;return this.T=s.token,N("FirebaseAppCheckTokenProvider",`Received ${o?"new":"existing"} token.`),o?n(s.token):Promise.resolve()};this.o=s=>{e.enqueueRetryable(()=>r(s))};let i=s=>{N("FirebaseAppCheckTokenProvider","AppCheck detected"),this.appCheck=s,this.appCheck.addTokenListener(this.o)};this.I.onInit(s=>i(s)),setTimeout(()=>{if(!this.appCheck){let s=this.I.getImmediate({optional:!0});s?i(s):N("FirebaseAppCheckTokenProvider","AppCheck not yet detected")}},0)}getToken(){let e=this.forceRefresh;return this.forceRefresh=!1,this.appCheck?this.appCheck.getToken(e).then(n=>n?(Ee(typeof n.token=="string"),this.T=n.token,new Vf(n.token)):null):Promise.resolve(null)}invalidateToken(){this.forceRefresh=!0}shutdown(){this.appCheck&&this.appCheck.removeTokenListener(this.o)}};function K6(t){let e=typeof self<"u"&&(self.crypto||self.msCrypto),n=new Uint8Array(t);if(e&&typeof e.getRandomValues=="function")e.getRandomValues(n);else for(let r=0;r<t;r++)n[r]=Math.floor(256*Math.random());return n}var du=class{static A(){let e="ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789",n=Math.floor(256/e.length)*e.length,r="";for(;r.length<20;){let i=K6(40);for(let s=0;s<i.length;++s)r.length<20&&i[s]<n&&(r+=e.charAt(i[s]%e.length))}return r}};function X(t,e){return t<e?-1:t>e?1:0}function Fi(t,e,n){return t.length===e.length&&t.every((r,i)=>n(r,e[i]))}var He=class{constructor(e,n){if(this.seconds=e,this.nanoseconds=n,n<0)throw new O(x.INVALID_ARGUMENT,"Timestamp nanoseconds out of range: "+n);if(n>=1e9)throw new O(x.INVALID_ARGUMENT,"Timestamp nanoseconds out of range: "+n);if(e<-62135596800)throw new O(x.INVALID_ARGUMENT,"Timestamp seconds out of range: "+e);if(e>=253402300800)throw new O(x.INVALID_ARGUMENT,"Timestamp seconds out of range: "+e)}static now(){return He.fromMillis(Date.now())}static fromDate(e){return He.fromMillis(e.getTime())}static fromMillis(e){let n=Math.floor(e/1e3),r=Math.floor(1e6*(e-1e3*n));return new He(n,r)}toDate(){return new Date(this.toMillis())}toMillis(){return 1e3*this.seconds+this.nanoseconds/1e6}_compareTo(e){return this.seconds===e.seconds?X(this.nanoseconds,e.nanoseconds):X(this.seconds,e.seconds)}isEqual(e){return e.seconds===this.seconds&&e.nanoseconds===this.nanoseconds}toString(){return"Timestamp(seconds="+this.seconds+", nanoseconds="+this.nanoseconds+")"}toJSON(){return{seconds:this.seconds,nanoseconds:this.nanoseconds}}valueOf(){let e=this.seconds- -62135596800;return String(e).padStart(12,"0")+"."+String(this.nanoseconds).padStart(9,"0")}};var R=class{constructor(e){this.timestamp=e}static fromTimestamp(e){return new R(e)}static min(){return new R(new He(0,0))}static max(){return new R(new He(253402300799,999999999))}compareTo(e){return this.timestamp._compareTo(e.timestamp)}isEqual(e){return this.timestamp.isEqual(e.timestamp)}toMicroseconds(){return 1e6*this.timestamp.seconds+this.timestamp.nanoseconds/1e3}toString(){return"SnapshotVersion("+this.timestamp.toString()+")"}toTimestamp(){return this.timestamp}};var Ur=class{constructor(e,n,r){n===void 0?n=0:n>e.length&&z(),r===void 0?r=e.length-n:r>e.length-n&&z(),this.segments=e,this.offset=n,this.len=r}get length(){return this.len}isEqual(e){return Ur.comparator(this,e)===0}child(e){let n=this.segments.slice(this.offset,this.limit());return e instanceof Ur?e.forEach(r=>{n.push(r)}):n.push(e),this.construct(n)}limit(){return this.offset+this.length}popFirst(e){return e=e===void 0?1:e,this.construct(this.segments,this.offset+e,this.length-e)}popLast(){return this.construct(this.segments,this.offset,this.length-1)}firstSegment(){return this.segments[this.offset]}lastSegment(){return this.get(this.length-1)}get(e){return this.segments[this.offset+e]}isEmpty(){return this.length===0}isPrefixOf(e){if(e.length<this.length)return!1;for(let n=0;n<this.length;n++)if(this.get(n)!==e.get(n))return!1;return!0}isImmediateParentOf(e){if(this.length+1!==e.length)return!1;for(let n=0;n<this.length;n++)if(this.get(n)!==e.get(n))return!1;return!0}forEach(e){for(let n=this.offset,r=this.limit();n<r;n++)e(this.segments[n])}toArray(){return this.segments.slice(this.offset,this.limit())}static comparator(e,n){let r=Math.min(e.length,n.length);for(let i=0;i<r;i++){let s=e.get(i),o=n.get(i);if(s<o)return-1;if(s>o)return 1}return e.length<n.length?-1:e.length>n.length?1:0}},se=class extends Ur{construct(e,n,r){return new se(e,n,r)}canonicalString(){return this.toArray().join("/")}toString(){return this.canonicalString()}static fromString(...e){let n=[];for(let r of e){if(r.indexOf("//")>=0)throw new O(x.INVALID_ARGUMENT,`Invalid segment (${r}). Paths must not contain // in them.`);n.push(...r.split("/").filter(i=>i.length>0))}return new se(n)}static emptyPath(){return new se([])}},X6=/^[_a-zA-Z][_a-zA-Z0-9]*$/,Qe=class extends Ur{construct(e,n,r){return new Qe(e,n,r)}static isValidIdentifier(e){return X6.test(e)}canonicalString(){return this.toArray().map(e=>(e=e.replace(/\\/g,"\\\\").replace(/`/g,"\\`"),Qe.isValidIdentifier(e)||(e="`"+e+"`"),e)).join(".")}toString(){return this.canonicalString()}isKeyField(){return this.length===1&&this.get(0)==="__name__"}static keyField(){return new Qe(["__name__"])}static fromServerFormat(e){let n=[],r="",i=0,s=()=>{if(r.length===0)throw new O(x.INVALID_ARGUMENT,`Invalid field path (${e}). Paths must not be empty, begin with '.', end with '.', or contain '..'`);n.push(r),r=""},o=!1;for(;i<e.length;){let a=e[i];if(a==="\\"){if(i+1===e.length)throw new O(x.INVALID_ARGUMENT,"Path has trailing escape character: "+e);let l=e[i+1];if(l!=="\\"&&l!=="."&&l!=="`")throw new O(x.INVALID_ARGUMENT,"Path has invalid escape sequence: "+e);r+=l,i+=2}else a==="`"?(o=!o,i++):a!=="."||o?(r+=a,i++):(s(),i++)}if(s(),o)throw new O(x.INVALID_ARGUMENT,"Unterminated ` in path: "+e);return new Qe(n)}static emptyPath(){return new Qe([])}};var _=class{constructor(e){this.path=e}static fromPath(e){return new _(se.fromString(e))}static fromName(e){return new _(se.fromString(e).popFirst(5))}static empty(){return new _(se.emptyPath())}get collectionGroup(){return this.path.popLast().lastSegment()}hasCollectionId(e){return this.path.length>=2&&this.path.get(this.path.length-2)===e}getCollectionGroup(){return this.path.get(this.path.length-2)}getCollectionPath(){return this.path.popLast()}isEqual(e){return e!==null&&se.comparator(this.path,e.path)===0}toString(){return this.path.toString()}static comparator(e,n){return se.comparator(e.path,n.path)}static isDocumentKey(e){return e.length%2==0}static fromSegments(e){return new _(new se(e.slice()))}};var jf=class{constructor(e,n,r,i){this.indexId=e,this.collectionGroup=n,this.fields=r,this.indexState=i}};jf.UNKNOWN_ID=-1;function W6(t,e){let n=t.toTimestamp().seconds,r=t.toTimestamp().nanoseconds+1,i=R.fromTimestamp(r===1e9?new He(n+1,0):new He(n,r));return new en(i,_.empty(),e)}function G6(t){return new en(t.readTime,t.key,-1)}var en=class{constructor(e,n,r){this.readTime=e,this.documentKey=n,this.largestBatchId=r}static min(){return new en(R.min(),_.empty(),-1)}static max(){return new en(R.max(),_.empty(),-1)}};function J6(t,e){let n=t.readTime.compareTo(e.readTime);return n!==0?n:(n=_.comparator(t.documentKey,e.documentKey),n!==0?n:X(t.largestBatchId,e.largestBatchId))}var Z6="The current tab is not in the required state to perform this operation. It might be necessary to refresh the browser tab.",Qf=class{constructor(){this.onCommittedListeners=[]}addOnCommittedListener(e){this.onCommittedListeners.push(e)}raiseOnCommittedEvent(){this.onCommittedListeners.forEach(e=>e())}};async function om(t){if(t.code!==x.FAILED_PRECONDITION||t.message!==Z6)throw t;N("LocalStore","Unexpectedly lost primary lease")}var E=class{constructor(e){this.nextCallback=null,this.catchCallback=null,this.result=void 0,this.error=void 0,this.isDone=!1,this.callbackAttached=!1,e(n=>{this.isDone=!0,this.result=n,this.nextCallback&&this.nextCallback(n)},n=>{this.isDone=!0,this.error=n,this.catchCallback&&this.catchCallback(n)})}catch(e){return this.next(void 0,e)}next(e,n){return this.callbackAttached&&z(),this.callbackAttached=!0,this.isDone?this.error?this.wrapFailure(n,this.error):this.wrapSuccess(e,this.result):new E((r,i)=>{this.nextCallback=s=>{this.wrapSuccess(e,s).next(r,i)},this.catchCallback=s=>{this.wrapFailure(n,s).next(r,i)}})}toPromise(){return new Promise((e,n)=>{this.next(e,n)})}wrapUserFunction(e){try{let n=e();return n instanceof E?n:E.resolve(n)}catch(n){return E.reject(n)}}wrapSuccess(e,n){return e?this.wrapUserFunction(()=>e(n)):E.resolve(n)}wrapFailure(e,n){return e?this.wrapUserFunction(()=>e(n)):E.reject(n)}static resolve(e){return new E((n,r)=>{n(e)})}static reject(e){return new E((n,r)=>{r(e)})}static waitFor(e){return new E((n,r)=>{let i=0,s=0,o=!1;e.forEach(a=>{++i,a.next(()=>{++s,o&&s===i&&n()},l=>r(l))}),o=!0,s===i&&n()})}static or(e){let n=E.resolve(!1);for(let r of e)n=n.next(i=>i?E.resolve(i):r());return n}static forEach(e,n){let r=[];return e.forEach((i,s)=>{r.push(n.call(this,i,s))}),this.waitFor(r)}static mapArray(e,n){return new E((r,i)=>{let s=e.length,o=new Array(s),a=0;for(let l=0;l<s;l++){let u=l;n(e[u]).next(c=>{o[u]=c,++a,a===s&&r(o)},c=>i(c))}})}static doWhile(e,n){return new E((r,i)=>{let s=()=>{e()===!0?n().next(()=>{s()},i):r()};s()})}};function Bo(t){return t.name==="IndexedDbTransactionError"}var xo=class{constructor(e,n){this.previousValue=e,n&&(n.sequenceNumberHandler=r=>this.ot(r),this.ut=r=>n.writeSequenceNumber(r))}ot(e){return this.previousValue=Math.max(e,this.previousValue),this.previousValue}next(){let e=++this.previousValue;return this.ut&&this.ut(e),e}};xo.ct=-1;function Lu(t){return t==null}function fu(t){return t===0&&1/t==-1/0}var Y6=["mutationQueues","mutations","documentMutations","remoteDocuments","targets","owner","targetGlobal","targetDocuments","clientMetadata","remoteDocumentGlobal","collectionParents","bundles","namedQueries"],IC=[...Y6,"documentOverlays"],$6=["mutationQueues","mutations","documentMutations","remoteDocumentsV14","targets","owner","targetGlobal","targetDocuments","clientMetadata","remoteDocumentGlobal","collectionParents","bundles","namedQueries","documentOverlays"],eI=$6,xC=[...eI,"indexConfiguration","indexState","indexEntries"];function Yv(t){let e=0;for(let n in t)Object.prototype.hasOwnProperty.call(t,n)&&e++;return e}function Mu(t,e){for(let n in t)Object.prototype.hasOwnProperty.call(t,n)&&e(n,t[n])}function tI(t){for(let e in t)if(Object.prototype.hasOwnProperty.call(t,e))return!1;return!0}var oe=class{constructor(e,n){this.comparator=e,this.root=n||we.EMPTY}insert(e,n){return new oe(this.comparator,this.root.insert(e,n,this.comparator).copy(null,null,we.BLACK,null,null))}remove(e){return new oe(this.comparator,this.root.remove(e,this.comparator).copy(null,null,we.BLACK,null,null))}get(e){let n=this.root;for(;!n.isEmpty();){let r=this.comparator(e,n.key);if(r===0)return n.value;r<0?n=n.left:r>0&&(n=n.right)}return null}indexOf(e){let n=0,r=this.root;for(;!r.isEmpty();){let i=this.comparator(e,r.key);if(i===0)return n+r.left.size;i<0?r=r.left:(n+=r.left.size+1,r=r.right)}return-1}isEmpty(){return this.root.isEmpty()}get size(){return this.root.size}minKey(){return this.root.minKey()}maxKey(){return this.root.maxKey()}inorderTraversal(e){return this.root.inorderTraversal(e)}forEach(e){this.inorderTraversal((n,r)=>(e(n,r),!1))}toString(){let e=[];return this.inorderTraversal((n,r)=>(e.push(`${n}:${r}`),!1)),`{${e.join(", ")}}`}reverseTraversal(e){return this.root.reverseTraversal(e)}getIterator(){return new Li(this.root,null,this.comparator,!1)}getIteratorFrom(e){return new Li(this.root,e,this.comparator,!1)}getReverseIterator(){return new Li(this.root,null,this.comparator,!0)}getReverseIteratorFrom(e){return new Li(this.root,e,this.comparator,!0)}},Li=class{constructor(e,n,r,i){this.isReverse=i,this.nodeStack=[];let s=1;for(;!e.isEmpty();)if(s=n?r(e.key,n):1,n&&i&&(s*=-1),s<0)e=this.isReverse?e.left:e.right;else{if(s===0){this.nodeStack.push(e);break}this.nodeStack.push(e),e=this.isReverse?e.right:e.left}}getNext(){let e=this.nodeStack.pop(),n={key:e.key,value:e.value};if(this.isReverse)for(e=e.left;!e.isEmpty();)this.nodeStack.push(e),e=e.right;else for(e=e.right;!e.isEmpty();)this.nodeStack.push(e),e=e.left;return n}hasNext(){return this.nodeStack.length>0}peek(){if(this.nodeStack.length===0)return null;let e=this.nodeStack[this.nodeStack.length-1];return{key:e.key,value:e.value}}},we=class{constructor(e,n,r,i,s){this.key=e,this.value=n,this.color=r??we.RED,this.left=i??we.EMPTY,this.right=s??we.EMPTY,this.size=this.left.size+1+this.right.size}copy(e,n,r,i,s){return new we(e??this.key,n??this.value,r??this.color,i??this.left,s??this.right)}isEmpty(){return!1}inorderTraversal(e){return this.left.inorderTraversal(e)||e(this.key,this.value)||this.right.inorderTraversal(e)}reverseTraversal(e){return this.right.reverseTraversal(e)||e(this.key,this.value)||this.left.reverseTraversal(e)}min(){return this.left.isEmpty()?this:this.left.min()}minKey(){return this.min().key}maxKey(){return this.right.isEmpty()?this.key:this.right.maxKey()}insert(e,n,r){let i=this,s=r(e,i.key);return i=s<0?i.copy(null,null,null,i.left.insert(e,n,r),null):s===0?i.copy(null,n,null,null,null):i.copy(null,null,null,null,i.right.insert(e,n,r)),i.fixUp()}removeMin(){if(this.left.isEmpty())return we.EMPTY;let e=this;return e.left.isRed()||e.left.left.isRed()||(e=e.moveRedLeft()),e=e.copy(null,null,null,e.left.removeMin(),null),e.fixUp()}remove(e,n){let r,i=this;if(n(e,i.key)<0)i.left.isEmpty()||i.left.isRed()||i.left.left.isRed()||(i=i.moveRedLeft()),i=i.copy(null,null,null,i.left.remove(e,n),null);else{if(i.left.isRed()&&(i=i.rotateRight()),i.right.isEmpty()||i.right.isRed()||i.right.left.isRed()||(i=i.moveRedRight()),n(e,i.key)===0){if(i.right.isEmpty())return we.EMPTY;r=i.right.min(),i=i.copy(r.key,r.value,null,null,i.right.removeMin())}i=i.copy(null,null,null,null,i.right.remove(e,n))}return i.fixUp()}isRed(){return this.color}fixUp(){let e=this;return e.right.isRed()&&!e.left.isRed()&&(e=e.rotateLeft()),e.left.isRed()&&e.left.left.isRed()&&(e=e.rotateRight()),e.left.isRed()&&e.right.isRed()&&(e=e.colorFlip()),e}moveRedLeft(){let e=this.colorFlip();return e.right.left.isRed()&&(e=e.copy(null,null,null,null,e.right.rotateRight()),e=e.rotateLeft(),e=e.colorFlip()),e}moveRedRight(){let e=this.colorFlip();return e.left.left.isRed()&&(e=e.rotateRight(),e=e.colorFlip()),e}rotateLeft(){let e=this.copy(null,null,we.RED,null,this.right.left);return this.right.copy(null,null,this.color,e,null)}rotateRight(){let e=this.copy(null,null,we.RED,this.left.right,null);return this.left.copy(null,null,this.color,null,e)}colorFlip(){let e=this.left.copy(null,null,!this.left.color,null,null),n=this.right.copy(null,null,!this.right.color,null,null);return this.copy(null,null,!this.color,e,n)}checkMaxDepth(){let e=this.check();return Math.pow(2,e)<=this.size+1}check(){if(this.isRed()&&this.left.isRed()||this.right.isRed())throw z();let e=this.left.check();if(e!==this.right.check())throw z();return e+(this.isRed()?0:1)}};we.EMPTY=null,we.RED=!0,we.BLACK=!1;we.EMPTY=new class{constructor(){this.size=0}get key(){throw z()}get value(){throw z()}get color(){throw z()}get left(){throw z()}get right(){throw z()}copy(t,e,n,r,i){return this}insert(t,e,n){return new we(t,e)}remove(t,e){return this}isEmpty(){return!0}inorderTraversal(t){return!1}reverseTraversal(t){return!1}minKey(){return null}maxKey(){return null}isRed(){return!1}checkMaxDepth(){return!0}check(){return 0}};var De=class{constructor(e){this.comparator=e,this.data=new oe(this.comparator)}has(e){return this.data.get(e)!==null}first(){return this.data.minKey()}last(){return this.data.maxKey()}get size(){return this.data.size}indexOf(e){return this.data.indexOf(e)}forEach(e){this.data.inorderTraversal((n,r)=>(e(n),!1))}forEachInRange(e,n){let r=this.data.getIteratorFrom(e[0]);for(;r.hasNext();){let i=r.getNext();if(this.comparator(i.key,e[1])>=0)return;n(i.key)}}forEachWhile(e,n){let r;for(r=n!==void 0?this.data.getIteratorFrom(n):this.data.getIterator();r.hasNext();)if(!e(r.getNext().key))return}firstAfterOrEqual(e){let n=this.data.getIteratorFrom(e);return n.hasNext()?n.getNext().key:null}getIterator(){return new pu(this.data.getIterator())}getIteratorFrom(e){return new pu(this.data.getIteratorFrom(e))}add(e){return this.copy(this.data.remove(e).insert(e,!0))}delete(e){return this.has(e)?this.copy(this.data.remove(e)):this}isEmpty(){return this.data.isEmpty()}unionWith(e){let n=this;return n.size<e.size&&(n=e,e=this),e.forEach(r=>{n=n.add(r)}),n}isEqual(e){if(!(e instanceof De)||this.size!==e.size)return!1;let n=this.data.getIterator(),r=e.data.getIterator();for(;n.hasNext();){let i=n.getNext().key,s=r.getNext().key;if(this.comparator(i,s)!==0)return!1}return!0}toArray(){let e=[];return this.forEach(n=>{e.push(n)}),e}toString(){let e=[];return this.forEach(n=>e.push(n)),"SortedSet("+e.toString()+")"}copy(e){let n=new De(this.comparator);return n.data=e,n}},pu=class{constructor(e){this.iter=e}getNext(){return this.iter.getNext().key}hasNext(){return this.iter.hasNext()}};var Yt=class{constructor(e){this.fields=e,e.sort(Qe.comparator)}static empty(){return new Yt([])}unionWith(e){let n=new De(Qe.comparator);for(let r of this.fields)n=n.add(r);for(let r of e)n=n.add(r);return new Yt(n.toArray())}covers(e){for(let n of this.fields)if(n.isPrefixOf(e))return!0;return!1}isEqual(e){return Fi(this.fields,e.fields,(n,r)=>n.isEqual(r))}};var mu=class extends Error{constructor(){super(...arguments),this.name="Base64DecodeError"}};var Ne=class{constructor(e){this.binaryString=e}static fromBase64String(e){let n=function(r){try{return atob(r)}catch(i){throw typeof DOMException<"u"&&i instanceof DOMException?new mu("Invalid base64 string: "+i):i}}(e);return new Ne(n)}static fromUint8Array(e){let n=function(r){let i="";for(let s=0;s<r.length;++s)i+=String.fromCharCode(r[s]);return i}(e);return new Ne(n)}[Symbol.iterator](){let e=0;return{next:()=>e<this.binaryString.length?{value:this.binaryString.charCodeAt(e++),done:!1}:{value:void 0,done:!0}}}toBase64(){return e=this.binaryString,btoa(e);var e}toUint8Array(){return function(e){let n=new Uint8Array(e.length);for(let r=0;r<e.length;r++)n[r]=e.charCodeAt(r);return n}(this.binaryString)}approximateByteSize(){return 2*this.binaryString.length}compareTo(e){return X(this.binaryString,e.binaryString)}isEqual(e){return this.binaryString===e.binaryString}};Ne.EMPTY_BYTE_STRING=new Ne("");var nI=new RegExp(/^\d{4}-\d\d-\d\dT\d\d:\d\d:\d\d(?:\.(\d+))?Z$/);function rr(t){if(Ee(!!t),typeof t=="string"){let e=0,n=nI.exec(t);if(Ee(!!n),n[1]){let i=n[1];i=(i+"000000000").substr(0,9),e=Number(i)}let r=new Date(t);return{seconds:Math.floor(r.getTime()/1e3),nanos:e}}return{seconds:de(t.seconds),nanos:de(t.nanos)}}function de(t){return typeof t=="number"?t:typeof t=="string"?Number(t):0}function ir(t){return typeof t=="string"?Ne.fromBase64String(t):Ne.fromUint8Array(t)}function am(t){var e,n;return((n=(((e=t?.mapValue)===null||e===void 0?void 0:e.fields)||{}).__type__)===null||n===void 0?void 0:n.stringValue)==="server_timestamp"}function lm(t){let e=t.mapValue.fields.__previous_value__;return am(e)?lm(e):e}function To(t){let e=rr(t.mapValue.fields.__local_write_time__.timestampValue);return new He(e.seconds,e.nanos)}var Hf=class{constructor(e,n,r,i,s,o,a,l){this.databaseId=e,this.appId=n,this.persistenceKey=r,this.host=i,this.ssl=s,this.forceLongPolling=o,this.autoDetectLongPolling=a,this.useFetchStreams=l}},jr=class{constructor(e,n){this.projectId=e,this.database=n||"(default)"}static empty(){return new jr("","")}get isDefaultDatabase(){return this.database==="(default)"}isEqual(e){return e instanceof jr&&e.projectId===this.projectId&&e.database===this.database}};var au={mapValue:{fields:{__type__:{stringValue:"__max__"}}}};function Qr(t){return"nullValue"in t?0:"booleanValue"in t?1:"integerValue"in t||"doubleValue"in t?2:"timestampValue"in t?3:"stringValue"in t?5:"bytesValue"in t?6:"referenceValue"in t?7:"geoPointValue"in t?8:"arrayValue"in t?9:"mapValue"in t?am(t)?4:xw(t)?9007199254740991:10:z()}function tn(t,e){if(t===e)return!0;let n=Qr(t);if(n!==Qr(e))return!1;switch(n){case 0:case 9007199254740991:return!0;case 1:return t.booleanValue===e.booleanValue;case 4:return To(t).isEqual(To(e));case 3:return function(r,i){if(typeof r.timestampValue=="string"&&typeof i.timestampValue=="string"&&r.timestampValue.length===i.timestampValue.length)return r.timestampValue===i.timestampValue;let s=rr(r.timestampValue),o=rr(i.timestampValue);return s.seconds===o.seconds&&s.nanos===o.nanos}(t,e);case 5:return t.stringValue===e.stringValue;case 6:return function(r,i){return ir(r.bytesValue).isEqual(ir(i.bytesValue))}(t,e);case 7:return t.referenceValue===e.referenceValue;case 8:return function(r,i){return de(r.geoPointValue.latitude)===de(i.geoPointValue.latitude)&&de(r.geoPointValue.longitude)===de(i.geoPointValue.longitude)}(t,e);case 2:return function(r,i){if("integerValue"in r&&"integerValue"in i)return de(r.integerValue)===de(i.integerValue);if("doubleValue"in r&&"doubleValue"in i){let s=de(r.doubleValue),o=de(i.doubleValue);return s===o?fu(s)===fu(o):isNaN(s)&&isNaN(o)}return!1}(t,e);case 9:return Fi(t.arrayValue.values||[],e.arrayValue.values||[],tn);case 10:return function(r,i){let s=r.mapValue.fields||{},o=i.mapValue.fields||{};if(Yv(s)!==Yv(o))return!1;for(let a in s)if(s.hasOwnProperty(a)&&(o[a]===void 0||!tn(s[a],o[a])))return!1;return!0}(t,e);default:return z()}}function Co(t,e){return(t.values||[]).find(n=>tn(n,e))!==void 0}function Bi(t,e){if(t===e)return 0;let n=Qr(t),r=Qr(e);if(n!==r)return X(n,r);switch(n){case 0:case 9007199254740991:return 0;case 1:return X(t.booleanValue,e.booleanValue);case 2:return function(i,s){let o=de(i.integerValue||i.doubleValue),a=de(s.integerValue||s.doubleValue);return o<a?-1:o>a?1:o===a?0:isNaN(o)?isNaN(a)?0:-1:1}(t,e);case 3:return $v(t.timestampValue,e.timestampValue);case 4:return $v(To(t),To(e));case 5:return X(t.stringValue,e.stringValue);case 6:return function(i,s){let o=ir(i),a=ir(s);return o.compareTo(a)}(t.bytesValue,e.bytesValue);case 7:return function(i,s){let o=i.split("/"),a=s.split("/");for(let l=0;l<o.length&&l<a.length;l++){let u=X(o[l],a[l]);if(u!==0)return u}return X(o.length,a.length)}(t.referenceValue,e.referenceValue);case 8:return function(i,s){let o=X(de(i.latitude),de(s.latitude));return o!==0?o:X(de(i.longitude),de(s.longitude))}(t.geoPointValue,e.geoPointValue);case 9:return function(i,s){let o=i.values||[],a=s.values||[];for(let l=0;l<o.length&&l<a.length;++l){let u=Bi(o[l],a[l]);if(u)return u}return X(o.length,a.length)}(t.arrayValue,e.arrayValue);case 10:return function(i,s){if(i===au.mapValue&&s===au.mapValue)return 0;if(i===au.mapValue)return 1;if(s===au.mapValue)return-1;let o=i.fields||{},a=Object.keys(o),l=s.fields||{},u=Object.keys(l);a.sort(),u.sort();for(let c=0;c<a.length&&c<u.length;++c){let h=X(a[c],u[c]);if(h!==0)return h;let p=Bi(o[a[c]],l[u[c]]);if(p!==0)return p}return X(a.length,u.length)}(t.mapValue,e.mapValue);default:throw z()}}function $v(t,e){if(typeof t=="string"&&typeof e=="string"&&t.length===e.length)return X(t,e);let n=rr(t),r=rr(e),i=X(n.seconds,r.seconds);return i!==0?i:X(n.nanos,r.nanos)}function qi(t){return Kf(t)}function Kf(t){return"nullValue"in t?"null":"booleanValue"in t?""+t.booleanValue:"integerValue"in t?""+t.integerValue:"doubleValue"in t?""+t.doubleValue:"timestampValue"in t?function(r){let i=rr(r);return`time(${i.seconds},${i.nanos})`}(t.timestampValue):"stringValue"in t?t.stringValue:"bytesValue"in t?ir(t.bytesValue).toBase64():"referenceValue"in t?(n=t.referenceValue,_.fromName(n).toString()):"geoPointValue"in t?`geo(${(e=t.geoPointValue).latitude},${e.longitude})`:"arrayValue"in t?function(r){let i="[",s=!0;for(let o of r.values||[])s?s=!1:i+=",",i+=Kf(o);return i+"]"}(t.arrayValue):"mapValue"in t?function(r){let i=Object.keys(r.fields||{}).sort(),s="{",o=!0;for(let a of i)o?o=!1:s+=",",s+=`${a}:${Kf(r.fields[a])}`;return s+"}"}(t.mapValue):z();var e,n}function Xf(t){return!!t&&"integerValue"in t}function um(t){return!!t&&"arrayValue"in t}function ew(t){return!!t&&"nullValue"in t}function tw(t){return!!t&&"doubleValue"in t&&isNaN(Number(t.doubleValue))}function _f(t){return!!t&&"mapValue"in t}function Eo(t){if(t.geoPointValue)return{geoPointValue:Object.assign({},t.geoPointValue)};if(t.timestampValue&&typeof t.timestampValue=="object")return{timestampValue:Object.assign({},t.timestampValue)};if(t.mapValue){let e={mapValue:{fields:{}}};return Mu(t.mapValue.fields,(n,r)=>e.mapValue.fields[n]=Eo(r)),e}if(t.arrayValue){let e={arrayValue:{values:[]}};for(let n=0;n<(t.arrayValue.values||[]).length;++n)e.arrayValue.values[n]=Eo(t.arrayValue.values[n]);return e}return Object.assign({},t)}function xw(t){return(((t.mapValue||{}).fields||{}).__type__||{}).stringValue==="__max__"}var xt=class{constructor(e){this.value=e}static empty(){return new xt({mapValue:{}})}field(e){if(e.isEmpty())return this.value;{let n=this.value;for(let r=0;r<e.length-1;++r)if(n=(n.mapValue.fields||{})[e.get(r)],!_f(n))return null;return n=(n.mapValue.fields||{})[e.lastSegment()],n||null}}set(e,n){this.getFieldsMap(e.popLast())[e.lastSegment()]=Eo(n)}setAll(e){let n=Qe.emptyPath(),r={},i=[];e.forEach((o,a)=>{if(!n.isImmediateParentOf(a)){let l=this.getFieldsMap(n);this.applyChanges(l,r,i),r={},i=[],n=a.popLast()}o?r[a.lastSegment()]=Eo(o):i.push(a.lastSegment())});let s=this.getFieldsMap(n);this.applyChanges(s,r,i)}delete(e){let n=this.field(e.popLast());_f(n)&&n.mapValue.fields&&delete n.mapValue.fields[e.lastSegment()]}isEqual(e){return tn(this.value,e.value)}getFieldsMap(e){let n=this.value;n.mapValue.fields||(n.mapValue={fields:{}});for(let r=0;r<e.length;++r){let i=n.mapValue.fields[e.get(r)];_f(i)&&i.mapValue.fields||(i={mapValue:{fields:{}}},n.mapValue.fields[e.get(r)]=i),n=i}return n.mapValue.fields}applyChanges(e,n,r){Mu(n,(i,s)=>e[i]=s);for(let i of r)delete e[i]}clone(){return new xt(Eo(this.value))}};var ke=class{constructor(e,n,r,i,s,o,a){this.key=e,this.documentType=n,this.version=r,this.readTime=i,this.createTime=s,this.data=o,this.documentState=a}static newInvalidDocument(e){return new ke(e,0,R.min(),R.min(),R.min(),xt.empty(),0)}static newFoundDocument(e,n,r,i){return new ke(e,1,n,R.min(),r,i,0)}static newNoDocument(e,n){return new ke(e,2,n,R.min(),R.min(),xt.empty(),0)}static newUnknownDocument(e,n){return new ke(e,3,n,R.min(),R.min(),xt.empty(),2)}convertToFoundDocument(e,n){return!this.createTime.isEqual(R.min())||this.documentType!==2&&this.documentType!==0||(this.createTime=e),this.version=e,this.documentType=1,this.data=n,this.documentState=0,this}convertToNoDocument(e){return this.version=e,this.documentType=2,this.data=xt.empty(),this.documentState=0,this}convertToUnknownDocument(e){return this.version=e,this.documentType=3,this.data=xt.empty(),this.documentState=2,this}setHasCommittedMutations(){return this.documentState=2,this}setHasLocalMutations(){return this.documentState=1,this.version=R.min(),this}setReadTime(e){return this.readTime=e,this}get hasLocalMutations(){return this.documentState===1}get hasCommittedMutations(){return this.documentState===2}get hasPendingWrites(){return this.hasLocalMutations||this.hasCommittedMutations}isValidDocument(){return this.documentType!==0}isFoundDocument(){return this.documentType===1}isNoDocument(){return this.documentType===2}isUnknownDocument(){return this.documentType===3}isEqual(e){return e instanceof ke&&this.key.isEqual(e.key)&&this.version.isEqual(e.version)&&this.documentType===e.documentType&&this.documentState===e.documentState&&this.data.isEqual(e.data)}mutableCopy(){return new ke(this.key,this.documentType,this.version,this.readTime,this.createTime,this.data.clone(),this.documentState)}toString(){return`Document(${this.key}, ${this.version}, ${JSON.stringify(this.data.value)}, {createTime: ${this.createTime}}), {documentType: ${this.documentType}}), {documentState: ${this.documentState}})`}};var Vi=class{constructor(e,n){this.position=e,this.inclusive=n}};function nw(t,e,n){let r=0;for(let i=0;i<t.position.length;i++){let s=e[i],o=t.position[i];if(s.field.isKeyField()?r=_.comparator(_.fromName(o.referenceValue),n.key):r=Bi(o,n.data.field(s.field)),s.dir==="desc"&&(r*=-1),r!==0)break}return r}function rw(t,e){if(t===null)return e===null;if(e===null||t.inclusive!==e.inclusive||t.position.length!==e.position.length)return!1;for(let n=0;n<t.position.length;n++)if(!tn(t.position[n],e.position[n]))return!1;return!0}var qr=class{constructor(e,n="asc"){this.field=e,this.dir=n}};function rI(t,e){return t.dir===e.dir&&t.field.isEqual(e.field)}var gu=class{},pe=class extends gu{constructor(e,n,r){super(),this.field=e,this.op=n,this.value=r}static create(e,n,r){return e.isKeyField()?n==="in"||n==="not-in"?this.createKeyFieldInFilter(e,n,r):new Gf(e,n,r):n==="array-contains"?new Yf(e,r):n==="in"?new $f(e,r):n==="not-in"?new ep(e,r):n==="array-contains-any"?new tp(e,r):new pe(e,n,r)}static createKeyFieldInFilter(e,n,r){return n==="in"?new Jf(e,r):new Zf(e,r)}matches(e){let n=e.data.field(this.field);return this.op==="!="?n!==null&&this.matchesComparison(Bi(n,this.value)):n!==null&&Qr(this.value)===Qr(n)&&this.matchesComparison(Bi(n,this.value))}matchesComparison(e){switch(this.op){case"<":return e<0;case"<=":return e<=0;case"==":return e===0;case"!=":return e!==0;case">":return e>0;case">=":return e>=0;default:return z()}}isInequality(){return["<","<=",">",">=","!=","not-in"].indexOf(this.op)>=0}getFlattenedFilters(){return[this]}getFilters(){return[this]}getFirstInequalityField(){return this.isInequality()?this.field:null}},Tt=class extends gu{constructor(e,n){super(),this.filters=e,this.op=n,this.ht=null}static create(e,n){return new Tt(e,n)}matches(e){return Tw(this)?this.filters.find(n=>!n.matches(e))===void 0:this.filters.find(n=>n.matches(e))!==void 0}getFlattenedFilters(){return this.ht!==null||(this.ht=this.filters.reduce((e,n)=>e.concat(n.getFlattenedFilters()),[])),this.ht}getFilters(){return Object.assign([],this.filters)}getFirstInequalityField(){let e=this.lt(n=>n.isInequality());return e!==null?e.field:null}lt(e){for(let n of this.getFlattenedFilters())if(e(n))return n;return null}};function Tw(t){return t.op==="and"}function Cw(t){return iI(t)&&Tw(t)}function iI(t){for(let e of t.filters)if(e instanceof Tt)return!1;return!0}function Wf(t){if(t instanceof pe)return t.field.canonicalString()+t.op.toString()+qi(t.value);if(Cw(t))return t.filters.map(e=>Wf(e)).join(",");{let e=t.filters.map(n=>Wf(n)).join(",");return`${t.op}(${e})`}}function kw(t,e){return t instanceof pe?function(n,r){return r instanceof pe&&n.op===r.op&&n.field.isEqual(r.field)&&tn(n.value,r.value)}(t,e):t instanceof Tt?function(n,r){return r instanceof Tt&&n.op===r.op&&n.filters.length===r.filters.length?n.filters.reduce((i,s,o)=>i&&kw(s,r.filters[o]),!0):!1}(t,e):void z()}function Dw(t){return t instanceof pe?function(e){return`${e.field.canonicalString()} ${e.op} ${qi(e.value)}`}(t):t instanceof Tt?function(e){return e.op.toString()+" {"+e.getFilters().map(Dw).join(" ,")+"}"}(t):"Filter"}var Gf=class extends pe{constructor(e,n,r){super(e,n,r),this.key=_.fromName(r.referenceValue)}matches(e){let n=_.comparator(e.key,this.key);return this.matchesComparison(n)}},Jf=class extends pe{constructor(e,n){super(e,"in",n),this.keys=Nw("in",n)}matches(e){return this.keys.some(n=>n.isEqual(e.key))}},Zf=class extends pe{constructor(e,n){super(e,"not-in",n),this.keys=Nw("not-in",n)}matches(e){return!this.keys.some(n=>n.isEqual(e.key))}};function Nw(t,e){var n;return(((n=e.arrayValue)===null||n===void 0?void 0:n.values)||[]).map(r=>_.fromName(r.referenceValue))}var Yf=class extends pe{constructor(e,n){super(e,"array-contains",n)}matches(e){let n=e.data.field(this.field);return um(n)&&Co(n.arrayValue,this.value)}},$f=class extends pe{constructor(e,n){super(e,"in",n)}matches(e){let n=e.data.field(this.field);return n!==null&&Co(this.value.arrayValue,n)}},ep=class extends pe{constructor(e,n){super(e,"not-in",n)}matches(e){if(Co(this.value.arrayValue,{nullValue:"NULL_VALUE"}))return!1;let n=e.data.field(this.field);return n!==null&&!Co(this.value.arrayValue,n)}},tp=class extends pe{constructor(e,n){super(e,"array-contains-any",n)}matches(e){let n=e.data.field(this.field);return!(!um(n)||!n.arrayValue.values)&&n.arrayValue.values.some(r=>Co(this.value.arrayValue,r))}};var np=class{constructor(e,n=null,r=[],i=[],s=null,o=null,a=null){this.path=e,this.collectionGroup=n,this.orderBy=r,this.filters=i,this.limit=s,this.startAt=o,this.endAt=a,this.ft=null}};function iw(t,e=null,n=[],r=[],i=null,s=null,o=null){return new np(t,e,n,r,i,s,o)}function cm(t){let e=Q(t);if(e.ft===null){let n=e.path.canonicalString();e.collectionGroup!==null&&(n+="|cg:"+e.collectionGroup),n+="|f:",n+=e.filters.map(r=>Wf(r)).join(","),n+="|ob:",n+=e.orderBy.map(r=>function(i){return i.field.canonicalString()+i.dir}(r)).join(","),Lu(e.limit)||(n+="|l:",n+=e.limit),e.startAt&&(n+="|lb:",n+=e.startAt.inclusive?"b:":"a:",n+=e.startAt.position.map(r=>qi(r)).join(",")),e.endAt&&(n+="|ub:",n+=e.endAt.inclusive?"a:":"b:",n+=e.endAt.position.map(r=>qi(r)).join(",")),e.ft=n}return e.ft}function hm(t,e){if(t.limit!==e.limit||t.orderBy.length!==e.orderBy.length)return!1;for(let n=0;n<t.orderBy.length;n++)if(!rI(t.orderBy[n],e.orderBy[n]))return!1;if(t.filters.length!==e.filters.length)return!1;for(let n=0;n<t.filters.length;n++)if(!kw(t.filters[n],e.filters[n]))return!1;return t.collectionGroup===e.collectionGroup&&!!t.path.isEqual(e.path)&&!!rw(t.startAt,e.startAt)&&rw(t.endAt,e.endAt)}function rp(t){return _.isDocumentKey(t.path)&&t.collectionGroup===null&&t.filters.length===0}var Ui=class{constructor(e,n=null,r=[],i=[],s=null,o="F",a=null,l=null){this.path=e,this.collectionGroup=n,this.explicitOrderBy=r,this.filters=i,this.limit=s,this.limitType=o,this.startAt=a,this.endAt=l,this.dt=null,this._t=null,this.startAt,this.endAt}};function sI(t,e,n,r,i,s,o,a){return new Ui(t,e,n,r,i,s,o,a)}function dm(t){return new Ui(t)}function sw(t){return t.filters.length===0&&t.limit===null&&t.startAt==null&&t.endAt==null&&(t.explicitOrderBy.length===0||t.explicitOrderBy.length===1&&t.explicitOrderBy[0].field.isKeyField())}function oI(t){return t.explicitOrderBy.length>0?t.explicitOrderBy[0].field:null}function aI(t){for(let e of t.filters){let n=e.getFirstInequalityField();if(n!==null)return n}return null}function lI(t){return t.collectionGroup!==null}function Mi(t){let e=Q(t);if(e.dt===null){e.dt=[];let n=aI(e),r=oI(e);if(n!==null&&r===null)n.isKeyField()||e.dt.push(new qr(n)),e.dt.push(new qr(Qe.keyField(),"asc"));else{let i=!1;for(let s of e.explicitOrderBy)e.dt.push(s),s.field.isKeyField()&&(i=!0);if(!i){let s=e.explicitOrderBy.length>0?e.explicitOrderBy[e.explicitOrderBy.length-1].dir:"asc";e.dt.push(new qr(Qe.keyField(),s))}}}return e.dt}function xn(t){let e=Q(t);if(!e._t)if(e.limitType==="F")e._t=iw(e.path,e.collectionGroup,Mi(e),e.filters,e.limit,e.startAt,e.endAt);else{let n=[];for(let s of Mi(e)){let o=s.dir==="desc"?"asc":"desc";n.push(new qr(s.field,o))}let r=e.endAt?new Vi(e.endAt.position,e.endAt.inclusive):null,i=e.startAt?new Vi(e.startAt.position,e.startAt.inclusive):null;e._t=iw(e.path,e.collectionGroup,n,e.filters,e.limit,r,i)}return e._t}function ip(t,e,n){return new Ui(t.path,t.collectionGroup,t.explicitOrderBy.slice(),t.filters.slice(),e,n,t.startAt,t.endAt)}function bu(t,e){return hm(xn(t),xn(e))&&t.limitType===e.limitType}function Pw(t){return`${cm(xn(t))}|lt:${t.limitType}`}function sp(t){return`Query(target=${function(e){let n=e.path.canonicalString();return e.collectionGroup!==null&&(n+=" collectionGroup="+e.collectionGroup),e.filters.length>0&&(n+=`, filters: [${e.filters.map(r=>Dw(r)).join(", ")}]`),Lu(e.limit)||(n+=", limit: "+e.limit),e.orderBy.length>0&&(n+=`, orderBy: [${e.orderBy.map(r=>function(i){return`${i.field.canonicalString()} (${i.dir})`}(r)).join(", ")}]`),e.startAt&&(n+=", startAt: ",n+=e.startAt.inclusive?"b:":"a:",n+=e.startAt.position.map(r=>qi(r)).join(",")),e.endAt&&(n+=", endAt: ",n+=e.endAt.inclusive?"a:":"b:",n+=e.endAt.position.map(r=>qi(r)).join(",")),`Target(${n})`}(xn(t))}; limitType=${t.limitType})`}function Ru(t,e){return e.isFoundDocument()&&function(n,r){let i=r.key.path;return n.collectionGroup!==null?r.key.hasCollectionId(n.collectionGroup)&&n.path.isPrefixOf(i):_.isDocumentKey(n.path)?n.path.isEqual(i):n.path.isImmediateParentOf(i)}(t,e)&&function(n,r){for(let i of Mi(n))if(!i.field.isKeyField()&&r.data.field(i.field)===null)return!1;return!0}(t,e)&&function(n,r){for(let i of n.filters)if(!i.matches(r))return!1;return!0}(t,e)&&function(n,r){return!(n.startAt&&!function(i,s,o){let a=nw(i,s,o);return i.inclusive?a<=0:a<0}(n.startAt,Mi(n),r)||n.endAt&&!function(i,s,o){let a=nw(i,s,o);return i.inclusive?a>=0:a>0}(n.endAt,Mi(n),r))}(t,e)}function uI(t){return t.collectionGroup||(t.path.length%2==1?t.path.lastSegment():t.path.get(t.path.length-2))}function _w(t){return(e,n)=>{let r=!1;for(let i of Mi(t)){let s=cI(i,e,n);if(s!==0)return s;r=r||i.field.isKeyField()}return 0}}function cI(t,e,n){let r=t.field.isKeyField()?_.comparator(e.key,n.key):function(i,s,o){let a=s.data.field(i),l=o.data.field(i);return a!==null&&l!==null?Bi(a,l):z()}(t.field,e,n);switch(t.dir){case"asc":return r;case"desc":return-1*r;default:return z()}}var sr=class{constructor(e,n){this.mapKeyFn=e,this.equalsFn=n,this.inner={},this.innerSize=0}get(e){let n=this.mapKeyFn(e),r=this.inner[n];if(r!==void 0){for(let[i,s]of r)if(this.equalsFn(i,e))return s}}has(e){return this.get(e)!==void 0}set(e,n){let r=this.mapKeyFn(e),i=this.inner[r];if(i===void 0)return this.inner[r]=[[e,n]],void this.innerSize++;for(let s=0;s<i.length;s++)if(this.equalsFn(i[s][0],e))return void(i[s]=[e,n]);i.push([e,n]),this.innerSize++}delete(e){let n=this.mapKeyFn(e),r=this.inner[n];if(r===void 0)return!1;for(let i=0;i<r.length;i++)if(this.equalsFn(r[i][0],e))return r.length===1?delete this.inner[n]:r.splice(i,1),this.innerSize--,!0;return!1}forEach(e){Mu(this.inner,(n,r)=>{for(let[i,s]of r)e(i,s)})}isEmpty(){return tI(this.inner)}size(){return this.innerSize}};var hI=new oe(_.comparator);function or(){return hI}var Ow=new oe(_.comparator);function wo(...t){let e=Ow;for(let n of t)e=e.insert(n.key,n);return e}function dI(t){let e=Ow;return t.forEach((n,r)=>e=e.insert(n,r.overlayedDocument)),e}function Fr(){return So()}function Lw(){return So()}function So(){return new sr(t=>t.toString(),(t,e)=>t.isEqual(e))}var TC=new oe(_.comparator),fI=new De(_.comparator);function j(...t){let e=fI;for(let n of t)e=e.add(n);return e}var pI=new De(X);function mI(){return pI}function gI(t,e){if(t.useProto3Json){if(isNaN(e))return{doubleValue:"NaN"};if(e===1/0)return{doubleValue:"Infinity"};if(e===-1/0)return{doubleValue:"-Infinity"}}return{doubleValue:fu(e)?"-0":e}}function yI(t){return{integerValue:""+t}}var ji=class{constructor(){this._=void 0}};function AI(t,e,n){return t instanceof ko?function(r,i){let s={fields:{__type__:{stringValue:"server_timestamp"},__local_write_time__:{timestampValue:{seconds:r.seconds,nanos:r.nanoseconds}}}};return i&&am(i)&&(i=lm(i)),i&&(s.fields.__previous_value__=i),{mapValue:s}}(n,e):t instanceof Qi?Mw(t,e):t instanceof Hi?bw(t,e):function(r,i){let s=wI(r,i),o=ow(s)+ow(r.wt);return Xf(s)&&Xf(r.wt)?yI(o):gI(r.serializer,o)}(t,e)}function vI(t,e,n){return t instanceof Qi?Mw(t,e):t instanceof Hi?bw(t,e):n}function wI(t,e){return t instanceof Do?Xf(n=e)||function(r){return!!r&&"doubleValue"in r}(n)?e:{integerValue:0}:null;var n}var ko=class extends ji{},Qi=class extends ji{constructor(e){super(),this.elements=e}};function Mw(t,e){let n=Rw(e);for(let r of t.elements)n.some(i=>tn(i,r))||n.push(r);return{arrayValue:{values:n}}}var Hi=class extends ji{constructor(e){super(),this.elements=e}};function bw(t,e){let n=Rw(e);for(let r of t.elements)n=n.filter(i=>!tn(i,r));return{arrayValue:{values:n}}}var Do=class extends ji{constructor(e,n){super(),this.serializer=e,this.wt=n}};function ow(t){return de(t.integerValue||t.doubleValue)}function Rw(t){return um(t)&&t.arrayValue.values?t.arrayValue.values.slice():[]}function EI(t,e){return t.field.isEqual(e.field)&&function(n,r){return n instanceof Qi&&r instanceof Qi||n instanceof Hi&&r instanceof Hi?Fi(n.elements,r.elements,tn):n instanceof Do&&r instanceof Do?tn(n.wt,r.wt):n instanceof ko&&r instanceof ko}(t.transform,e.transform)}var Sn=class{constructor(e,n){this.updateTime=e,this.exists=n}static none(){return new Sn}static exists(e){return new Sn(void 0,e)}static updateTime(e){return new Sn(e)}get isNone(){return this.updateTime===void 0&&this.exists===void 0}isEqual(e){return this.exists===e.exists&&(this.updateTime?!!e.updateTime&&this.updateTime.isEqual(e.updateTime):!e.updateTime)}};function cu(t,e){return t.updateTime!==void 0?e.isFoundDocument()&&e.version.isEqual(t.updateTime):t.exists===void 0||t.exists===e.isFoundDocument()}var No=class{};function zw(t,e){if(!t.hasLocalMutations||e&&e.fields.length===0)return null;if(e===null)return t.isNoDocument()?new op(t.key,Sn.none()):new Po(t.key,t.data,Sn.none());{let n=t.data,r=xt.empty(),i=new De(Qe.comparator);for(let s of e.fields)if(!i.has(s)){let o=n.field(s);o===null&&s.length>1&&(s=s.popLast(),o=n.field(s)),o===null?r.delete(s):r.set(s,o),i=i.add(s)}return new Ki(t.key,r,new Yt(i.toArray()),Sn.none())}}function SI(t,e,n){t instanceof Po?function(r,i,s){let o=r.value.clone(),a=lw(r.fieldTransforms,i,s.transformResults);o.setAll(a),i.convertToFoundDocument(s.version,o).setHasCommittedMutations()}(t,e,n):t instanceof Ki?function(r,i,s){if(!cu(r.precondition,i))return void i.convertToUnknownDocument(s.version);let o=lw(r.fieldTransforms,i,s.transformResults),a=i.data;a.setAll(Fw(r)),a.setAll(o),i.convertToFoundDocument(s.version,a).setHasCommittedMutations()}(t,e,n):function(r,i,s){i.convertToNoDocument(s.version).setHasCommittedMutations()}(0,e,n)}function Io(t,e,n,r){return t instanceof Po?function(i,s,o,a){if(!cu(i.precondition,s))return o;let l=i.value.clone(),u=uw(i.fieldTransforms,a,s);return l.setAll(u),s.convertToFoundDocument(s.version,l).setHasLocalMutations(),null}(t,e,n,r):t instanceof Ki?function(i,s,o,a){if(!cu(i.precondition,s))return o;let l=uw(i.fieldTransforms,a,s),u=s.data;return u.setAll(Fw(i)),u.setAll(l),s.convertToFoundDocument(s.version,u).setHasLocalMutations(),o===null?null:o.unionWith(i.fieldMask.fields).unionWith(i.fieldTransforms.map(c=>c.field))}(t,e,n,r):function(i,s,o){return cu(i.precondition,s)?(s.convertToNoDocument(s.version).setHasLocalMutations(),null):o}(t,e,n)}function aw(t,e){return t.type===e.type&&!!t.key.isEqual(e.key)&&!!t.precondition.isEqual(e.precondition)&&!!function(n,r){return n===void 0&&r===void 0||!(!n||!r)&&Fi(n,r,(i,s)=>EI(i,s))}(t.fieldTransforms,e.fieldTransforms)&&(t.type===0?t.value.isEqual(e.value):t.type!==1||t.data.isEqual(e.data)&&t.fieldMask.isEqual(e.fieldMask))}var Po=class extends No{constructor(e,n,r,i=[]){super(),this.key=e,this.value=n,this.precondition=r,this.fieldTransforms=i,this.type=0}getFieldMask(){return null}},Ki=class extends No{constructor(e,n,r,i,s=[]){super(),this.key=e,this.data=n,this.fieldMask=r,this.precondition=i,this.fieldTransforms=s,this.type=1}getFieldMask(){return this.fieldMask}};function Fw(t){let e=new Map;return t.fieldMask.fields.forEach(n=>{if(!n.isEmpty()){let r=t.data.field(n);e.set(n,r)}}),e}function lw(t,e,n){let r=new Map;Ee(t.length===n.length);for(let i=0;i<n.length;i++){let s=t[i],o=s.transform,a=e.data.field(s.field);r.set(s.field,vI(o,a,n[i]))}return r}function uw(t,e,n){let r=new Map;for(let i of t){let s=i.transform,o=n.data.field(i.field);r.set(i.field,AI(s,o,e))}return r}var op=class extends No{constructor(e,n){super(),this.key=e,this.precondition=n,this.type=2,this.fieldTransforms=[]}getFieldMask(){return null}};var ap=class{constructor(e,n,r,i){this.batchId=e,this.localWriteTime=n,this.baseMutations=r,this.mutations=i}applyToRemoteDocument(e,n){let r=n.mutationResults;for(let i=0;i<this.mutations.length;i++){let s=this.mutations[i];s.key.isEqual(e.key)&&SI(s,e,r[i])}}applyToLocalView(e,n){for(let r of this.baseMutations)r.key.isEqual(e.key)&&(n=Io(r,e,n,this.localWriteTime));for(let r of this.mutations)r.key.isEqual(e.key)&&(n=Io(r,e,n,this.localWriteTime));return n}applyToLocalDocumentSet(e,n){let r=Lw();return this.mutations.forEach(i=>{let s=e.get(i.key),o=s.overlayedDocument,a=this.applyToLocalView(o,s.mutatedFields);a=n.has(i.key)?null:a;let l=zw(o,a);l!==null&&r.set(i.key,l),o.isValidDocument()||o.convertToNoDocument(R.min())}),r}keys(){return this.mutations.reduce((e,n)=>e.add(n.key),j())}isEqual(e){return this.batchId===e.batchId&&Fi(this.mutations,e.mutations,(n,r)=>aw(n,r))&&Fi(this.baseMutations,e.baseMutations,(n,r)=>aw(n,r))}};var lp=class{constructor(e,n){this.largestBatchId=e,this.mutation=n}getKey(){return this.mutation.key}isEqual(e){return e!==null&&this.mutation===e.mutation}toString(){return`Overlay{
      largestBatchId: ${this.largestBatchId},
      mutation: ${this.mutation.toString()}
    }`}};var up=class{constructor(e,n){this.count=e,this.unchangedNames=n}};var ge,V;function Bw(t){if(t===void 0)return In("GRPC error has no .code"),x.UNKNOWN;switch(t){case ge.OK:return x.OK;case ge.CANCELLED:return x.CANCELLED;case ge.UNKNOWN:return x.UNKNOWN;case ge.DEADLINE_EXCEEDED:return x.DEADLINE_EXCEEDED;case ge.RESOURCE_EXHAUSTED:return x.RESOURCE_EXHAUSTED;case ge.INTERNAL:return x.INTERNAL;case ge.UNAVAILABLE:return x.UNAVAILABLE;case ge.UNAUTHENTICATED:return x.UNAUTHENTICATED;case ge.INVALID_ARGUMENT:return x.INVALID_ARGUMENT;case ge.NOT_FOUND:return x.NOT_FOUND;case ge.ALREADY_EXISTS:return x.ALREADY_EXISTS;case ge.PERMISSION_DENIED:return x.PERMISSION_DENIED;case ge.FAILED_PRECONDITION:return x.FAILED_PRECONDITION;case ge.ABORTED:return x.ABORTED;case ge.OUT_OF_RANGE:return x.OUT_OF_RANGE;case ge.UNIMPLEMENTED:return x.UNIMPLEMENTED;case ge.DATA_LOSS:return x.DATA_LOSS;default:return z()}}(V=ge||(ge={}))[V.OK=0]="OK",V[V.CANCELLED=1]="CANCELLED",V[V.UNKNOWN=2]="UNKNOWN",V[V.INVALID_ARGUMENT=3]="INVALID_ARGUMENT",V[V.DEADLINE_EXCEEDED=4]="DEADLINE_EXCEEDED",V[V.NOT_FOUND=5]="NOT_FOUND",V[V.ALREADY_EXISTS=6]="ALREADY_EXISTS",V[V.PERMISSION_DENIED=7]="PERMISSION_DENIED",V[V.UNAUTHENTICATED=16]="UNAUTHENTICATED",V[V.RESOURCE_EXHAUSTED=8]="RESOURCE_EXHAUSTED",V[V.FAILED_PRECONDITION=9]="FAILED_PRECONDITION",V[V.ABORTED=10]="ABORTED",V[V.OUT_OF_RANGE=11]="OUT_OF_RANGE",V[V.UNIMPLEMENTED=12]="UNIMPLEMENTED",V[V.INTERNAL=13]="INTERNAL",V[V.UNAVAILABLE=14]="UNAVAILABLE",V[V.DATA_LOSS=15]="DATA_LOSS";var _o=class{constructor(){this.onExistenceFilterMismatchCallbacks=new Map}static get instance(){return lu}static getOrCreateInstance(){return lu===null&&(lu=new _o),lu}onExistenceFilterMismatch(e){let n=Symbol();return this.onExistenceFilterMismatchCallbacks.set(n,e),()=>this.onExistenceFilterMismatchCallbacks.delete(n)}notifyOnExistenceFilterMismatch(e){this.onExistenceFilterMismatchCallbacks.forEach(n=>n(e))}},lu=null;function II(){return new TextEncoder}var xI=new zr([4294967295,4294967295],0);function cw(t){let e=II().encode(t),n=new Gv;return n.update(e),new Uint8Array(n.digest())}function hw(t){let e=new DataView(t.buffer),n=e.getUint32(0,!0),r=e.getUint32(4,!0),i=e.getUint32(8,!0),s=e.getUint32(12,!0);return[new zr([n,r],0),new zr([i,s],0)]}var Oo=class{constructor(e,n,r){if(this.bitmap=e,this.padding=n,this.hashCount=r,n<0||n>=8)throw new Br(`Invalid padding: ${n}`);if(r<0)throw new Br(`Invalid hash count: ${r}`);if(e.length>0&&this.hashCount===0)throw new Br(`Invalid hash count: ${r}`);if(e.length===0&&n!==0)throw new Br(`Invalid padding when bitmap length is 0: ${n}`);this.yt=8*e.length-n,this.It=zr.fromNumber(this.yt)}Tt(e,n,r){let i=e.add(n.multiply(zr.fromNumber(r)));return i.compare(xI)===1&&(i=new zr([i.getBits(0),i.getBits(1)],0)),i.modulo(this.It).toNumber()}Et(e){return(this.bitmap[Math.floor(e/8)]&1<<e%8)!=0}At(e){if(this.yt===0)return!1;let n=cw(e),[r,i]=hw(n);for(let s=0;s<this.hashCount;s++){let o=this.Tt(r,i,s);if(!this.Et(o))return!1}return!0}static create(e,n,r){let i=e%8==0?0:8-e%8,s=new Uint8Array(Math.ceil(e/8)),o=new Oo(s,i,n);return r.forEach(a=>o.insert(a)),o}insert(e){if(this.yt===0)return;let n=cw(e),[r,i]=hw(n);for(let s=0;s<this.hashCount;s++){let o=this.Tt(r,i,s);this.Rt(o)}}Rt(e){let n=Math.floor(e/8),r=e%8;this.bitmap[n]|=1<<r}},Br=class extends Error{constructor(){super(...arguments),this.name="BloomFilterError"}};var Xi=class{constructor(e,n,r,i,s){this.snapshotVersion=e,this.targetChanges=n,this.targetMismatches=r,this.documentUpdates=i,this.resolvedLimboDocuments=s}static createSynthesizedRemoteEventForCurrentChange(e,n,r){let i=new Map;return i.set(e,Hr.createSynthesizedTargetChangeForCurrentChange(e,n,r)),new Xi(R.min(),i,new oe(X),or(),j())}},Hr=class{constructor(e,n,r,i,s){this.resumeToken=e,this.current=n,this.addedDocuments=r,this.modifiedDocuments=i,this.removedDocuments=s}static createSynthesizedTargetChangeForCurrentChange(e,n,r){return new Hr(r,n,j(),j(),j())}};var bi=class{constructor(e,n,r,i){this.vt=e,this.removedTargetIds=n,this.key=r,this.Pt=i}},yu=class{constructor(e,n){this.targetId=e,this.bt=n}},Au=class{constructor(e,n,r=Ne.EMPTY_BYTE_STRING,i=null){this.state=e,this.targetIds=n,this.resumeToken=r,this.cause=i}},vu=class{constructor(){this.Vt=0,this.St=fw(),this.Dt=Ne.EMPTY_BYTE_STRING,this.Ct=!1,this.xt=!0}get current(){return this.Ct}get resumeToken(){return this.Dt}get Nt(){return this.Vt!==0}get kt(){return this.xt}Mt(e){e.approximateByteSize()>0&&(this.xt=!0,this.Dt=e)}Ot(){let e=j(),n=j(),r=j();return this.St.forEach((i,s)=>{switch(s){case 0:e=e.add(i);break;case 2:n=n.add(i);break;case 1:r=r.add(i);break;default:z()}}),new Hr(this.Dt,this.Ct,e,n,r)}$t(){this.xt=!1,this.St=fw()}Ft(e,n){this.xt=!0,this.St=this.St.insert(e,n)}Bt(e){this.xt=!0,this.St=this.St.remove(e)}Lt(){this.Vt+=1}qt(){this.Vt-=1}Ut(){this.xt=!0,this.Ct=!0}},cp=class{constructor(e){this.Kt=e,this.Gt=new Map,this.Qt=or(),this.jt=dw(),this.zt=new oe(X)}Wt(e){for(let n of e.vt)e.Pt&&e.Pt.isFoundDocument()?this.Ht(n,e.Pt):this.Jt(n,e.key,e.Pt);for(let n of e.removedTargetIds)this.Jt(n,e.key,e.Pt)}Yt(e){this.forEachTarget(e,n=>{let r=this.Xt(n);switch(e.state){case 0:this.Zt(n)&&r.Mt(e.resumeToken);break;case 1:r.qt(),r.Nt||r.$t(),r.Mt(e.resumeToken);break;case 2:r.qt(),r.Nt||this.removeTarget(n);break;case 3:this.Zt(n)&&(r.Ut(),r.Mt(e.resumeToken));break;case 4:this.Zt(n)&&(this.te(n),r.Mt(e.resumeToken));break;default:z()}})}forEachTarget(e,n){e.targetIds.length>0?e.targetIds.forEach(n):this.Gt.forEach((r,i)=>{this.Zt(i)&&n(i)})}ee(e){var n;let r=e.targetId,i=e.bt.count,s=this.ne(r);if(s){let o=s.target;if(rp(o))if(i===0){let a=new _(o.path);this.Jt(r,a,ke.newNoDocument(a,R.min()))}else Ee(i===1);else{let a=this.se(r);if(a!==i){let l=this.ie(e,a);if(l!==0){this.te(r);let u=l===2?"TargetPurposeExistenceFilterMismatchBloom":"TargetPurposeExistenceFilterMismatch";this.zt=this.zt.insert(r,u)}(n=_o.instance)===null||n===void 0||n.notifyOnExistenceFilterMismatch(function(u,c,h){var p,g,y,A,P,f;let d={localCacheCount:c,existenceFilterCount:h.count},m=h.unchangedNames;return m&&(d.bloomFilter={applied:u===0,hashCount:(p=m?.hashCount)!==null&&p!==void 0?p:0,bitmapLength:(A=(y=(g=m?.bits)===null||g===void 0?void 0:g.bitmap)===null||y===void 0?void 0:y.length)!==null&&A!==void 0?A:0,padding:(f=(P=m?.bits)===null||P===void 0?void 0:P.padding)!==null&&f!==void 0?f:0}),d}(l,a,e.bt))}}}}ie(e,n){let{unchangedNames:r,count:i}=e.bt;if(!r||!r.bits)return 1;let{bits:{bitmap:s="",padding:o=0},hashCount:a=0}=r,l,u;try{l=ir(s).toUint8Array()}catch(c){if(c instanceof mu)return zi("Decoding the base64 bloom filter in existence filter failed ("+c.message+"); ignoring the bloom filter and falling back to full re-query."),1;throw c}try{u=new Oo(l,o,a)}catch(c){return zi(c instanceof Br?"BloomFilter error: ":"Applying bloom filter failed: ",c),1}return u.yt===0?1:i!==n-this.re(e.targetId,u)?2:0}re(e,n){let r=this.Kt.getRemoteKeysForTarget(e),i=0;return r.forEach(s=>{let o=this.Kt.oe(),a=`projects/${o.projectId}/databases/${o.database}/documents/${s.path.canonicalString()}`;n.At(a)||(this.Jt(e,s,null),i++)}),i}ue(e){let n=new Map;this.Gt.forEach((s,o)=>{let a=this.ne(o);if(a){if(s.current&&rp(a.target)){let l=new _(a.target.path);this.Qt.get(l)!==null||this.ce(o,l)||this.Jt(o,l,ke.newNoDocument(l,e))}s.kt&&(n.set(o,s.Ot()),s.$t())}});let r=j();this.jt.forEach((s,o)=>{let a=!0;o.forEachWhile(l=>{let u=this.ne(l);return!u||u.purpose==="TargetPurposeLimboResolution"||(a=!1,!1)}),a&&(r=r.add(s))}),this.Qt.forEach((s,o)=>o.setReadTime(e));let i=new Xi(e,n,this.zt,this.Qt,r);return this.Qt=or(),this.jt=dw(),this.zt=new oe(X),i}Ht(e,n){if(!this.Zt(e))return;let r=this.ce(e,n.key)?2:0;this.Xt(e).Ft(n.key,r),this.Qt=this.Qt.insert(n.key,n),this.jt=this.jt.insert(n.key,this.ae(n.key).add(e))}Jt(e,n,r){if(!this.Zt(e))return;let i=this.Xt(e);this.ce(e,n)?i.Ft(n,1):i.Bt(n),this.jt=this.jt.insert(n,this.ae(n).delete(e)),r&&(this.Qt=this.Qt.insert(n,r))}removeTarget(e){this.Gt.delete(e)}se(e){let n=this.Xt(e).Ot();return this.Kt.getRemoteKeysForTarget(e).size+n.addedDocuments.size-n.removedDocuments.size}Lt(e){this.Xt(e).Lt()}Xt(e){let n=this.Gt.get(e);return n||(n=new vu,this.Gt.set(e,n)),n}ae(e){let n=this.jt.get(e);return n||(n=new De(X),this.jt=this.jt.insert(e,n)),n}Zt(e){let n=this.ne(e)!==null;return n||N("WatchChangeAggregator","Detected inactive target",e),n}ne(e){let n=this.Gt.get(e);return n&&n.Nt?null:this.Kt.he(e)}te(e){this.Gt.set(e,new vu),this.Kt.getRemoteKeysForTarget(e).forEach(n=>{this.Jt(e,n,null)})}ce(e,n){return this.Kt.getRemoteKeysForTarget(e).has(n)}};function dw(){return new oe(_.comparator)}function fw(){return new oe(_.comparator)}var TI=(()=>({asc:"ASCENDING",desc:"DESCENDING"}))(),CI=(()=>({"<":"LESS_THAN","<=":"LESS_THAN_OR_EQUAL",">":"GREATER_THAN",">=":"GREATER_THAN_OR_EQUAL","==":"EQUAL","!=":"NOT_EQUAL","array-contains":"ARRAY_CONTAINS",in:"IN","not-in":"NOT_IN","array-contains-any":"ARRAY_CONTAINS_ANY"}))(),kI=(()=>({and:"AND",or:"OR"}))(),hp=class{constructor(e,n){this.databaseId=e,this.useProto3Json=n}};function dp(t,e){return t.useProto3Json||Lu(e)?e:{value:e}}function DI(t,e){return t.useProto3Json?`${new Date(1e3*e.seconds).toISOString().replace(/\.\d*/,"").replace("Z","")}.${("000000000"+e.nanoseconds).slice(-9)}Z`:{seconds:""+e.seconds,nanos:e.nanoseconds}}function NI(t,e){return t.useProto3Json?e.toBase64():e.toUint8Array()}function Ri(t){return Ee(!!t),R.fromTimestamp(function(e){let n=rr(e);return new He(n.seconds,n.nanos)}(t))}function PI(t,e){return function(n){return new se(["projects",n.projectId,"databases",n.database])}(t).child("documents").child(e).canonicalString()}function qw(t){let e=se.fromString(t);return Ee(Qw(e)),e}function Of(t,e){let n=qw(e);if(n.get(1)!==t.databaseId.projectId)throw new O(x.INVALID_ARGUMENT,"Tried to deserialize key from different project: "+n.get(1)+" vs "+t.databaseId.projectId);if(n.get(3)!==t.databaseId.database)throw new O(x.INVALID_ARGUMENT,"Tried to deserialize key from different database: "+n.get(3)+" vs "+t.databaseId.database);return new _(Vw(n))}function fp(t,e){return PI(t.databaseId,e)}function _I(t){let e=qw(t);return e.length===4?se.emptyPath():Vw(e)}function pw(t){return new se(["projects",t.databaseId.projectId,"databases",t.databaseId.database]).canonicalString()}function Vw(t){return Ee(t.length>4&&t.get(4)==="documents"),t.popFirst(5)}function OI(t,e){let n;if("targetChange"in e){e.targetChange;let r=function(l){return l==="NO_CHANGE"?0:l==="ADD"?1:l==="REMOVE"?2:l==="CURRENT"?3:l==="RESET"?4:z()}(e.targetChange.targetChangeType||"NO_CHANGE"),i=e.targetChange.targetIds||[],s=function(l,u){return l.useProto3Json?(Ee(u===void 0||typeof u=="string"),Ne.fromBase64String(u||"")):(Ee(u===void 0||u instanceof Uint8Array),Ne.fromUint8Array(u||new Uint8Array))}(t,e.targetChange.resumeToken),o=e.targetChange.cause,a=o&&function(l){let u=l.code===void 0?x.UNKNOWN:Bw(l.code);return new O(u,l.message||"")}(o);n=new Au(r,i,s,a||null)}else if("documentChange"in e){e.documentChange;let r=e.documentChange;r.document,r.document.name,r.document.updateTime;let i=Of(t,r.document.name),s=Ri(r.document.updateTime),o=r.document.createTime?Ri(r.document.createTime):R.min(),a=new xt({mapValue:{fields:r.document.fields}}),l=ke.newFoundDocument(i,s,o,a),u=r.targetIds||[],c=r.removedTargetIds||[];n=new bi(u,c,l.key,l)}else if("documentDelete"in e){e.documentDelete;let r=e.documentDelete;r.document;let i=Of(t,r.document),s=r.readTime?Ri(r.readTime):R.min(),o=ke.newNoDocument(i,s),a=r.removedTargetIds||[];n=new bi([],a,o.key,o)}else if("documentRemove"in e){e.documentRemove;let r=e.documentRemove;r.document;let i=Of(t,r.document),s=r.removedTargetIds||[];n=new bi([],s,i,null)}else{if(!("filter"in e))return z();{e.filter;let r=e.filter;r.targetId;let{count:i=0,unchangedNames:s}=r,o=new up(i,s),a=r.targetId;n=new yu(a,o)}}return n}function LI(t,e){return{documents:[fp(t,e.path)]}}function MI(t,e){let n={structuredQuery:{}},r=e.path;e.collectionGroup!==null?(n.parent=fp(t,r),n.structuredQuery.from=[{collectionId:e.collectionGroup,allDescendants:!0}]):(n.parent=fp(t,r.popLast()),n.structuredQuery.from=[{collectionId:r.lastSegment()}]);let i=function(l){if(l.length!==0)return jw(Tt.create(l,"and"))}(e.filters);i&&(n.structuredQuery.where=i);let s=function(l){if(l.length!==0)return l.map(u=>function(c){return{field:_i(c.field),direction:zI(c.dir)}}(u))}(e.orderBy);s&&(n.structuredQuery.orderBy=s);let o=dp(t,e.limit);var a;return o!==null&&(n.structuredQuery.limit=o),e.startAt&&(n.structuredQuery.startAt={before:(a=e.startAt).inclusive,values:a.position}),e.endAt&&(n.structuredQuery.endAt=function(l){return{before:!l.inclusive,values:l.position}}(e.endAt)),n}function bI(t){let e=_I(t.parent),n=t.structuredQuery,r=n.from?n.from.length:0,i=null;if(r>0){Ee(r===1);let c=n.from[0];c.allDescendants?i=c.collectionId:e=e.child(c.collectionId)}let s=[];n.where&&(s=function(c){let h=Uw(c);return h instanceof Tt&&Cw(h)?h.getFilters():[h]}(n.where));let o=[];n.orderBy&&(o=n.orderBy.map(c=>function(h){return new qr(Oi(h.field),function(p){switch(p){case"ASCENDING":return"asc";case"DESCENDING":return"desc";default:return}}(h.direction))}(c)));let a=null;n.limit&&(a=function(c){let h;return h=typeof c=="object"?c.value:c,Lu(h)?null:h}(n.limit));let l=null;n.startAt&&(l=function(c){let h=!!c.before,p=c.values||[];return new Vi(p,h)}(n.startAt));let u=null;return n.endAt&&(u=function(c){let h=!c.before,p=c.values||[];return new Vi(p,h)}(n.endAt)),sI(e,i,o,s,a,"F",l,u)}function RI(t,e){let n=function(r){switch(r){case"TargetPurposeListen":return null;case"TargetPurposeExistenceFilterMismatch":return"existence-filter-mismatch";case"TargetPurposeExistenceFilterMismatchBloom":return"existence-filter-mismatch-bloom";case"TargetPurposeLimboResolution":return"limbo-document";default:return z()}}(e.purpose);return n==null?null:{"goog-listen-tags":n}}function Uw(t){return t.unaryFilter!==void 0?function(e){switch(e.unaryFilter.op){case"IS_NAN":let n=Oi(e.unaryFilter.field);return pe.create(n,"==",{doubleValue:NaN});case"IS_NULL":let r=Oi(e.unaryFilter.field);return pe.create(r,"==",{nullValue:"NULL_VALUE"});case"IS_NOT_NAN":let i=Oi(e.unaryFilter.field);return pe.create(i,"!=",{doubleValue:NaN});case"IS_NOT_NULL":let s=Oi(e.unaryFilter.field);return pe.create(s,"!=",{nullValue:"NULL_VALUE"});default:return z()}}(t):t.fieldFilter!==void 0?function(e){return pe.create(Oi(e.fieldFilter.field),function(n){switch(n){case"EQUAL":return"==";case"NOT_EQUAL":return"!=";case"GREATER_THAN":return">";case"GREATER_THAN_OR_EQUAL":return">=";case"LESS_THAN":return"<";case"LESS_THAN_OR_EQUAL":return"<=";case"ARRAY_CONTAINS":return"array-contains";case"IN":return"in";case"NOT_IN":return"not-in";case"ARRAY_CONTAINS_ANY":return"array-contains-any";default:return z()}}(e.fieldFilter.op),e.fieldFilter.value)}(t):t.compositeFilter!==void 0?function(e){return Tt.create(e.compositeFilter.filters.map(n=>Uw(n)),function(n){switch(n){case"AND":return"and";case"OR":return"or";default:return z()}}(e.compositeFilter.op))}(t):z()}function zI(t){return TI[t]}function FI(t){return CI[t]}function BI(t){return kI[t]}function _i(t){return{fieldPath:t.canonicalString()}}function Oi(t){return Qe.fromServerFormat(t.fieldPath)}function jw(t){return t instanceof pe?function(e){if(e.op==="=="){if(tw(e.value))return{unaryFilter:{field:_i(e.field),op:"IS_NAN"}};if(ew(e.value))return{unaryFilter:{field:_i(e.field),op:"IS_NULL"}}}else if(e.op==="!="){if(tw(e.value))return{unaryFilter:{field:_i(e.field),op:"IS_NOT_NAN"}};if(ew(e.value))return{unaryFilter:{field:_i(e.field),op:"IS_NOT_NULL"}}}return{fieldFilter:{field:_i(e.field),op:FI(e.op),value:e.value}}}(t):t instanceof Tt?function(e){let n=e.getFilters().map(r=>jw(r));return n.length===1?n[0]:{compositeFilter:{op:BI(e.op),filters:n}}}(t):z()}function Qw(t){return t.length>=4&&t.get(0)==="projects"&&t.get(2)==="databases"}var $t=class{constructor(e,n,r,i,s=R.min(),o=R.min(),a=Ne.EMPTY_BYTE_STRING,l=null){this.target=e,this.targetId=n,this.purpose=r,this.sequenceNumber=i,this.snapshotVersion=s,this.lastLimboFreeSnapshotVersion=o,this.resumeToken=a,this.expectedCount=l}withSequenceNumber(e){return new $t(this.target,this.targetId,this.purpose,e,this.snapshotVersion,this.lastLimboFreeSnapshotVersion,this.resumeToken,this.expectedCount)}withResumeToken(e,n){return new $t(this.target,this.targetId,this.purpose,this.sequenceNumber,n,this.lastLimboFreeSnapshotVersion,e,null)}withExpectedCount(e){return new $t(this.target,this.targetId,this.purpose,this.sequenceNumber,this.snapshotVersion,this.lastLimboFreeSnapshotVersion,this.resumeToken,e)}withLastLimboFreeSnapshotVersion(e){return new $t(this.target,this.targetId,this.purpose,this.sequenceNumber,this.snapshotVersion,e,this.resumeToken,this.expectedCount)}};var pp=class{constructor(e){this.le=e}};function qI(t){let e=bI({parent:t.parent,structuredQuery:t.structuredQuery});return t.limitType==="LAST"?ip(e,e.limit,"L"):e}var wu=class{constructor(){}_e(e,n){this.we(e,n),n.me()}we(e,n){if("nullValue"in e)this.ge(n,5);else if("booleanValue"in e)this.ge(n,10),n.ye(e.booleanValue?1:0);else if("integerValue"in e)this.ge(n,15),n.ye(de(e.integerValue));else if("doubleValue"in e){let r=de(e.doubleValue);isNaN(r)?this.ge(n,13):(this.ge(n,15),fu(r)?n.ye(0):n.ye(r))}else if("timestampValue"in e){let r=e.timestampValue;this.ge(n,20),typeof r=="string"?n.pe(r):(n.pe(`${r.seconds||""}`),n.ye(r.nanos||0))}else if("stringValue"in e)this.Ie(e.stringValue,n),this.Te(n);else if("bytesValue"in e)this.ge(n,30),n.Ee(ir(e.bytesValue)),this.Te(n);else if("referenceValue"in e)this.Ae(e.referenceValue,n);else if("geoPointValue"in e){let r=e.geoPointValue;this.ge(n,45),n.ye(r.latitude||0),n.ye(r.longitude||0)}else"mapValue"in e?xw(e)?this.ge(n,Number.MAX_SAFE_INTEGER):(this.Re(e.mapValue,n),this.Te(n)):"arrayValue"in e?(this.ve(e.arrayValue,n),this.Te(n)):z()}Ie(e,n){this.ge(n,25),this.Pe(e,n)}Pe(e,n){n.pe(e)}Re(e,n){let r=e.fields||{};this.ge(n,55);for(let i of Object.keys(r))this.Ie(i,n),this.we(r[i],n)}ve(e,n){let r=e.values||[];this.ge(n,50);for(let i of r)this.we(i,n)}Ae(e,n){this.ge(n,37),_.fromName(e).path.forEach(r=>{this.ge(n,60),this.Pe(r,n)})}ge(e,n){e.ye(n)}Te(e){e.ye(2)}};wu.be=new wu;var mp=class{constructor(){this.sn=new gp}addToCollectionParentIndex(e,n){return this.sn.add(n),E.resolve()}getCollectionParents(e,n){return E.resolve(this.sn.getEntries(n))}addFieldIndex(e,n){return E.resolve()}deleteFieldIndex(e,n){return E.resolve()}getDocumentsMatchingTarget(e,n){return E.resolve(null)}getIndexType(e,n){return E.resolve(0)}getFieldIndexes(e,n){return E.resolve([])}getNextCollectionGroupToUpdate(e){return E.resolve(null)}getMinOffset(e,n){return E.resolve(en.min())}getMinOffsetFromCollectionGroup(e,n){return E.resolve(en.min())}updateCollectionGroup(e,n,r){return E.resolve()}updateIndexEntries(e,n){return E.resolve()}},gp=class{constructor(){this.index={}}add(e){let n=e.lastSegment(),r=e.popLast(),i=this.index[n]||new De(se.comparator),s=!i.has(r);return this.index[n]=i.add(r),s}has(e){let n=e.lastSegment(),r=e.popLast(),i=this.index[n];return i&&i.has(r)}getEntries(e){return(this.index[e]||new De(se.comparator)).toArray()}};var CC=new Uint8Array(0);var rt=class{constructor(e,n,r){this.cacheSizeCollectionThreshold=e,this.percentileToCollect=n,this.maximumSequenceNumbersToCollect=r}static withCacheSize(e){return new rt(e,rt.DEFAULT_COLLECTION_PERCENTILE,rt.DEFAULT_MAX_SEQUENCE_NUMBERS_TO_COLLECT)}};rt.DEFAULT_COLLECTION_PERCENTILE=10,rt.DEFAULT_MAX_SEQUENCE_NUMBERS_TO_COLLECT=1e3,rt.DEFAULT=new rt(41943040,rt.DEFAULT_COLLECTION_PERCENTILE,rt.DEFAULT_MAX_SEQUENCE_NUMBERS_TO_COLLECT),rt.DISABLED=new rt(-1,0,0);var ar=class{constructor(e){this.xn=e}next(){return this.xn+=2,this.xn}static Nn(){return new ar(0)}static kn(){return new ar(-1)}};var yp=class{constructor(){this.changes=new sr(e=>e.toString(),(e,n)=>e.isEqual(n)),this.changesApplied=!1}addEntry(e){this.assertNotApplied(),this.changes.set(e.key,e)}removeEntry(e,n){this.assertNotApplied(),this.changes.set(e,ke.newInvalidDocument(e).setReadTime(n))}getEntry(e,n){this.assertNotApplied();let r=this.changes.get(n);return r!==void 0?E.resolve(r):this.getFromCache(e,n)}getEntries(e,n){return this.getAllFromCache(e,n)}apply(e){return this.assertNotApplied(),this.changesApplied=!0,this.applyChanges(e)}assertNotApplied(){}};var Ap=class{constructor(e,n){this.overlayedDocument=e,this.mutatedFields=n}};var vp=class{constructor(e,n,r,i){this.remoteDocumentCache=e,this.mutationQueue=n,this.documentOverlayCache=r,this.indexManager=i}getDocument(e,n){let r=null;return this.documentOverlayCache.getOverlay(e,n).next(i=>(r=i,this.remoteDocumentCache.getEntry(e,n))).next(i=>(r!==null&&Io(r.mutation,i,Yt.empty(),He.now()),i))}getDocuments(e,n){return this.remoteDocumentCache.getEntries(e,n).next(r=>this.getLocalViewOfDocuments(e,r,j()).next(()=>r))}getLocalViewOfDocuments(e,n,r=j()){let i=Fr();return this.populateOverlays(e,i,n).next(()=>this.computeViews(e,n,i,r).next(s=>{let o=wo();return s.forEach((a,l)=>{o=o.insert(a,l.overlayedDocument)}),o}))}getOverlayedDocuments(e,n){let r=Fr();return this.populateOverlays(e,r,n).next(()=>this.computeViews(e,n,r,j()))}populateOverlays(e,n,r){let i=[];return r.forEach(s=>{n.has(s)||i.push(s)}),this.documentOverlayCache.getOverlays(e,i).next(s=>{s.forEach((o,a)=>{n.set(o,a)})})}computeViews(e,n,r,i){let s=or(),o=So(),a=So();return n.forEach((l,u)=>{let c=r.get(u.key);i.has(u.key)&&(c===void 0||c.mutation instanceof Ki)?s=s.insert(u.key,u):c!==void 0?(o.set(u.key,c.mutation.getFieldMask()),Io(c.mutation,u,c.mutation.getFieldMask(),He.now())):o.set(u.key,Yt.empty())}),this.recalculateAndSaveOverlays(e,s).next(l=>(l.forEach((u,c)=>o.set(u,c)),n.forEach((u,c)=>{var h;return a.set(u,new Ap(c,(h=o.get(u))!==null&&h!==void 0?h:null))}),a))}recalculateAndSaveOverlays(e,n){let r=So(),i=new oe((o,a)=>o-a),s=j();return this.mutationQueue.getAllMutationBatchesAffectingDocumentKeys(e,n).next(o=>{for(let a of o)a.keys().forEach(l=>{let u=n.get(l);if(u===null)return;let c=r.get(l)||Yt.empty();c=a.applyToLocalView(u,c),r.set(l,c);let h=(i.get(a.batchId)||j()).add(l);i=i.insert(a.batchId,h)})}).next(()=>{let o=[],a=i.getReverseIterator();for(;a.hasNext();){let l=a.getNext(),u=l.key,c=l.value,h=Lw();c.forEach(p=>{if(!s.has(p)){let g=zw(n.get(p),r.get(p));g!==null&&h.set(p,g),s=s.add(p)}}),o.push(this.documentOverlayCache.saveOverlays(e,u,h))}return E.waitFor(o)}).next(()=>r)}recalculateAndSaveOverlaysForDocumentKeys(e,n){return this.remoteDocumentCache.getEntries(e,n).next(r=>this.recalculateAndSaveOverlays(e,r))}getDocumentsMatchingQuery(e,n,r){return function(i){return _.isDocumentKey(i.path)&&i.collectionGroup===null&&i.filters.length===0}(n)?this.getDocumentsMatchingDocumentQuery(e,n.path):lI(n)?this.getDocumentsMatchingCollectionGroupQuery(e,n,r):this.getDocumentsMatchingCollectionQuery(e,n,r)}getNextDocuments(e,n,r,i){return this.remoteDocumentCache.getAllFromCollectionGroup(e,n,r,i).next(s=>{let o=i-s.size>0?this.documentOverlayCache.getOverlaysForCollectionGroup(e,n,r.largestBatchId,i-s.size):E.resolve(Fr()),a=-1,l=s;return o.next(u=>E.forEach(u,(c,h)=>(a<h.largestBatchId&&(a=h.largestBatchId),s.get(c)?E.resolve():this.remoteDocumentCache.getEntry(e,c).next(p=>{l=l.insert(c,p)}))).next(()=>this.populateOverlays(e,u,s)).next(()=>this.computeViews(e,l,u,j())).next(c=>({batchId:a,changes:dI(c)})))})}getDocumentsMatchingDocumentQuery(e,n){return this.getDocument(e,new _(n)).next(r=>{let i=wo();return r.isFoundDocument()&&(i=i.insert(r.key,r)),i})}getDocumentsMatchingCollectionGroupQuery(e,n,r){let i=n.collectionGroup,s=wo();return this.indexManager.getCollectionParents(e,i).next(o=>E.forEach(o,a=>{let l=function(u,c){return new Ui(c,null,u.explicitOrderBy.slice(),u.filters.slice(),u.limit,u.limitType,u.startAt,u.endAt)}(n,a.child(i));return this.getDocumentsMatchingCollectionQuery(e,l,r).next(u=>{u.forEach((c,h)=>{s=s.insert(c,h)})})}).next(()=>s))}getDocumentsMatchingCollectionQuery(e,n,r){let i;return this.documentOverlayCache.getOverlaysForCollection(e,n.path,r.largestBatchId).next(s=>(i=s,this.remoteDocumentCache.getDocumentsMatchingQuery(e,n,r,i))).next(s=>{i.forEach((a,l)=>{let u=l.getKey();s.get(u)===null&&(s=s.insert(u,ke.newInvalidDocument(u)))});let o=wo();return s.forEach((a,l)=>{let u=i.get(a);u!==void 0&&Io(u.mutation,l,Yt.empty(),He.now()),Ru(n,l)&&(o=o.insert(a,l))}),o})}};var wp=class{constructor(e){this.serializer=e,this.us=new Map,this.cs=new Map}getBundleMetadata(e,n){return E.resolve(this.us.get(n))}saveBundleMetadata(e,n){var r;return this.us.set(n.id,{id:(r=n).id,version:r.version,createTime:Ri(r.createTime)}),E.resolve()}getNamedQuery(e,n){return E.resolve(this.cs.get(n))}saveNamedQuery(e,n){return this.cs.set(n.name,function(r){return{name:r.name,query:qI(r.bundledQuery),readTime:Ri(r.readTime)}}(n)),E.resolve()}};var Ep=class{constructor(){this.overlays=new oe(_.comparator),this.hs=new Map}getOverlay(e,n){return E.resolve(this.overlays.get(n))}getOverlays(e,n){let r=Fr();return E.forEach(n,i=>this.getOverlay(e,i).next(s=>{s!==null&&r.set(i,s)})).next(()=>r)}saveOverlays(e,n,r){return r.forEach((i,s)=>{this.de(e,n,s)}),E.resolve()}removeOverlaysForBatchId(e,n,r){let i=this.hs.get(r);return i!==void 0&&(i.forEach(s=>this.overlays=this.overlays.remove(s)),this.hs.delete(r)),E.resolve()}getOverlaysForCollection(e,n,r){let i=Fr(),s=n.length+1,o=new _(n.child("")),a=this.overlays.getIteratorFrom(o);for(;a.hasNext();){let l=a.getNext().value,u=l.getKey();if(!n.isPrefixOf(u.path))break;u.path.length===s&&l.largestBatchId>r&&i.set(l.getKey(),l)}return E.resolve(i)}getOverlaysForCollectionGroup(e,n,r,i){let s=new oe((u,c)=>u-c),o=this.overlays.getIterator();for(;o.hasNext();){let u=o.getNext().value;if(u.getKey().getCollectionGroup()===n&&u.largestBatchId>r){let c=s.get(u.largestBatchId);c===null&&(c=Fr(),s=s.insert(u.largestBatchId,c)),c.set(u.getKey(),u)}}let a=Fr(),l=s.getIterator();for(;l.hasNext()&&(l.getNext().value.forEach((u,c)=>a.set(u,c)),!(a.size()>=i)););return E.resolve(a)}de(e,n,r){let i=this.overlays.get(r.key);if(i!==null){let o=this.hs.get(i.largestBatchId).delete(r.key);this.hs.set(i.largestBatchId,o)}this.overlays=this.overlays.insert(r.key,new lp(n,r));let s=this.hs.get(n);s===void 0&&(s=j(),this.hs.set(n,s)),this.hs.set(n,s.add(r.key))}};var Lo=class{constructor(){this.ls=new De(ye.fs),this.ds=new De(ye._s)}isEmpty(){return this.ls.isEmpty()}addReference(e,n){let r=new ye(e,n);this.ls=this.ls.add(r),this.ds=this.ds.add(r)}ws(e,n){e.forEach(r=>this.addReference(r,n))}removeReference(e,n){this.gs(new ye(e,n))}ys(e,n){e.forEach(r=>this.removeReference(r,n))}ps(e){let n=new _(new se([])),r=new ye(n,e),i=new ye(n,e+1),s=[];return this.ds.forEachInRange([r,i],o=>{this.gs(o),s.push(o.key)}),s}Is(){this.ls.forEach(e=>this.gs(e))}gs(e){this.ls=this.ls.delete(e),this.ds=this.ds.delete(e)}Ts(e){let n=new _(new se([])),r=new ye(n,e),i=new ye(n,e+1),s=j();return this.ds.forEachInRange([r,i],o=>{s=s.add(o.key)}),s}containsKey(e){let n=new ye(e,0),r=this.ls.firstAfterOrEqual(n);return r!==null&&e.isEqual(r.key)}},ye=class{constructor(e,n){this.key=e,this.Es=n}static fs(e,n){return _.comparator(e.key,n.key)||X(e.Es,n.Es)}static _s(e,n){return X(e.Es,n.Es)||_.comparator(e.key,n.key)}};var Sp=class{constructor(e,n){this.indexManager=e,this.referenceDelegate=n,this.mutationQueue=[],this.As=1,this.Rs=new De(ye.fs)}checkEmpty(e){return E.resolve(this.mutationQueue.length===0)}addMutationBatch(e,n,r,i){let s=this.As;this.As++,this.mutationQueue.length>0&&this.mutationQueue[this.mutationQueue.length-1];let o=new ap(s,n,r,i);this.mutationQueue.push(o);for(let a of i)this.Rs=this.Rs.add(new ye(a.key,s)),this.indexManager.addToCollectionParentIndex(e,a.key.path.popLast());return E.resolve(o)}lookupMutationBatch(e,n){return E.resolve(this.vs(n))}getNextMutationBatchAfterBatchId(e,n){let r=n+1,i=this.Ps(r),s=i<0?0:i;return E.resolve(this.mutationQueue.length>s?this.mutationQueue[s]:null)}getHighestUnacknowledgedBatchId(){return E.resolve(this.mutationQueue.length===0?-1:this.As-1)}getAllMutationBatches(e){return E.resolve(this.mutationQueue.slice())}getAllMutationBatchesAffectingDocumentKey(e,n){let r=new ye(n,0),i=new ye(n,Number.POSITIVE_INFINITY),s=[];return this.Rs.forEachInRange([r,i],o=>{let a=this.vs(o.Es);s.push(a)}),E.resolve(s)}getAllMutationBatchesAffectingDocumentKeys(e,n){let r=new De(X);return n.forEach(i=>{let s=new ye(i,0),o=new ye(i,Number.POSITIVE_INFINITY);this.Rs.forEachInRange([s,o],a=>{r=r.add(a.Es)})}),E.resolve(this.bs(r))}getAllMutationBatchesAffectingQuery(e,n){let r=n.path,i=r.length+1,s=r;_.isDocumentKey(s)||(s=s.child(""));let o=new ye(new _(s),0),a=new De(X);return this.Rs.forEachWhile(l=>{let u=l.key.path;return!!r.isPrefixOf(u)&&(u.length===i&&(a=a.add(l.Es)),!0)},o),E.resolve(this.bs(a))}bs(e){let n=[];return e.forEach(r=>{let i=this.vs(r);i!==null&&n.push(i)}),n}removeMutationBatch(e,n){Ee(this.Vs(n.batchId,"removed")===0),this.mutationQueue.shift();let r=this.Rs;return E.forEach(n.mutations,i=>{let s=new ye(i.key,n.batchId);return r=r.delete(s),this.referenceDelegate.markPotentiallyOrphaned(e,i.key)}).next(()=>{this.Rs=r})}Dn(e){}containsKey(e,n){let r=new ye(n,0),i=this.Rs.firstAfterOrEqual(r);return E.resolve(n.isEqual(i&&i.key))}performConsistencyCheck(e){return this.mutationQueue.length,E.resolve()}Vs(e,n){return this.Ps(e)}Ps(e){return this.mutationQueue.length===0?0:e-this.mutationQueue[0].batchId}vs(e){let n=this.Ps(e);return n<0||n>=this.mutationQueue.length?null:this.mutationQueue[n]}};var Ip=class{constructor(e){this.Ss=e,this.docs=new oe(_.comparator),this.size=0}setIndexManager(e){this.indexManager=e}addEntry(e,n){let r=n.key,i=this.docs.get(r),s=i?i.size:0,o=this.Ss(n);return this.docs=this.docs.insert(r,{document:n.mutableCopy(),size:o}),this.size+=o-s,this.indexManager.addToCollectionParentIndex(e,r.path.popLast())}removeEntry(e){let n=this.docs.get(e);n&&(this.docs=this.docs.remove(e),this.size-=n.size)}getEntry(e,n){let r=this.docs.get(n);return E.resolve(r?r.document.mutableCopy():ke.newInvalidDocument(n))}getEntries(e,n){let r=or();return n.forEach(i=>{let s=this.docs.get(i);r=r.insert(i,s?s.document.mutableCopy():ke.newInvalidDocument(i))}),E.resolve(r)}getDocumentsMatchingQuery(e,n,r,i){let s=or(),o=n.path,a=new _(o.child("")),l=this.docs.getIteratorFrom(a);for(;l.hasNext();){let{key:u,value:{document:c}}=l.getNext();if(!o.isPrefixOf(u.path))break;u.path.length>o.length+1||J6(G6(c),r)<=0||(i.has(c.key)||Ru(n,c))&&(s=s.insert(c.key,c.mutableCopy()))}return E.resolve(s)}getAllFromCollectionGroup(e,n,r,i){z()}Ds(e,n){return E.forEach(this.docs,r=>n(r))}newChangeBuffer(e){return new xp(this)}getSize(e){return E.resolve(this.size)}},xp=class extends yp{constructor(e){super(),this.rs=e}applyChanges(e){let n=[];return this.changes.forEach((r,i)=>{i.isValidDocument()?n.push(this.rs.addEntry(e,i)):this.rs.removeEntry(r)}),E.waitFor(n)}getFromCache(e,n){return this.rs.getEntry(e,n)}getAllFromCache(e,n){return this.rs.getEntries(e,n)}};var Tp=class{constructor(e){this.persistence=e,this.Cs=new sr(n=>cm(n),hm),this.lastRemoteSnapshotVersion=R.min(),this.highestTargetId=0,this.xs=0,this.Ns=new Lo,this.targetCount=0,this.ks=ar.Nn()}forEachTarget(e,n){return this.Cs.forEach((r,i)=>n(i)),E.resolve()}getLastRemoteSnapshotVersion(e){return E.resolve(this.lastRemoteSnapshotVersion)}getHighestSequenceNumber(e){return E.resolve(this.xs)}allocateTargetId(e){return this.highestTargetId=this.ks.next(),E.resolve(this.highestTargetId)}setTargetsMetadata(e,n,r){return r&&(this.lastRemoteSnapshotVersion=r),n>this.xs&&(this.xs=n),E.resolve()}$n(e){this.Cs.set(e.target,e);let n=e.targetId;n>this.highestTargetId&&(this.ks=new ar(n),this.highestTargetId=n),e.sequenceNumber>this.xs&&(this.xs=e.sequenceNumber)}addTargetData(e,n){return this.$n(n),this.targetCount+=1,E.resolve()}updateTargetData(e,n){return this.$n(n),E.resolve()}removeTargetData(e,n){return this.Cs.delete(n.target),this.Ns.ps(n.targetId),this.targetCount-=1,E.resolve()}removeTargets(e,n,r){let i=0,s=[];return this.Cs.forEach((o,a)=>{a.sequenceNumber<=n&&r.get(a.targetId)===null&&(this.Cs.delete(o),s.push(this.removeMatchingKeysForTargetId(e,a.targetId)),i++)}),E.waitFor(s).next(()=>i)}getTargetCount(e){return E.resolve(this.targetCount)}getTargetData(e,n){let r=this.Cs.get(n)||null;return E.resolve(r)}addMatchingKeys(e,n,r){return this.Ns.ws(n,r),E.resolve()}removeMatchingKeys(e,n,r){this.Ns.ys(n,r);let i=this.persistence.referenceDelegate,s=[];return i&&n.forEach(o=>{s.push(i.markPotentiallyOrphaned(e,o))}),E.waitFor(s)}removeMatchingKeysForTargetId(e,n){return this.Ns.ps(n),E.resolve()}getMatchingKeysForTargetId(e,n){let r=this.Ns.Ts(n);return E.resolve(r)}containsKey(e,n){return E.resolve(this.Ns.containsKey(n))}};var Cp=class{constructor(e,n){this.Ms={},this.overlays={},this.Os=new xo(0),this.$s=!1,this.$s=!0,this.referenceDelegate=e(this),this.Fs=new Tp(this),this.indexManager=new mp,this.remoteDocumentCache=function(r){return new Ip(r)}(r=>this.referenceDelegate.Bs(r)),this.serializer=new pp(n),this.Ls=new wp(this.serializer)}start(){return Promise.resolve()}shutdown(){return this.$s=!1,Promise.resolve()}get started(){return this.$s}setDatabaseDeletedListener(){}setNetworkEnabled(){}getIndexManager(e){return this.indexManager}getDocumentOverlayCache(e){let n=this.overlays[e.toKey()];return n||(n=new Ep,this.overlays[e.toKey()]=n),n}getMutationQueue(e,n){let r=this.Ms[e.toKey()];return r||(r=new Sp(n,this.referenceDelegate),this.Ms[e.toKey()]=r),r}getTargetCache(){return this.Fs}getRemoteDocumentCache(){return this.remoteDocumentCache}getBundleCache(){return this.Ls}runTransaction(e,n,r){N("MemoryPersistence","Starting transaction:",e);let i=new kp(this.Os.next());return this.referenceDelegate.qs(),r(i).next(s=>this.referenceDelegate.Us(i).next(()=>s)).toPromise().then(s=>(i.raiseOnCommittedEvent(),s))}Ks(e,n){return E.or(Object.values(this.Ms).map(r=>()=>r.containsKey(e,n)))}},kp=class extends Qf{constructor(e){super(),this.currentSequenceNumber=e}},Mo=class{constructor(e){this.persistence=e,this.Gs=new Lo,this.Qs=null}static js(e){return new Mo(e)}get zs(){if(this.Qs)return this.Qs;throw z()}addReference(e,n,r){return this.Gs.addReference(r,n),this.zs.delete(r.toString()),E.resolve()}removeReference(e,n,r){return this.Gs.removeReference(r,n),this.zs.add(r.toString()),E.resolve()}markPotentiallyOrphaned(e,n){return this.zs.add(n.toString()),E.resolve()}removeTarget(e,n){this.Gs.ps(n.targetId).forEach(i=>this.zs.add(i.toString()));let r=this.persistence.getTargetCache();return r.getMatchingKeysForTargetId(e,n.targetId).next(i=>{i.forEach(s=>this.zs.add(s.toString()))}).next(()=>r.removeTargetData(e,n))}qs(){this.Qs=new Set}Us(e){let n=this.persistence.getRemoteDocumentCache().newChangeBuffer();return E.forEach(this.zs,r=>{let i=_.fromPath(r);return this.Ws(e,i).next(s=>{s||n.removeEntry(i,R.min())})}).next(()=>(this.Qs=null,n.apply(e)))}updateLimboDocument(e,n){return this.Ws(e,n).next(r=>{r?this.zs.delete(n.toString()):this.zs.add(n.toString())})}Bs(e){return 0}Ws(e,n){return E.or([()=>E.resolve(this.Gs.containsKey(n)),()=>this.persistence.getTargetCache().containsKey(e,n),()=>this.persistence.Ks(e,n)])}};var bo=class{constructor(e,n,r,i){this.targetId=e,this.fromCache=n,this.$i=r,this.Fi=i}static Bi(e,n){let r=j(),i=j();for(let s of n.docChanges)switch(s.type){case 0:r=r.add(s.doc.key);break;case 1:i=i.add(s.doc.key)}return new bo(e,n.fromCache,r,i)}};var Dp=class{constructor(){this.Li=!1}initialize(e,n){this.qi=e,this.indexManager=n,this.Li=!0}getDocumentsMatchingQuery(e,n,r,i){return this.Ui(e,n).next(s=>s||this.Ki(e,n,i,r)).next(s=>s||this.Gi(e,n))}Ui(e,n){if(sw(n))return E.resolve(null);let r=xn(n);return this.indexManager.getIndexType(e,r).next(i=>i===0?null:(n.limit!==null&&i===1&&(n=ip(n,null,"F"),r=xn(n)),this.indexManager.getDocumentsMatchingTarget(e,r).next(s=>{let o=j(...s);return this.qi.getDocuments(e,o).next(a=>this.indexManager.getMinOffset(e,r).next(l=>{let u=this.Qi(n,a);return this.ji(n,u,o,l.readTime)?this.Ui(e,ip(n,null,"F")):this.zi(e,u,n,l)}))})))}Ki(e,n,r,i){return sw(n)||i.isEqual(R.min())?this.Gi(e,n):this.qi.getDocuments(e,r).next(s=>{let o=this.Qi(n,s);return this.ji(n,o,r,i)?this.Gi(e,n):(Zv()<=H.DEBUG&&N("QueryEngine","Re-using previous result from %s to execute query: %s",i.toString(),sp(n)),this.zi(e,o,n,W6(i,-1)))})}Qi(e,n){let r=new De(_w(e));return n.forEach((i,s)=>{Ru(e,s)&&(r=r.add(s))}),r}ji(e,n,r,i){if(e.limit===null)return!1;if(r.size!==n.size)return!0;let s=e.limitType==="F"?n.last():n.first();return!!s&&(s.hasPendingWrites||s.version.compareTo(i)>0)}Gi(e,n){return Zv()<=H.DEBUG&&N("QueryEngine","Using full collection scan to execute query:",sp(n)),this.qi.getDocumentsMatchingQuery(e,n,en.min())}zi(e,n,r,i){return this.qi.getDocumentsMatchingQuery(e,r,i).next(s=>(n.forEach(o=>{s=s.insert(o.key,o)}),s))}};var Np=class{constructor(e,n,r,i){this.persistence=e,this.Wi=n,this.serializer=i,this.Hi=new oe(X),this.Ji=new sr(s=>cm(s),hm),this.Yi=new Map,this.Xi=e.getRemoteDocumentCache(),this.Fs=e.getTargetCache(),this.Ls=e.getBundleCache(),this.Zi(r)}Zi(e){this.documentOverlayCache=this.persistence.getDocumentOverlayCache(e),this.indexManager=this.persistence.getIndexManager(e),this.mutationQueue=this.persistence.getMutationQueue(e,this.indexManager),this.localDocuments=new vp(this.Xi,this.mutationQueue,this.documentOverlayCache,this.indexManager),this.Xi.setIndexManager(this.indexManager),this.Wi.initialize(this.localDocuments,this.indexManager)}collectGarbage(e){return this.persistence.runTransaction("Collect garbage","readwrite-primary",n=>e.collect(n,this.Hi))}};function VI(t,e,n,r){return new Np(t,e,n,r)}async function Hw(t,e){let n=Q(t);return await n.persistence.runTransaction("Handle user change","readonly",r=>{let i;return n.mutationQueue.getAllMutationBatches(r).next(s=>(i=s,n.Zi(e),n.mutationQueue.getAllMutationBatches(r))).next(s=>{let o=[],a=[],l=j();for(let u of i){o.push(u.batchId);for(let c of u.mutations)l=l.add(c.key)}for(let u of s){a.push(u.batchId);for(let c of u.mutations)l=l.add(c.key)}return n.localDocuments.getDocuments(r,l).next(u=>({tr:u,removedBatchIds:o,addedBatchIds:a}))})})}function Kw(t){let e=Q(t);return e.persistence.runTransaction("Get last remote snapshot version","readonly",n=>e.Fs.getLastRemoteSnapshotVersion(n))}function UI(t,e){let n=Q(t),r=e.snapshotVersion,i=n.Hi;return n.persistence.runTransaction("Apply remote event","readwrite-primary",s=>{let o=n.Xi.newChangeBuffer({trackRemovals:!0});i=n.Hi;let a=[];e.targetChanges.forEach((c,h)=>{let p=i.get(h);if(!p)return;a.push(n.Fs.removeMatchingKeys(s,c.removedDocuments,h).next(()=>n.Fs.addMatchingKeys(s,c.addedDocuments,h)));let g=p.withSequenceNumber(s.currentSequenceNumber);e.targetMismatches.get(h)!==null?g=g.withResumeToken(Ne.EMPTY_BYTE_STRING,R.min()).withLastLimboFreeSnapshotVersion(R.min()):c.resumeToken.approximateByteSize()>0&&(g=g.withResumeToken(c.resumeToken,r)),i=i.insert(h,g),function(y,A,P){return y.resumeToken.approximateByteSize()===0||A.snapshotVersion.toMicroseconds()-y.snapshotVersion.toMicroseconds()>=3e8?!0:P.addedDocuments.size+P.modifiedDocuments.size+P.removedDocuments.size>0}(p,g,c)&&a.push(n.Fs.updateTargetData(s,g))});let l=or(),u=j();if(e.documentUpdates.forEach(c=>{e.resolvedLimboDocuments.has(c)&&a.push(n.persistence.referenceDelegate.updateLimboDocument(s,c))}),a.push(jI(s,o,e.documentUpdates).next(c=>{l=c.er,u=c.nr})),!r.isEqual(R.min())){let c=n.Fs.getLastRemoteSnapshotVersion(s).next(h=>n.Fs.setTargetsMetadata(s,s.currentSequenceNumber,r));a.push(c)}return E.waitFor(a).next(()=>o.apply(s)).next(()=>n.localDocuments.getLocalViewOfDocuments(s,l,u)).next(()=>l)}).then(s=>(n.Hi=i,s))}function jI(t,e,n){let r=j(),i=j();return n.forEach(s=>r=r.add(s)),e.getEntries(t,r).next(s=>{let o=or();return n.forEach((a,l)=>{let u=s.get(a);l.isFoundDocument()!==u.isFoundDocument()&&(i=i.add(a)),l.isNoDocument()&&l.version.isEqual(R.min())?(e.removeEntry(a,l.readTime),o=o.insert(a,l)):!u.isValidDocument()||l.version.compareTo(u.version)>0||l.version.compareTo(u.version)===0&&u.hasPendingWrites?(e.addEntry(l),o=o.insert(a,l)):N("LocalStore","Ignoring outdated watch update for ",a,". Current version:",u.version," Watch version:",l.version)}),{er:o,nr:i}})}function QI(t,e){let n=Q(t);return n.persistence.runTransaction("Allocate target","readwrite",r=>{let i;return n.Fs.getTargetData(r,e).next(s=>s?(i=s,E.resolve(i)):n.Fs.allocateTargetId(r).next(o=>(i=new $t(e,o,"TargetPurposeListen",r.currentSequenceNumber),n.Fs.addTargetData(r,i).next(()=>i))))}).then(r=>{let i=n.Hi.get(r.targetId);return(i===null||r.snapshotVersion.compareTo(i.snapshotVersion)>0)&&(n.Hi=n.Hi.insert(r.targetId,r),n.Ji.set(e,r.targetId)),r})}async function Pp(t,e,n){let r=Q(t),i=r.Hi.get(e),s=n?"readwrite":"readwrite-primary";try{n||await r.persistence.runTransaction("Release target",s,o=>r.persistence.referenceDelegate.removeTarget(o,i))}catch(o){if(!Bo(o))throw o;N("LocalStore",`Failed to update sequence numbers for target ${e}: ${o}`)}r.Hi=r.Hi.remove(e),r.Ji.delete(i.target)}function mw(t,e,n){let r=Q(t),i=R.min(),s=j();return r.persistence.runTransaction("Execute query","readonly",o=>function(a,l,u){let c=Q(a),h=c.Ji.get(u);return h!==void 0?E.resolve(c.Hi.get(h)):c.Fs.getTargetData(l,u)}(r,o,xn(e)).next(a=>{if(a)return i=a.lastLimboFreeSnapshotVersion,r.Fs.getMatchingKeysForTargetId(o,a.targetId).next(l=>{s=l})}).next(()=>r.Wi.getDocumentsMatchingQuery(o,e,n?i:R.min(),n?s:j())).next(a=>(HI(r,uI(e),a),{documents:a,sr:s})))}function HI(t,e,n){let r=t.Yi.get(e)||R.min();n.forEach((i,s)=>{s.readTime.compareTo(r)>0&&(r=s.readTime)}),t.Yi.set(e,r)}var Eu=class{constructor(){this.activeTargetIds=mI()}hr(e){this.activeTargetIds=this.activeTargetIds.add(e)}lr(e){this.activeTargetIds=this.activeTargetIds.delete(e)}ar(){let e={activeTargetIds:this.activeTargetIds.toArray(),updateTimeMs:Date.now()};return JSON.stringify(e)}};var _p=class{constructor(){this.Wr=new Eu,this.Hr={},this.onlineStateHandler=null,this.sequenceNumberHandler=null}addPendingMutation(e){}updateMutationState(e,n,r){}addLocalQueryTarget(e){return this.Wr.hr(e),this.Hr[e]||"not-current"}updateQueryState(e,n,r){this.Hr[e]=n}removeLocalQueryTarget(e){this.Wr.lr(e)}isLocalQueryTarget(e){return this.Wr.activeTargetIds.has(e)}clearQueryState(e){delete this.Hr[e]}getAllActiveQueryTargets(){return this.Wr.activeTargetIds}isActiveQueryTarget(e){return this.Wr.activeTargetIds.has(e)}start(){return this.Wr=new Eu,Promise.resolve()}handleUserChange(e,n,r){}setOnlineState(e){}shutdown(){}writeSequenceNumber(e){}notifyBundleLoaded(e){}};var Op=class{Jr(e){}shutdown(){}};var Su=class{constructor(){this.Yr=()=>this.Xr(),this.Zr=()=>this.eo(),this.no=[],this.so()}Jr(e){this.no.push(e)}shutdown(){window.removeEventListener("online",this.Yr),window.removeEventListener("offline",this.Zr)}so(){window.addEventListener("online",this.Yr),window.addEventListener("offline",this.Zr)}Xr(){N("ConnectivityMonitor","Network connectivity changed: AVAILABLE");for(let e of this.no)e(0)}eo(){N("ConnectivityMonitor","Network connectivity changed: UNAVAILABLE");for(let e of this.no)e(1)}static D(){return typeof window<"u"&&window.addEventListener!==void 0&&window.removeEventListener!==void 0}};var uu=null;function Lf(){return uu===null?uu=268435456+Math.round(2147483648*Math.random()):uu++,"0x"+uu.toString(16)}var KI={BatchGetDocuments:"batchGet",Commit:"commit",RunQuery:"runQuery",RunAggregationQuery:"runAggregationQuery"};var Lp=class{constructor(e){this.io=e.io,this.ro=e.ro}oo(e){this.uo=e}co(e){this.ao=e}onMessage(e){this.ho=e}close(){this.ro()}send(e){this.io(e)}lo(){this.uo()}fo(e){this.ao(e)}_o(e){this.ho(e)}};var je="WebChannelConnection",Mp=class extends class{constructor(e){this.databaseInfo=e,this.databaseId=e.databaseId;let n=e.ssl?"https":"http";this.wo=n+"://"+e.host,this.mo="projects/"+this.databaseId.projectId+"/databases/"+this.databaseId.database+"/documents"}get yo(){return!1}po(e,n,r,i,s){let o=Lf(),a=this.Io(e,n);N("RestConnection",`Sending RPC '${e}' ${o}:`,a,r);let l={};return this.To(l,i,s),this.Eo(e,a,l,r).then(u=>(N("RestConnection",`Received RPC '${e}' ${o}: `,u),u),u=>{throw zi("RestConnection",`RPC '${e}' ${o} failed with error: `,u,"url: ",a,"request:",r),u})}Ao(e,n,r,i,s,o){return this.po(e,n,r,i,s)}To(e,n,r){e["X-Goog-Api-Client"]="gl-js/ fire/"+Gi,e["Content-Type"]="text/plain",this.databaseInfo.appId&&(e["X-Firebase-GMPID"]=this.databaseInfo.appId),n&&n.headers.forEach((i,s)=>e[s]=i),r&&r.headers.forEach((i,s)=>e[s]=i)}Io(e,n){let r=KI[e];return`${this.wo}/v1/${n}:${r}`}}{constructor(e){super(e),this.forceLongPolling=e.forceLongPolling,this.autoDetectLongPolling=e.autoDetectLongPolling,this.useFetchStreams=e.useFetchStreams}Eo(e,n,r,i){let s=Lf();return new Promise((o,a)=>{let l=new Wv;l.setWithCredentials(!0),l.listenOnce(Hv.COMPLETE,()=>{try{switch(l.getLastErrorCode()){case ou.NO_ERROR:let c=l.getResponseJson();N(je,`XHR for RPC '${e}' ${s} received:`,JSON.stringify(c)),o(c);break;case ou.TIMEOUT:N(je,`RPC '${e}' ${s} timed out`),a(new O(x.DEADLINE_EXCEEDED,"Request time out"));break;case ou.HTTP_ERROR:let h=l.getStatus();if(N(je,`RPC '${e}' ${s} failed with status:`,h,"response text:",l.getResponseText()),h>0){let p=l.getResponseJson();Array.isArray(p)&&(p=p[0]);let g=p?.error;if(g&&g.status&&g.message){let y=function(A){let P=A.toLowerCase().replace(/_/g,"-");return Object.values(x).indexOf(P)>=0?P:x.UNKNOWN}(g.status);a(new O(y,g.message))}else a(new O(x.UNKNOWN,"Server responded with status "+l.getStatus()))}else a(new O(x.UNAVAILABLE,"Connection failed."));break;default:z()}}finally{N(je,`RPC '${e}' ${s} completed.`)}});let u=JSON.stringify(i);N(je,`RPC '${e}' ${s} sending request:`,i),l.send(n,"POST",u,r,15)})}Ro(e,n,r){let i=Lf(),s=[this.wo,"/","google.firestore.v1.Firestore","/",e,"/channel"],o=jv(),a=Qv(),l={httpSessionIdParam:"gsessionid",initMessageHeaders:{},messageUrlParams:{database:`projects/${this.databaseId.projectId}/databases/${this.databaseId.database}`},sendRawJson:!0,supportsCrossDomainXhr:!0,internalChannelParams:{forwardChannelRequestTimeoutMs:6e5},forceLongPolling:this.forceLongPolling,detectBufferingProxy:this.autoDetectLongPolling};this.useFetchStreams&&(l.xmlHttpFactory=new Xv({})),this.To(l.initMessageHeaders,n,r),l.encodeInitMessageHeaders=!0;let u=s.join("");N(je,`Creating RPC '${e}' stream ${i}: ${u}`,l);let c=o.createWebChannel(u,l),h=!1,p=!1,g=new Lp({io:A=>{p?N(je,`Not sending because RPC '${e}' stream ${i} is closed:`,A):(h||(N(je,`Opening RPC '${e}' stream ${i} transport.`),c.open(),h=!0),N(je,`RPC '${e}' stream ${i} sending:`,A),c.send(A))},ro:()=>c.close()}),y=(A,P,f)=>{A.listen(P,d=>{try{f(d)}catch(m){setTimeout(()=>{throw m},0)}})};return y(c,vo.EventType.OPEN,()=>{p||N(je,`RPC '${e}' stream ${i} transport opened.`)}),y(c,vo.EventType.CLOSE,()=>{p||(p=!0,N(je,`RPC '${e}' stream ${i} transport closed`),g.fo())}),y(c,vo.EventType.ERROR,A=>{p||(p=!0,zi(je,`RPC '${e}' stream ${i} transport errored:`,A),g.fo(new O(x.UNAVAILABLE,"The operation could not be completed")))}),y(c,vo.EventType.MESSAGE,A=>{var P;if(!p){let f=A.data[0];Ee(!!f);let d=f,m=d.error||((P=d[0])===null||P===void 0?void 0:P.error);if(m){N(je,`RPC '${e}' stream ${i} received error:`,m);let v=m.status,S=function(T){let k=ge[T];if(k!==void 0)return Bw(k)}(v),D=m.message;S===void 0&&(S=x.INTERNAL,D="Unknown error status: "+v+" with message "+m.message),p=!0,g.fo(new O(S,D)),c.close()}else N(je,`RPC '${e}' stream ${i} received:`,f),g._o(f)}}),y(a,Kv.STAT_EVENT,A=>{A.stat===Pf.PROXY?N(je,`RPC '${e}' stream ${i} detected buffering proxy`):A.stat===Pf.NOPROXY&&N(je,`RPC '${e}' stream ${i} detected no buffering proxy`)}),setTimeout(()=>{g.lo()},0),g}};function Mf(){return typeof document<"u"?document:null}function Xw(t){return new hp(t,!0)}var Iu=class{constructor(e,n,r=1e3,i=1.5,s=6e4){this.si=e,this.timerId=n,this.vo=r,this.Po=i,this.bo=s,this.Vo=0,this.So=null,this.Do=Date.now(),this.reset()}reset(){this.Vo=0}Co(){this.Vo=this.bo}xo(e){this.cancel();let n=Math.floor(this.Vo+this.No()),r=Math.max(0,Date.now()-this.Do),i=Math.max(0,n-r);i>0&&N("ExponentialBackoff",`Backing off for ${i} ms (base delay: ${this.Vo} ms, delay with jitter: ${n} ms, last attempt: ${r} ms ago)`),this.So=this.si.enqueueAfterDelay(this.timerId,i,()=>(this.Do=Date.now(),e())),this.Vo*=this.Po,this.Vo<this.vo&&(this.Vo=this.vo),this.Vo>this.bo&&(this.Vo=this.bo)}ko(){this.So!==null&&(this.So.skipDelay(),this.So=null)}cancel(){this.So!==null&&(this.So.cancel(),this.So=null)}No(){return(Math.random()-.5)*this.Vo}};var bp=class{constructor(e,n,r,i,s,o,a,l){this.si=e,this.Mo=r,this.Oo=i,this.connection=s,this.authCredentialsProvider=o,this.appCheckCredentialsProvider=a,this.listener=l,this.state=0,this.$o=0,this.Fo=null,this.Bo=null,this.stream=null,this.Lo=new Iu(e,n)}qo(){return this.state===1||this.state===5||this.Uo()}Uo(){return this.state===2||this.state===3}start(){this.state!==4?this.auth():this.Ko()}async stop(){this.qo()&&await this.close(0)}Go(){this.state=0,this.Lo.reset()}Qo(){this.Uo()&&this.Fo===null&&(this.Fo=this.si.enqueueAfterDelay(this.Mo,6e4,()=>this.jo()))}zo(e){this.Wo(),this.stream.send(e)}async jo(){if(this.Uo())return this.close(0)}Wo(){this.Fo&&(this.Fo.cancel(),this.Fo=null)}Ho(){this.Bo&&(this.Bo.cancel(),this.Bo=null)}async close(e,n){this.Wo(),this.Ho(),this.Lo.cancel(),this.$o++,e!==4?this.Lo.reset():n&&n.code===x.RESOURCE_EXHAUSTED?(In(n.toString()),In("Using maximum backoff delay to prevent overloading the backend."),this.Lo.Co()):n&&n.code===x.UNAUTHENTICATED&&this.state!==3&&(this.authCredentialsProvider.invalidateToken(),this.appCheckCredentialsProvider.invalidateToken()),this.stream!==null&&(this.Jo(),this.stream.close(),this.stream=null),this.state=e,await this.listener.co(n)}Jo(){}auth(){this.state=1;let e=this.Yo(this.$o),n=this.$o;Promise.all([this.authCredentialsProvider.getToken(),this.appCheckCredentialsProvider.getToken()]).then(([r,i])=>{this.$o===n&&this.Xo(r,i)},r=>{e(()=>{let i=new O(x.UNKNOWN,"Fetching auth token failed: "+r.message);return this.Zo(i)})})}Xo(e,n){let r=this.Yo(this.$o);this.stream=this.tu(e,n),this.stream.oo(()=>{r(()=>(this.state=2,this.Bo=this.si.enqueueAfterDelay(this.Oo,1e4,()=>(this.Uo()&&(this.state=3),Promise.resolve())),this.listener.oo()))}),this.stream.co(i=>{r(()=>this.Zo(i))}),this.stream.onMessage(i=>{r(()=>this.onMessage(i))})}Ko(){this.state=5,this.Lo.xo(async()=>{this.state=0,this.start()})}Zo(e){return N("PersistentStream",`close with error: ${e}`),this.stream=null,this.close(4,e)}Yo(e){return n=>{this.si.enqueueAndForget(()=>this.$o===e?n():(N("PersistentStream","stream callback skipped by getCloseGuardedDispatcher."),Promise.resolve()))}}},Rp=class extends bp{constructor(e,n,r,i,s,o){super(e,"listen_stream_connection_backoff","listen_stream_idle","health_check_timeout",n,r,i,o),this.serializer=s}tu(e,n){return this.connection.Ro("Listen",e,n)}onMessage(e){this.Lo.reset();let n=OI(this.serializer,e),r=function(i){if(!("targetChange"in i))return R.min();let s=i.targetChange;return s.targetIds&&s.targetIds.length?R.min():s.readTime?Ri(s.readTime):R.min()}(e);return this.listener.eu(n,r)}nu(e){let n={};n.database=pw(this.serializer),n.addTarget=function(i,s){let o,a=s.target;if(o=rp(a)?{documents:LI(i,a)}:{query:MI(i,a)},o.targetId=s.targetId,s.resumeToken.approximateByteSize()>0){o.resumeToken=NI(i,s.resumeToken);let l=dp(i,s.expectedCount);l!==null&&(o.expectedCount=l)}else if(s.snapshotVersion.compareTo(R.min())>0){o.readTime=DI(i,s.snapshotVersion.toTimestamp());let l=dp(i,s.expectedCount);l!==null&&(o.expectedCount=l)}return o}(this.serializer,e);let r=RI(this.serializer,e);r&&(n.labels=r),this.zo(n)}su(e){let n={};n.database=pw(this.serializer),n.removeTarget=e,this.zo(n)}};var zp=class extends class{}{constructor(e,n,r,i){super(),this.authCredentials=e,this.appCheckCredentials=n,this.connection=r,this.serializer=i,this.hu=!1}lu(){if(this.hu)throw new O(x.FAILED_PRECONDITION,"The client has already been terminated.")}po(e,n,r){return this.lu(),Promise.all([this.authCredentials.getToken(),this.appCheckCredentials.getToken()]).then(([i,s])=>this.connection.po(e,n,r,i,s)).catch(i=>{throw i.name==="FirebaseError"?(i.code===x.UNAUTHENTICATED&&(this.authCredentials.invalidateToken(),this.appCheckCredentials.invalidateToken()),i):new O(x.UNKNOWN,i.toString())})}Ao(e,n,r,i){return this.lu(),Promise.all([this.authCredentials.getToken(),this.appCheckCredentials.getToken()]).then(([s,o])=>this.connection.Ao(e,n,r,s,o,i)).catch(s=>{throw s.name==="FirebaseError"?(s.code===x.UNAUTHENTICATED&&(this.authCredentials.invalidateToken(),this.appCheckCredentials.invalidateToken()),s):new O(x.UNKNOWN,s.toString())})}terminate(){this.hu=!0}};var Fp=class{constructor(e,n){this.asyncQueue=e,this.onlineStateHandler=n,this.state="Unknown",this.du=0,this._u=null,this.wu=!0}mu(){this.du===0&&(this.gu("Unknown"),this._u=this.asyncQueue.enqueueAfterDelay("online_state_timeout",1e4,()=>(this._u=null,this.yu("Backend didn't respond within 10 seconds."),this.gu("Offline"),Promise.resolve())))}pu(e){this.state==="Online"?this.gu("Unknown"):(this.du++,this.du>=1&&(this.Iu(),this.yu(`Connection failed 1 times. Most recent error: ${e.toString()}`),this.gu("Offline")))}set(e){this.Iu(),this.du=0,e==="Online"&&(this.wu=!1),this.gu(e)}gu(e){e!==this.state&&(this.state=e,this.onlineStateHandler(e))}yu(e){let n=`Could not reach Cloud Firestore backend. ${e}
This typically indicates that your device does not have a healthy Internet connection at the moment. The client will operate in offline mode until it is able to successfully connect to the backend.`;this.wu?(In(n),this.wu=!1):N("OnlineStateTracker",n)}Iu(){this._u!==null&&(this._u.cancel(),this._u=null)}};var Bp=class{constructor(e,n,r,i,s){this.localStore=e,this.datastore=n,this.asyncQueue=r,this.remoteSyncer={},this.Tu=[],this.Eu=new Map,this.Au=new Set,this.Ru=[],this.vu=s,this.vu.Jr(o=>{r.enqueueAndForget(async()=>{Vo(this)&&(N("RemoteStore","Restarting streams for network reachability change."),await async function(a){let l=Q(a);l.Au.add(4),await qo(l),l.Pu.set("Unknown"),l.Au.delete(4),await zu(l)}(this))})}),this.Pu=new Fp(r,i)}};async function zu(t){if(Vo(t))for(let e of t.Ru)await e(!0)}async function qo(t){for(let e of t.Ru)await e(!1)}function Ww(t,e){let n=Q(t);n.Eu.has(e.targetId)||(n.Eu.set(e.targetId,e),mm(n)?pm(n):Ji(n).Uo()&&fm(n,e))}function Gw(t,e){let n=Q(t),r=Ji(n);n.Eu.delete(e),r.Uo()&&Jw(n,e),n.Eu.size===0&&(r.Uo()?r.Qo():Vo(n)&&n.Pu.set("Unknown"))}function fm(t,e){if(t.bu.Lt(e.targetId),e.resumeToken.approximateByteSize()>0||e.snapshotVersion.compareTo(R.min())>0){let n=t.remoteSyncer.getRemoteKeysForTarget(e.targetId).size;e=e.withExpectedCount(n)}Ji(t).nu(e)}function Jw(t,e){t.bu.Lt(e),Ji(t).su(e)}function pm(t){t.bu=new cp({getRemoteKeysForTarget:e=>t.remoteSyncer.getRemoteKeysForTarget(e),he:e=>t.Eu.get(e)||null,oe:()=>t.datastore.serializer.databaseId}),Ji(t).start(),t.Pu.mu()}function mm(t){return Vo(t)&&!Ji(t).qo()&&t.Eu.size>0}function Vo(t){return Q(t).Au.size===0}function Zw(t){t.bu=void 0}async function XI(t){t.Eu.forEach((e,n)=>{fm(t,e)})}async function WI(t,e){Zw(t),mm(t)?(t.Pu.pu(e),pm(t)):t.Pu.set("Unknown")}async function GI(t,e,n){if(t.Pu.set("Online"),e instanceof Au&&e.state===2&&e.cause)try{await async function(r,i){let s=i.cause;for(let o of i.targetIds)r.Eu.has(o)&&(await r.remoteSyncer.rejectListen(o,s),r.Eu.delete(o),r.bu.removeTarget(o))}(t,e)}catch(r){N("RemoteStore","Failed to remove targets %s: %s ",e.targetIds.join(","),r),await gw(t,r)}else if(e instanceof bi?t.bu.Wt(e):e instanceof yu?t.bu.ee(e):t.bu.Yt(e),!n.isEqual(R.min()))try{let r=await Kw(t.localStore);n.compareTo(r)>=0&&await function(i,s){let o=i.bu.ue(s);return o.targetChanges.forEach((a,l)=>{if(a.resumeToken.approximateByteSize()>0){let u=i.Eu.get(l);u&&i.Eu.set(l,u.withResumeToken(a.resumeToken,s))}}),o.targetMismatches.forEach((a,l)=>{let u=i.Eu.get(a);if(!u)return;i.Eu.set(a,u.withResumeToken(Ne.EMPTY_BYTE_STRING,u.snapshotVersion)),Jw(i,a);let c=new $t(u.target,a,l,u.sequenceNumber);fm(i,c)}),i.remoteSyncer.applyRemoteEvent(o)}(t,n)}catch(r){N("RemoteStore","Failed to raise snapshot:",r),await gw(t,r)}}async function gw(t,e,n){if(!Bo(e))throw e;t.Au.add(1),await qo(t),t.Pu.set("Offline"),n||(n=()=>Kw(t.localStore)),t.asyncQueue.enqueueRetryable(async()=>{N("RemoteStore","Retrying IndexedDB access"),await n(),t.Au.delete(1),await zu(t)})}async function yw(t,e){let n=Q(t);n.asyncQueue.verifyOperationInProgress(),N("RemoteStore","RemoteStore received new credentials");let r=Vo(n);n.Au.add(3),await qo(n),r&&n.Pu.set("Unknown"),await n.remoteSyncer.handleCredentialChange(e),n.Au.delete(3),await zu(n)}async function JI(t,e){let n=Q(t);e?(n.Au.delete(2),await zu(n)):e||(n.Au.add(2),await qo(n),n.Pu.set("Unknown"))}function Ji(t){return t.Vu||(t.Vu=function(e,n,r){let i=Q(e);return i.lu(),new Rp(n,i.connection,i.authCredentials,i.appCheckCredentials,i.serializer,r)}(t.datastore,t.asyncQueue,{oo:XI.bind(null,t),co:WI.bind(null,t),eu:GI.bind(null,t)}),t.Ru.push(async e=>{e?(t.Vu.Go(),mm(t)?pm(t):t.Pu.set("Unknown")):(await t.Vu.stop(),Zw(t))})),t.Vu}var Ro=class{constructor(e,n,r,i,s){this.asyncQueue=e,this.timerId=n,this.targetTimeMs=r,this.op=i,this.removalCallback=s,this.deferred=new En,this.then=this.deferred.promise.then.bind(this.deferred.promise),this.deferred.promise.catch(o=>{})}static createAndSchedule(e,n,r,i,s){let o=Date.now()+r,a=new Ro(e,n,o,i,s);return a.start(r),a}start(e){this.timerHandle=setTimeout(()=>this.handleDelayElapsed(),e)}skipDelay(){return this.handleDelayElapsed()}cancel(e){this.timerHandle!==null&&(this.clearTimeout(),this.deferred.reject(new O(x.CANCELLED,"Operation cancelled"+(e?": "+e:""))))}handleDelayElapsed(){this.asyncQueue.enqueueAndForget(()=>this.timerHandle!==null?(this.clearTimeout(),this.op().then(e=>this.deferred.resolve(e))):Promise.resolve())}clearTimeout(){this.timerHandle!==null&&(this.removalCallback(this),clearTimeout(this.timerHandle),this.timerHandle=null)}};function Yw(t,e){if(In("AsyncQueue",`${e}: ${t}`),Bo(t))return new O(x.UNAVAILABLE,`${e}: ${t}`);throw t}var nr=class{constructor(e){this.comparator=e?(n,r)=>e(n,r)||_.comparator(n.key,r.key):(n,r)=>_.comparator(n.key,r.key),this.keyedMap=wo(),this.sortedSet=new oe(this.comparator)}static emptySet(e){return new nr(e.comparator)}has(e){return this.keyedMap.get(e)!=null}get(e){return this.keyedMap.get(e)}first(){return this.sortedSet.minKey()}last(){return this.sortedSet.maxKey()}isEmpty(){return this.sortedSet.isEmpty()}indexOf(e){let n=this.keyedMap.get(e);return n?this.sortedSet.indexOf(n):-1}get size(){return this.sortedSet.size}forEach(e){this.sortedSet.inorderTraversal((n,r)=>(e(n),!1))}add(e){let n=this.delete(e.key);return n.copy(n.keyedMap.insert(e.key,e),n.sortedSet.insert(e,null))}delete(e){let n=this.get(e);return n?this.copy(this.keyedMap.remove(e),this.sortedSet.remove(n)):this}isEqual(e){if(!(e instanceof nr)||this.size!==e.size)return!1;let n=this.sortedSet.getIterator(),r=e.sortedSet.getIterator();for(;n.hasNext();){let i=n.getNext().key,s=r.getNext().key;if(!i.isEqual(s))return!1}return!0}toString(){let e=[];return this.forEach(n=>{e.push(n.toString())}),e.length===0?"DocumentSet ()":`DocumentSet (
  `+e.join(`  
`)+`
)`}copy(e,n){let r=new nr;return r.comparator=this.comparator,r.keyedMap=e,r.sortedSet=n,r}};var xu=class{constructor(){this.Du=new oe(_.comparator)}track(e){let n=e.doc.key,r=this.Du.get(n);r?e.type!==0&&r.type===3?this.Du=this.Du.insert(n,e):e.type===3&&r.type!==1?this.Du=this.Du.insert(n,{type:r.type,doc:e.doc}):e.type===2&&r.type===2?this.Du=this.Du.insert(n,{type:2,doc:e.doc}):e.type===2&&r.type===0?this.Du=this.Du.insert(n,{type:0,doc:e.doc}):e.type===1&&r.type===0?this.Du=this.Du.remove(n):e.type===1&&r.type===2?this.Du=this.Du.insert(n,{type:1,doc:r.doc}):e.type===0&&r.type===1?this.Du=this.Du.insert(n,{type:2,doc:e.doc}):z():this.Du=this.Du.insert(n,e)}Cu(){let e=[];return this.Du.inorderTraversal((n,r)=>{e.push(r)}),e}},lr=class{constructor(e,n,r,i,s,o,a,l,u){this.query=e,this.docs=n,this.oldDocs=r,this.docChanges=i,this.mutatedKeys=s,this.fromCache=o,this.syncStateChanged=a,this.excludesMetadataChanges=l,this.hasCachedResults=u}static fromInitialDocuments(e,n,r,i,s){let o=[];return n.forEach(a=>{o.push({type:0,doc:a})}),new lr(e,n,nr.emptySet(n),o,r,i,!0,!1,s)}get hasPendingWrites(){return!this.mutatedKeys.isEmpty()}isEqual(e){if(!(this.fromCache===e.fromCache&&this.hasCachedResults===e.hasCachedResults&&this.syncStateChanged===e.syncStateChanged&&this.mutatedKeys.isEqual(e.mutatedKeys)&&bu(this.query,e.query)&&this.docs.isEqual(e.docs)&&this.oldDocs.isEqual(e.oldDocs)))return!1;let n=this.docChanges,r=e.docChanges;if(n.length!==r.length)return!1;for(let i=0;i<n.length;i++)if(n[i].type!==r[i].type||!n[i].doc.isEqual(r[i].doc))return!1;return!0}};var qp=class{constructor(){this.xu=void 0,this.listeners=[]}},Vp=class{constructor(){this.queries=new sr(e=>Pw(e),bu),this.onlineState="Unknown",this.Nu=new Set}};async function ZI(t,e){let n=Q(t),r=e.query,i=!1,s=n.queries.get(r);if(s||(i=!0,s=new qp),i)try{s.xu=await n.onListen(r)}catch(o){let a=Yw(o,`Initialization of query '${sp(e.query)}' failed`);return void e.onError(a)}n.queries.set(r,s),s.listeners.push(e),e.ku(n.onlineState),s.xu&&e.Mu(s.xu)&&gm(n)}async function YI(t,e){let n=Q(t),r=e.query,i=!1,s=n.queries.get(r);if(s){let o=s.listeners.indexOf(e);o>=0&&(s.listeners.splice(o,1),i=s.listeners.length===0)}if(i)return n.queries.delete(r),n.onUnlisten(r)}function $I(t,e){let n=Q(t),r=!1;for(let i of e){let s=i.query,o=n.queries.get(s);if(o){for(let a of o.listeners)a.Mu(i)&&(r=!0);o.xu=i}}r&&gm(n)}function ex(t,e,n){let r=Q(t),i=r.queries.get(e);if(i)for(let s of i.listeners)s.onError(n);r.queries.delete(e)}function gm(t){t.Nu.forEach(e=>{e.next()})}var Up=class{constructor(e,n,r){this.query=e,this.Ou=n,this.$u=!1,this.Fu=null,this.onlineState="Unknown",this.options=r||{}}Mu(e){if(!this.options.includeMetadataChanges){let r=[];for(let i of e.docChanges)i.type!==3&&r.push(i);e=new lr(e.query,e.docs,e.oldDocs,r,e.mutatedKeys,e.fromCache,e.syncStateChanged,!0,e.hasCachedResults)}let n=!1;return this.$u?this.Bu(e)&&(this.Ou.next(e),n=!0):this.Lu(e,this.onlineState)&&(this.qu(e),n=!0),this.Fu=e,n}onError(e){this.Ou.error(e)}ku(e){this.onlineState=e;let n=!1;return this.Fu&&!this.$u&&this.Lu(this.Fu,e)&&(this.qu(this.Fu),n=!0),n}Lu(e,n){if(!e.fromCache)return!0;let r=n!=="Offline";return(!this.options.Uu||!r)&&(!e.docs.isEmpty()||e.hasCachedResults||n==="Offline")}Bu(e){if(e.docChanges.length>0)return!0;let n=this.Fu&&this.Fu.hasPendingWrites!==e.hasPendingWrites;return!(!e.syncStateChanged&&!n)&&this.options.includeMetadataChanges===!0}qu(e){e=lr.fromInitialDocuments(e.query,e.docs,e.mutatedKeys,e.fromCache,e.hasCachedResults),this.$u=!0,this.Ou.next(e)}};var Tu=class{constructor(e){this.key=e}},Cu=class{constructor(e){this.key=e}},jp=class{constructor(e,n){this.query=e,this.Ju=n,this.Yu=null,this.hasCachedResults=!1,this.current=!1,this.Xu=j(),this.mutatedKeys=j(),this.Zu=_w(e),this.tc=new nr(this.Zu)}get ec(){return this.Ju}nc(e,n){let r=n?n.sc:new xu,i=n?n.tc:this.tc,s=n?n.mutatedKeys:this.mutatedKeys,o=i,a=!1,l=this.query.limitType==="F"&&i.size===this.query.limit?i.last():null,u=this.query.limitType==="L"&&i.size===this.query.limit?i.first():null;if(e.inorderTraversal((c,h)=>{let p=i.get(c),g=Ru(this.query,h)?h:null,y=!!p&&this.mutatedKeys.has(p.key),A=!!g&&(g.hasLocalMutations||this.mutatedKeys.has(g.key)&&g.hasCommittedMutations),P=!1;p&&g?p.data.isEqual(g.data)?y!==A&&(r.track({type:3,doc:g}),P=!0):this.ic(p,g)||(r.track({type:2,doc:g}),P=!0,(l&&this.Zu(g,l)>0||u&&this.Zu(g,u)<0)&&(a=!0)):!p&&g?(r.track({type:0,doc:g}),P=!0):p&&!g&&(r.track({type:1,doc:p}),P=!0,(l||u)&&(a=!0)),P&&(g?(o=o.add(g),s=A?s.add(c):s.delete(c)):(o=o.delete(c),s=s.delete(c)))}),this.query.limit!==null)for(;o.size>this.query.limit;){let c=this.query.limitType==="F"?o.last():o.first();o=o.delete(c.key),s=s.delete(c.key),r.track({type:1,doc:c})}return{tc:o,sc:r,ji:a,mutatedKeys:s}}ic(e,n){return e.hasLocalMutations&&n.hasCommittedMutations&&!n.hasLocalMutations}applyChanges(e,n,r){let i=this.tc;this.tc=e.tc,this.mutatedKeys=e.mutatedKeys;let s=e.sc.Cu();s.sort((u,c)=>function(h,p){let g=y=>{switch(y){case 0:return 1;case 2:case 3:return 2;case 1:return 0;default:return z()}};return g(h)-g(p)}(u.type,c.type)||this.Zu(u.doc,c.doc)),this.rc(r);let o=n?this.oc():[],a=this.Xu.size===0&&this.current?1:0,l=a!==this.Yu;return this.Yu=a,s.length!==0||l?{snapshot:new lr(this.query,e.tc,i,s,e.mutatedKeys,a===0,l,!1,!!r&&r.resumeToken.approximateByteSize()>0),uc:o}:{uc:o}}ku(e){return this.current&&e==="Offline"?(this.current=!1,this.applyChanges({tc:this.tc,sc:new xu,mutatedKeys:this.mutatedKeys,ji:!1},!1)):{uc:[]}}cc(e){return!this.Ju.has(e)&&!!this.tc.has(e)&&!this.tc.get(e).hasLocalMutations}rc(e){e&&(e.addedDocuments.forEach(n=>this.Ju=this.Ju.add(n)),e.modifiedDocuments.forEach(n=>{}),e.removedDocuments.forEach(n=>this.Ju=this.Ju.delete(n)),this.current=e.current)}oc(){if(!this.current)return[];let e=this.Xu;this.Xu=j(),this.tc.forEach(r=>{this.cc(r.key)&&(this.Xu=this.Xu.add(r.key))});let n=[];return e.forEach(r=>{this.Xu.has(r)||n.push(new Cu(r))}),this.Xu.forEach(r=>{e.has(r)||n.push(new Tu(r))}),n}ac(e){this.Ju=e.sr,this.Xu=j();let n=this.nc(e.documents);return this.applyChanges(n,!0)}hc(){return lr.fromInitialDocuments(this.query,this.tc,this.mutatedKeys,this.Yu===0,this.hasCachedResults)}},Qp=class{constructor(e,n,r){this.query=e,this.targetId=n,this.view=r}},Hp=class{constructor(e){this.key=e,this.lc=!1}},Kp=class{constructor(e,n,r,i,s,o){this.localStore=e,this.remoteStore=n,this.eventManager=r,this.sharedClientState=i,this.currentUser=s,this.maxConcurrentLimboResolutions=o,this.fc={},this.dc=new sr(a=>Pw(a),bu),this._c=new Map,this.wc=new Set,this.mc=new oe(_.comparator),this.gc=new Map,this.yc=new Lo,this.Ic={},this.Tc=new Map,this.Ec=ar.kn(),this.onlineState="Unknown",this.Ac=void 0}get isPrimaryClient(){return this.Ac===!0}};async function tx(t,e){let n=lx(t),r,i,s=n.dc.get(e);if(s)r=s.targetId,n.sharedClientState.addLocalQueryTarget(r),i=s.view.hc();else{let o=await QI(n.localStore,xn(e)),a=n.sharedClientState.addLocalQueryTarget(o.targetId);r=o.targetId,i=await nx(n,e,r,a==="current",o.resumeToken),n.isPrimaryClient&&Ww(n.remoteStore,o)}return i}async function nx(t,e,n,r,i){t.Rc=(h,p,g)=>async function(y,A,P,f){let d=A.view.nc(P);d.ji&&(d=await mw(y.localStore,A.query,!1).then(({documents:S})=>A.view.nc(S,d)));let m=f&&f.targetChanges.get(A.targetId),v=A.view.applyChanges(d,y.isPrimaryClient,m);return vw(y,A.targetId,v.uc),v.snapshot}(t,h,p,g);let s=await mw(t.localStore,e,!0),o=new jp(e,s.sr),a=o.nc(s.documents),l=Hr.createSynthesizedTargetChangeForCurrentChange(n,r&&t.onlineState!=="Offline",i),u=o.applyChanges(a,t.isPrimaryClient,l);vw(t,n,u.uc);let c=new Qp(e,n,o);return t.dc.set(e,c),t._c.has(n)?t._c.get(n).push(e):t._c.set(n,[e]),u.snapshot}async function rx(t,e){let n=Q(t),r=n.dc.get(e),i=n._c.get(r.targetId);if(i.length>1)return n._c.set(r.targetId,i.filter(s=>!bu(s,e))),void n.dc.delete(e);n.isPrimaryClient?(n.sharedClientState.removeLocalQueryTarget(r.targetId),n.sharedClientState.isActiveQueryTarget(r.targetId)||await Pp(n.localStore,r.targetId,!1).then(()=>{n.sharedClientState.clearQueryState(r.targetId),Gw(n.remoteStore,r.targetId),Xp(n,r.targetId)}).catch(om)):(Xp(n,r.targetId),await Pp(n.localStore,r.targetId,!0))}async function $w(t,e){let n=Q(t);try{let r=await UI(n.localStore,e);e.targetChanges.forEach((i,s)=>{let o=n.gc.get(s);o&&(Ee(i.addedDocuments.size+i.modifiedDocuments.size+i.removedDocuments.size<=1),i.addedDocuments.size>0?o.lc=!0:i.modifiedDocuments.size>0?Ee(o.lc):i.removedDocuments.size>0&&(Ee(o.lc),o.lc=!1))}),await t2(n,r,e)}catch(r){await om(r)}}function Aw(t,e,n){let r=Q(t);if(r.isPrimaryClient&&n===0||!r.isPrimaryClient&&n===1){let i=[];r.dc.forEach((s,o)=>{let a=o.view.ku(e);a.snapshot&&i.push(a.snapshot)}),function(s,o){let a=Q(s);a.onlineState=o;let l=!1;a.queries.forEach((u,c)=>{for(let h of c.listeners)h.ku(o)&&(l=!0)}),l&&gm(a)}(r.eventManager,e),i.length&&r.fc.eu(i),r.onlineState=e,r.isPrimaryClient&&r.sharedClientState.setOnlineState(e)}}async function ix(t,e,n){let r=Q(t);r.sharedClientState.updateQueryState(e,"rejected",n);let i=r.gc.get(e),s=i&&i.key;if(s){let o=new oe(_.comparator);o=o.insert(s,ke.newNoDocument(s,R.min()));let a=j().add(s),l=new Xi(R.min(),new Map,new oe(X),o,a);await $w(r,l),r.mc=r.mc.remove(s),r.gc.delete(e),ym(r)}else await Pp(r.localStore,e,!1).then(()=>Xp(r,e,n)).catch(om)}function Xp(t,e,n=null){t.sharedClientState.removeLocalQueryTarget(e);for(let r of t._c.get(e))t.dc.delete(r),n&&t.fc.vc(r,n);t._c.delete(e),t.isPrimaryClient&&t.yc.ps(e).forEach(r=>{t.yc.containsKey(r)||e2(t,r)})}function e2(t,e){t.wc.delete(e.path.canonicalString());let n=t.mc.get(e);n!==null&&(Gw(t.remoteStore,n),t.mc=t.mc.remove(e),t.gc.delete(n),ym(t))}function vw(t,e,n){for(let r of n)r instanceof Tu?(t.yc.addReference(r.key,e),sx(t,r)):r instanceof Cu?(N("SyncEngine","Document no longer in limbo: "+r.key),t.yc.removeReference(r.key,e),t.yc.containsKey(r.key)||e2(t,r.key)):z()}function sx(t,e){let n=e.key,r=n.path.canonicalString();t.mc.get(n)||t.wc.has(r)||(N("SyncEngine","New document in limbo: "+n),t.wc.add(r),ym(t))}function ym(t){for(;t.wc.size>0&&t.mc.size<t.maxConcurrentLimboResolutions;){let e=t.wc.values().next().value;t.wc.delete(e);let n=new _(se.fromString(e)),r=t.Ec.next();t.gc.set(r,new Hp(n)),t.mc=t.mc.insert(n,r),Ww(t.remoteStore,new $t(xn(dm(n.path)),r,"TargetPurposeLimboResolution",xo.ct))}}async function t2(t,e,n){let r=Q(t),i=[],s=[],o=[];r.dc.isEmpty()||(r.dc.forEach((a,l)=>{o.push(r.Rc(l,e,n).then(u=>{if((u||n)&&r.isPrimaryClient&&r.sharedClientState.updateQueryState(l.targetId,u?.fromCache?"not-current":"current"),u){i.push(u);let c=bo.Bi(l.targetId,u);s.push(c)}}))}),await Promise.all(o),r.fc.eu(i),await async function(a,l){let u=Q(a);try{await u.persistence.runTransaction("notifyLocalViewChanges","readwrite",c=>E.forEach(l,h=>E.forEach(h.$i,p=>u.persistence.referenceDelegate.addReference(c,h.targetId,p)).next(()=>E.forEach(h.Fi,p=>u.persistence.referenceDelegate.removeReference(c,h.targetId,p)))))}catch(c){if(!Bo(c))throw c;N("LocalStore","Failed to update sequence numbers: "+c)}for(let c of l){let h=c.targetId;if(!c.fromCache){let p=u.Hi.get(h),g=p.snapshotVersion,y=p.withLastLimboFreeSnapshotVersion(g);u.Hi=u.Hi.insert(h,y)}}}(r.localStore,s))}async function ox(t,e){let n=Q(t);if(!n.currentUser.isEqual(e)){N("SyncEngine","User change. New user:",e.toKey());let r=await Hw(n.localStore,e);n.currentUser=e,function(i,s){i.Tc.forEach(o=>{o.forEach(a=>{a.reject(new O(x.CANCELLED,s))})}),i.Tc.clear()}(n,"'waitForPendingWrites' promise is rejected due to a user change."),n.sharedClientState.handleUserChange(e,r.removedBatchIds,r.addedBatchIds),await t2(n,r.tr)}}function ax(t,e){let n=Q(t),r=n.gc.get(e);if(r&&r.lc)return j().add(r.key);{let i=j(),s=n._c.get(e);if(!s)return i;for(let o of s){let a=n.dc.get(o);i=i.unionWith(a.view.ec)}return i}}function lx(t){let e=Q(t);return e.remoteStore.remoteSyncer.applyRemoteEvent=$w.bind(null,e),e.remoteStore.remoteSyncer.getRemoteKeysForTarget=ax.bind(null,e),e.remoteStore.remoteSyncer.rejectListen=ix.bind(null,e),e.fc.eu=$I.bind(null,e.eventManager),e.fc.vc=ex.bind(null,e.eventManager),e}var ku=class{constructor(){this.synchronizeTabs=!1}async initialize(e){this.serializer=Xw(e.databaseInfo.databaseId),this.sharedClientState=this.createSharedClientState(e),this.persistence=this.createPersistence(e),await this.persistence.start(),this.localStore=this.createLocalStore(e),this.gcScheduler=this.createGarbageCollectionScheduler(e,this.localStore),this.indexBackfillerScheduler=this.createIndexBackfillerScheduler(e,this.localStore)}createGarbageCollectionScheduler(e,n){return null}createIndexBackfillerScheduler(e,n){return null}createLocalStore(e){return VI(this.persistence,new Dp,e.initialUser,this.serializer)}createPersistence(e){return new Cp(Mo.js,this.serializer)}createSharedClientState(e){return new _p}async terminate(){this.gcScheduler&&this.gcScheduler.stop(),await this.sharedClientState.shutdown(),await this.persistence.shutdown()}};var Wp=class{async initialize(e,n){this.localStore||(this.localStore=e.localStore,this.sharedClientState=e.sharedClientState,this.datastore=this.createDatastore(n),this.remoteStore=this.createRemoteStore(n),this.eventManager=this.createEventManager(n),this.syncEngine=this.createSyncEngine(n,!e.synchronizeTabs),this.sharedClientState.onlineStateHandler=r=>Aw(this.syncEngine,r,1),this.remoteStore.remoteSyncer.handleCredentialChange=ox.bind(null,this.syncEngine),await JI(this.remoteStore,this.syncEngine.isPrimaryClient))}createEventManager(e){return new Vp}createDatastore(e){let n=Xw(e.databaseInfo.databaseId),r=(i=e.databaseInfo,new Mp(i));var i;return function(s,o,a,l){return new zp(s,o,a,l)}(e.authCredentials,e.appCheckCredentials,r,n)}createRemoteStore(e){return n=this.localStore,r=this.datastore,i=e.asyncQueue,s=a=>Aw(this.syncEngine,a,0),o=Su.D()?new Su:new Op,new Bp(n,r,i,s,o);var n,r,i,s,o}createSyncEngine(e,n){return function(r,i,s,o,a,l,u){let c=new Kp(r,i,s,o,a,l);return u&&(c.Ac=!0),c}(this.localStore,this.remoteStore,this.eventManager,this.sharedClientState,e.initialUser,e.maxConcurrentLimboResolutions,n)}terminate(){return async function(e){let n=Q(e);N("RemoteStore","RemoteStore shutting down."),n.Au.add(5),await qo(n),n.vu.shutdown(),n.Pu.set("Unknown")}(this.remoteStore)}};var Gp=class{constructor(e){this.observer=e,this.muted=!1}next(e){this.observer.next&&this.Vc(this.observer.next,e)}error(e){this.observer.error?this.Vc(this.observer.error,e):In("Uncaught Error in snapshot listener:",e.toString())}Sc(){this.muted=!0}Vc(e,n){this.muted||setTimeout(()=>{this.muted||e(n)},0)}};var Jp=class{constructor(e,n,r,i){this.authCredentials=e,this.appCheckCredentials=n,this.asyncQueue=r,this.databaseInfo=i,this.user=Ce.UNAUTHENTICATED,this.clientId=du.A(),this.authCredentialListener=()=>Promise.resolve(),this.appCheckCredentialListener=()=>Promise.resolve(),this.authCredentials.start(r,async s=>{N("FirestoreClient","Received user=",s.uid),await this.authCredentialListener(s),this.user=s}),this.appCheckCredentials.start(r,s=>(N("FirestoreClient","Received new app check token=",s),this.appCheckCredentialListener(s,this.user)))}async getConfiguration(){return{asyncQueue:this.asyncQueue,databaseInfo:this.databaseInfo,clientId:this.clientId,authCredentials:this.authCredentials,appCheckCredentials:this.appCheckCredentials,initialUser:this.user,maxConcurrentLimboResolutions:100}}setCredentialChangeListener(e){this.authCredentialListener=e}setAppCheckTokenChangeListener(e){this.appCheckCredentialListener=e}verifyNotTerminated(){if(this.asyncQueue.isShuttingDown)throw new O(x.FAILED_PRECONDITION,"The client has already been terminated.")}terminate(){this.asyncQueue.enterRestrictedMode();let e=new En;return this.asyncQueue.enqueueAndForgetEvenWhileRestricted(async()=>{try{this._onlineComponents&&await this._onlineComponents.terminate(),this._offlineComponents&&await this._offlineComponents.terminate(),this.authCredentials.shutdown(),this.appCheckCredentials.shutdown(),e.resolve()}catch(n){let r=Yw(n,"Failed to shutdown persistence");e.reject(r)}}),e.promise}};async function bf(t,e){t.asyncQueue.verifyOperationInProgress(),N("FirestoreClient","Initializing OfflineComponentProvider");let n=await t.getConfiguration();await e.initialize(n);let r=n.initialUser;t.setCredentialChangeListener(async i=>{r.isEqual(i)||(await Hw(e.localStore,i),r=i)}),e.persistence.setDatabaseDeletedListener(()=>t.terminate()),t._offlineComponents=e}async function ww(t,e){t.asyncQueue.verifyOperationInProgress();let n=await cx(t);N("FirestoreClient","Initializing OnlineComponentProvider");let r=await t.getConfiguration();await e.initialize(n,r),t.setCredentialChangeListener(i=>yw(e.remoteStore,i)),t.setAppCheckTokenChangeListener((i,s)=>yw(e.remoteStore,s)),t._onlineComponents=e}function ux(t){return t.name==="FirebaseError"?t.code===x.FAILED_PRECONDITION||t.code===x.UNIMPLEMENTED:!(typeof DOMException<"u"&&t instanceof DOMException)||t.code===22||t.code===20||t.code===11}async function cx(t){if(!t._offlineComponents)if(t._uninitializedComponentsProvider){N("FirestoreClient","Using user provided OfflineComponentProvider");try{await bf(t,t._uninitializedComponentsProvider._offline)}catch(e){let n=e;if(!ux(n))throw n;zi("Error using user provided cache. Falling back to memory cache: "+n),await bf(t,new ku)}}else N("FirestoreClient","Using default OfflineComponentProvider"),await bf(t,new ku);return t._offlineComponents}async function hx(t){return t._onlineComponents||(t._uninitializedComponentsProvider?(N("FirestoreClient","Using user provided OnlineComponentProvider"),await ww(t,t._uninitializedComponentsProvider._online)):(N("FirestoreClient","Using default OnlineComponentProvider"),await ww(t,new Wp))),t._onlineComponents}async function dx(t){let e=await hx(t),n=e.eventManager;return n.onListen=tx.bind(null,e.syncEngine),n.onUnlisten=rx.bind(null,e.syncEngine),n}function fx(t,e,n={}){let r=new En;return t.asyncQueue.enqueueAndForget(async()=>function(i,s,o,a,l){let u=new Gp({next:h=>{s.enqueueAndForget(()=>YI(i,c));let p=h.docs.has(o);!p&&h.fromCache?l.reject(new O(x.UNAVAILABLE,"Failed to get document because the client is offline.")):p&&h.fromCache&&a&&a.source==="server"?l.reject(new O(x.UNAVAILABLE,'Failed to get document from server. (However, this document does exist in the local cache. Run again without setting source to "server" to retrieve the cached document.)')):l.resolve(h)},error:h=>l.reject(h)}),c=new Up(dm(o.path),u,{includeMetadataChanges:!0,Uu:!0});return ZI(i,c)}(await dx(t),t.asyncQueue,e,n,r)),r.promise}var Ew=new Map;function px(t,e,n){if(!n)throw new O(x.INVALID_ARGUMENT,`Function ${t}() cannot be called with an empty ${e}.`)}function mx(t,e,n,r){if(e===!0&&r===!0)throw new O(x.INVALID_ARGUMENT,`${t} and ${n} cannot be used together.`)}function Sw(t){if(!_.isDocumentKey(t))throw new O(x.INVALID_ARGUMENT,`Invalid document reference. Document references must have an even number of segments, but ${t} has ${t.length}.`)}function gx(t){if(t===void 0)return"undefined";if(t===null)return"null";if(typeof t=="string")return t.length>20&&(t=`${t.substring(0,20)}...`),JSON.stringify(t);if(typeof t=="number"||typeof t=="boolean")return""+t;if(typeof t=="object"){if(t instanceof Array)return"an array";{let e=function(n){return n.constructor?n.constructor.name:null}(t);return e?`a custom ${e} object`:"an object"}}return typeof t=="function"?"a function":z()}function Zp(t,e){if("_delegate"in t&&(t=t._delegate),!(t instanceof e)){if(e.name===t.constructor.name)throw new O(x.INVALID_ARGUMENT,"Type does not match the expected instance. Did you pass a reference from a different Firestore SDK?");{let n=gx(t);throw new O(x.INVALID_ARGUMENT,`Expected type '${e.name}', but it was: ${n}`)}}return t}var Du=class{constructor(e){var n;if(e.host===void 0){if(e.ssl!==void 0)throw new O(x.INVALID_ARGUMENT,"Can't provide ssl option if host option is not set");this.host="firestore.googleapis.com",this.ssl=!0}else this.host=e.host,this.ssl=(n=e.ssl)===null||n===void 0||n;if(this.credentials=e.credentials,this.ignoreUndefinedProperties=!!e.ignoreUndefinedProperties,this.cache=e.localCache,e.cacheSizeBytes===void 0)this.cacheSizeBytes=41943040;else{if(e.cacheSizeBytes!==-1&&e.cacheSizeBytes<1048576)throw new O(x.INVALID_ARGUMENT,"cacheSizeBytes must be at least 1048576");this.cacheSizeBytes=e.cacheSizeBytes}mx("experimentalForceLongPolling",e.experimentalForceLongPolling,"experimentalAutoDetectLongPolling",e.experimentalAutoDetectLongPolling),this.experimentalForceLongPolling=!!e.experimentalForceLongPolling,this.experimentalForceLongPolling?this.experimentalAutoDetectLongPolling=!1:e.experimentalAutoDetectLongPolling===void 0?this.experimentalAutoDetectLongPolling=!1:this.experimentalAutoDetectLongPolling=!!e.experimentalAutoDetectLongPolling,this.useFetchStreams=!!e.useFetchStreams}isEqual(e){return this.host===e.host&&this.ssl===e.ssl&&this.credentials===e.credentials&&this.cacheSizeBytes===e.cacheSizeBytes&&this.experimentalForceLongPolling===e.experimentalForceLongPolling&&this.experimentalAutoDetectLongPolling===e.experimentalAutoDetectLongPolling&&this.ignoreUndefinedProperties===e.ignoreUndefinedProperties&&this.useFetchStreams===e.useFetchStreams}};var zo=class{constructor(e,n,r,i){this._authCredentials=e,this._appCheckCredentials=n,this._databaseId=r,this._app=i,this.type="firestore-lite",this._persistenceKey="(lite)",this._settings=new Du({}),this._settingsFrozen=!1}get app(){if(!this._app)throw new O(x.FAILED_PRECONDITION,"Firestore was not initialized using the Firebase SDK. 'app' is not available");return this._app}get _initialized(){return this._settingsFrozen}get _terminated(){return this._terminateTask!==void 0}_setSettings(e){if(this._settingsFrozen)throw new O(x.FAILED_PRECONDITION,"Firestore has already been started and its settings can no longer be changed. You can only modify settings before calling any other methods on a Firestore object.");this._settings=new Du(e),e.credentials!==void 0&&(this._authCredentials=function(n){if(!n)return new Rf;switch(n.type){case"firstParty":return new qf(n.sessionIndex||"0",n.iamToken||null,n.authTokenFactory||null);case"provider":return n.client;default:throw new O(x.INVALID_ARGUMENT,"makeAuthCredentialsProvider failed due to invalid credential type")}}(e.credentials))}_getSettings(){return this._settings}_freezeSettings(){return this._settingsFrozen=!0,this._settings}_delete(){return this._terminateTask||(this._terminateTask=this._terminate()),this._terminateTask}toJSON(){return{app:this._app,databaseId:this._databaseId,settings:this._settings}}_terminate(){return function(e){let n=Ew.get(e);n&&(N("ComponentProvider","Removing Datastore"),Ew.delete(e),n.terminate())}(this),Promise.resolve()}};function yx(t,e,n,r={}){var i;let s=(t=Zp(t,zo))._getSettings();if(s.host!=="firestore.googleapis.com"&&s.host!==e&&zi("Host has been set in both settings() and useEmulator(), emulator host will be used"),t._setSettings(Object.assign(Object.assign({},s),{host:`${e}:${n}`,ssl:!1})),r.mockUserToken){let o,a;if(typeof r.mockUserToken=="string")o=r.mockUserToken,a=Ce.MOCK_USER;else{o=aA(r.mockUserToken,(i=t._app)===null||i===void 0?void 0:i.options.projectId);let l=r.mockUserToken.sub||r.mockUserToken.user_id;if(!l)throw new O(x.INVALID_ARGUMENT,"mockUserToken must contain 'sub' or 'user_id' field!");a=new Ce(l)}t._authCredentials=new zf(new hu(o,a))}}var Bt=class{constructor(e,n,r){this.converter=n,this._key=r,this.type="document",this.firestore=e}get _path(){return this._key.path}get id(){return this._key.path.lastSegment()}get path(){return this._key.path.canonicalString()}get parent(){return new Kr(this.firestore,this.converter,this._key.path.popLast())}withConverter(e){return new Bt(this.firestore,e,this._key)}},Fo=class{constructor(e,n,r){this.converter=n,this._query=r,this.type="query",this.firestore=e}withConverter(e){return new Fo(this.firestore,e,this._query)}},Kr=class extends Fo{constructor(e,n,r){super(e,n,dm(r)),this._path=r,this.type="collection"}get id(){return this._query.path.lastSegment()}get path(){return this._query.path.canonicalString()}get parent(){let e=this._path.popLast();return e.isEmpty()?null:new Bt(this.firestore,null,new _(e))}withConverter(e){return new Kr(this.firestore,e,this._path)}};function n2(t,e,...n){if(t=uA(t),arguments.length===1&&(e=du.A()),px("doc","path",e),t instanceof zo){let r=se.fromString(e,...n);return Sw(r),new Bt(t,null,new _(r))}{if(!(t instanceof Bt||t instanceof Kr))throw new O(x.INVALID_ARGUMENT,"Expected first argument to collection() to be a CollectionReference, a DocumentReference or FirebaseFirestore");let r=t._path.child(se.fromString(e,...n));return Sw(r),new Bt(t.firestore,t instanceof Kr?t.converter:null,new _(r))}}var Yp=class{constructor(){this.Kc=Promise.resolve(),this.Gc=[],this.Qc=!1,this.jc=[],this.zc=null,this.Wc=!1,this.Hc=!1,this.Jc=[],this.Lo=new Iu(this,"async_queue_retry"),this.Yc=()=>{let n=Mf();n&&N("AsyncQueue","Visibility state changed to "+n.visibilityState),this.Lo.ko()};let e=Mf();e&&typeof e.addEventListener=="function"&&e.addEventListener("visibilitychange",this.Yc)}get isShuttingDown(){return this.Qc}enqueueAndForget(e){this.enqueue(e)}enqueueAndForgetEvenWhileRestricted(e){this.Xc(),this.Zc(e)}enterRestrictedMode(e){if(!this.Qc){this.Qc=!0,this.Hc=e||!1;let n=Mf();n&&typeof n.removeEventListener=="function"&&n.removeEventListener("visibilitychange",this.Yc)}}enqueue(e){if(this.Xc(),this.Qc)return new Promise(()=>{});let n=new En;return this.Zc(()=>this.Qc&&this.Hc?Promise.resolve():(e().then(n.resolve,n.reject),n.promise)).then(()=>n.promise)}enqueueRetryable(e){this.enqueueAndForget(()=>(this.Gc.push(e),this.ta()))}async ta(){if(this.Gc.length!==0){try{await this.Gc[0](),this.Gc.shift(),this.Lo.reset()}catch(e){if(!Bo(e))throw e;N("AsyncQueue","Operation failed with retryable error: "+e)}this.Gc.length>0&&this.Lo.xo(()=>this.ta())}}Zc(e){let n=this.Kc.then(()=>(this.Wc=!0,e().catch(r=>{this.zc=r,this.Wc=!1;let i=function(s){let o=s.message||"";return s.stack&&(o=s.stack.includes(s.message)?s.stack:s.message+`
`+s.stack),o}(r);throw In("INTERNAL UNHANDLED ERROR: ",i),r}).then(r=>(this.Wc=!1,r))));return this.Kc=n,n}enqueueAfterDelay(e,n,r){this.Xc(),this.Jc.indexOf(e)>-1&&(n=0);let i=Ro.createAndSchedule(this,e,n,r,s=>this.ea(s));return this.jc.push(i),i}Xc(){this.zc&&z()}verifyOperationInProgress(){}async na(){let e;do e=this.Kc,await e;while(e!==this.Kc)}sa(e){for(let n of this.jc)if(n.timerId===e)return!0;return!1}ia(e){return this.na().then(()=>{this.jc.sort((n,r)=>n.targetTimeMs-r.targetTimeMs);for(let n of this.jc)if(n.skipDelay(),e!=="all"&&n.timerId===e)break;return this.na()})}ra(e){this.Jc.push(e)}ea(e){let n=this.jc.indexOf(e);this.jc.splice(n,1)}};var Nu=class extends zo{constructor(e,n,r,i){super(e,n,r,i),this.type="firestore",this._queue=new Yp,this._persistenceKey=i?.name||"[DEFAULT]"}_terminate(){return this._firestoreClient||i2(this),this._firestoreClient.terminate()}};function r2(t,e){let n=typeof t=="object"?t:IA(),r=typeof t=="string"?t:e||"(default)",i=EA(n,"firestore").getImmediate({identifier:r});if(!i._initialized){let s=sA("firestore");s&&yx(i,...s)}return i}function Ax(t){return t._firestoreClient||i2(t),t._firestoreClient.verifyNotTerminated(),t._firestoreClient}function i2(t){var e,n,r;let i=t._freezeSettings(),s=function(o,a,l,u){return new Hf(o,a,l,u.host,u.ssl,u.experimentalForceLongPolling,u.experimentalAutoDetectLongPolling,u.useFetchStreams)}(t._databaseId,((e=t._app)===null||e===void 0?void 0:e.options.appId)||"",t._persistenceKey,i);t._firestoreClient=new Jp(t._authCredentials,t._appCheckCredentials,t._queue,s),!((n=i.cache)===null||n===void 0)&&n._offlineComponentProvider&&(!((r=i.cache)===null||r===void 0)&&r._onlineComponentProvider)&&(t._firestoreClient._uninitializedComponentsProvider={_offlineKind:i.cache.kind,_offline:i.cache._offlineComponentProvider,_online:i.cache._onlineComponentProvider})}var Wi=class{constructor(e){this._byteString=e}static fromBase64String(e){try{return new Wi(Ne.fromBase64String(e))}catch(n){throw new O(x.INVALID_ARGUMENT,"Failed to construct data from Base64 string: "+n)}}static fromUint8Array(e){return new Wi(Ne.fromUint8Array(e))}toBase64(){return this._byteString.toBase64()}toUint8Array(){return this._byteString.toUint8Array()}toString(){return"Bytes(base64: "+this.toBase64()+")"}isEqual(e){return this._byteString.isEqual(e._byteString)}};var Pu=class{constructor(...e){for(let n=0;n<e.length;++n)if(e[n].length===0)throw new O(x.INVALID_ARGUMENT,"Invalid field name at argument $(i + 1). Field names must not be empty.");this._internalPath=new Qe(e)}isEqual(e){return this._internalPath.isEqual(e._internalPath)}};var $p=class{constructor(e,n){if(!isFinite(e)||e<-90||e>90)throw new O(x.INVALID_ARGUMENT,"Latitude must be a number between -90 and 90, but was: "+e);if(!isFinite(n)||n<-180||n>180)throw new O(x.INVALID_ARGUMENT,"Longitude must be a number between -180 and 180, but was: "+n);this._lat=e,this._long=n}get latitude(){return this._lat}get longitude(){return this._long}isEqual(e){return this._lat===e._lat&&this._long===e._long}toJSON(){return{latitude:this._lat,longitude:this._long}}_compareTo(e){return X(this._lat,e._lat)||X(this._long,e._long)}};var vx=new RegExp("[~\\*/\\[\\]]");function wx(t,e,n){if(e.search(vx)>=0)throw Iw(`Invalid field path (${e}). Paths must not contain '~', '*', '/', '[', or ']'`,t,!1,void 0,n);try{return new Pu(...e.split("."))._internalPath}catch{throw Iw(`Invalid field path (${e}). Paths must not be empty, begin with '.', end with '.', or contain '..'`,t,!1,void 0,n)}}function Iw(t,e,n,r,i){let s=r&&!r.isEmpty(),o=i!==void 0,a=`Function ${e}() called with invalid data`;n&&(a+=" (via `toFirestore()`)"),a+=". ";let l="";return(s||o)&&(l+=" (found",s&&(l+=` in field ${r}`),o&&(l+=` in document ${i}`),l+=")"),new O(x.INVALID_ARGUMENT,a+t+l)}var _u=class{constructor(e,n,r,i,s){this._firestore=e,this._userDataWriter=n,this._key=r,this._document=i,this._converter=s}get id(){return this._key.path.lastSegment()}get ref(){return new Bt(this._firestore,this._converter,this._key)}exists(){return this._document!==null}data(){if(this._document){if(this._converter){let e=new em(this._firestore,this._userDataWriter,this._key,this._document,null);return this._converter.fromFirestore(e)}return this._userDataWriter.convertValue(this._document.data.value)}}get(e){if(this._document){let n=this._document.data.field(s2("DocumentSnapshot.get",e));if(n!==null)return this._userDataWriter.convertValue(n)}}},em=class extends _u{data(){return super.data()}};function s2(t,e){return typeof e=="string"?wx(t,e):e instanceof Pu?e._internalPath:e._delegate._internalPath}var tm=class{convertValue(e,n="none"){switch(Qr(e)){case 0:return null;case 1:return e.booleanValue;case 2:return de(e.integerValue||e.doubleValue);case 3:return this.convertTimestamp(e.timestampValue);case 4:return this.convertServerTimestamp(e,n);case 5:return e.stringValue;case 6:return this.convertBytes(ir(e.bytesValue));case 7:return this.convertReference(e.referenceValue);case 8:return this.convertGeoPoint(e.geoPointValue);case 9:return this.convertArray(e.arrayValue,n);case 10:return this.convertObject(e.mapValue,n);default:throw z()}}convertObject(e,n){return this.convertObjectMap(e.fields,n)}convertObjectMap(e,n="none"){let r={};return Mu(e,(i,s)=>{r[i]=this.convertValue(s,n)}),r}convertGeoPoint(e){return new $p(de(e.latitude),de(e.longitude))}convertArray(e,n){return(e.values||[]).map(r=>this.convertValue(r,n))}convertServerTimestamp(e,n){switch(n){case"previous":let r=lm(e);return r==null?null:this.convertValue(r,n);case"estimate":return this.convertTimestamp(To(e));default:return null}}convertTimestamp(e){let n=rr(e);return new He(n.seconds,n.nanos)}convertDocumentKey(e,n){let r=se.fromString(e);Ee(Qw(r));let i=new jr(r.get(1),r.get(3)),s=new _(r.popFirst(5));return i.isEqual(n)||In(`Document ${s} contains a document reference within a different database (${i.projectId}/${i.database}) which is not supported. It will be treated as a reference in the current database (${n.projectId}/${n.database}) instead.`),s}};var nm=class{constructor(e,n){this.hasPendingWrites=e,this.fromCache=n}isEqual(e){return this.hasPendingWrites===e.hasPendingWrites&&this.fromCache===e.fromCache}},Ou=class extends _u{constructor(e,n,r,i,s,o){super(e,n,r,i,o),this._firestore=e,this._firestoreImpl=e,this.metadata=s}exists(){return super.exists()}data(e={}){if(this._document){if(this._converter){let n=new rm(this._firestore,this._userDataWriter,this._key,this._document,this.metadata,null);return this._converter.fromFirestore(n,e)}return this._userDataWriter.convertValue(this._document.data.value,e.serverTimestamps)}}get(e,n={}){if(this._document){let r=this._document.data.field(s2("DocumentSnapshot.get",e));if(r!==null)return this._userDataWriter.convertValue(r,n.serverTimestamps)}}},rm=class extends Ou{data(e={}){return super.data(e)}};function o2(t){t=Zp(t,Bt);let e=Zp(t.firestore,Nu);return fx(Ax(e),t._key).then(n=>Ex(e,t,n))}var im=class extends tm{constructor(e){super(),this.firestore=e}convertBytes(e){return new Wi(e)}convertReference(e){let n=this.convertDocumentKey(e,this.firestore._databaseId);return new Bt(this.firestore,null,n)}};function Ex(t,e,n){let r=n.docs.get(e._key),i=new im(t);return new Ou(t,i,e._key,r,new nm(n.hasPendingWrites,n.fromCache),e.converter)}(function(t,e=!0){(function(n){Gi=n})(SA),Zs(new yn("firestore",(n,{instanceIdentifier:r,options:i})=>{let s=n.getProvider("app").getImmediate(),o=new Nu(new Ff(n.getProvider("auth-internal")),new Uf(n.getProvider("app-check-internal")),function(a,l){if(!Object.prototype.hasOwnProperty.apply(a.options,["projectId"]))throw new O(x.INVALID_ARGUMENT,'"projectId" not provided in firebase.initializeApp.');return new jr(a.options.projectId,l)}(s,r),s);return i=Object.assign({useFetchStreams:e},i),o._setSettings(i),o},"PUBLIC").setMultipleInstances(!0)),$n(Jv,"3.11.0",t),$n(Jv,"3.11.0","esm2017")})();var Sx=[];gn.get("logs").then(t=>{t&&(Sx=t)});var Ix;gn.get("debug").then(t=>Ix=!!t);var xx={apiKey:"AIzaSyBb6O-EVKWYnTYooRfmDSa7xaJX1LWNNxk",authDomain:"wordkache.firebaseapp.com",projectId:"wordkache",storageBucket:"wordkache.appspot.com",messagingSenderId:"673136087991",appId:"1:673136087991:web:31bc60b43177f991c64e32",measurementId:"G-FL6DD4ZEQZ"},Tx=r2(Fd(xx));var a2=(t,e)=>qu(void 0,null,function*(){let n=yield o2(n2(Tx,t,e));return n.exists()?n.data():void 0});var L=F(te()),Tn=({children:t})=>(0,L.jsx)("div",{className:Pr.hotKeyContainer,children:t}),Cx=()=>{let[t,e]=(0,ur.useState)(),n=Xs("userId",void 0);return(0,ur.useEffect)(()=>{n&&a2("forms",n).then(r=>{r&&e(r)})},[n]),{formStatus:t}},u2=({numCardsHidden:t})=>{let[e,n]=(0,ur.useState)(!1),{formStatus:r}=Cx(),i=(0,ur.useRef)(null);(0,ur.useEffect)(()=>{if(!e)return;let o=a=>{var l;(l=i.current)!=null&&l.contains(a.target)||n(!1)};return window.addEventListener("click",o),()=>window.removeEventListener("click",o)},[e]);let s=30;return(0,L.jsxs)(L.Fragment,{children:[r&&(0,L.jsx)(G,{type:"paragraph",style:{padding:"10px"},children:r.done?"Thanks for completing the form! You'll be able to see your hidden cards soon.":(0,L.jsxs)(L.Fragment,{children:["You have"," ",(0,L.jsx)("a",{href:r.url,target:"_blank",rel:"noreferrer",style:{color:"lightblue"},children:"a form"})," ","available! It should only take 5 minutes to complete, and you'll get to see your hidden cards afterwards!"]})}),(0,L.jsxs)(G,{type:"subheading",className:Pr.container,children:[(0,L.jsxs)(Jn,{onClick:o=>{n(!e),o.stopPropagation()},style:{padding:"10px",width:"100%"},children:[(0,L.jsx)(mn,{name:"help"})," ",t>0?`${t} Card${t!==1?"s":""} Hidden`:"Info"]}),(0,L.jsxs)("div",{className:(0,l2.default)(Pr.textBox,e?Pr.open:Pr.closed),ref:i,children:[(0,L.jsx)(G,{type:"heading",lineHeight:2,bold:!0,children:"You're using a Beta version!"}),(0,L.jsxs)(G,{type:"paragraph",children:["For statistical analysis, around 50% of your collected cards will be temporarily hidden. However, once you've accumulated 30 hidden cards, you'll be able to see all subsequent translations. (",t>=s?(0,L.jsx)(L.Fragment,{children:"You've reached it!"}):(0,L.jsxs)(L.Fragment,{children:["You're currently"," ",(0,L.jsxs)("b",{children:[Math.round(t/s*100),"%"]})," ","of the way there."]}),")"]}),(0,L.jsx)(G,{type:"heading",lineHeight:2,style:{marginTop:"15px"},bold:!0,children:"Why aren't my translations being saved?"}),(0,L.jsx)(G,{type:"paragraph",children:"We currently only support Google Translate and DeepL. Make sure that if you're using Google Translate, you're on translate.google.com and not the embedded Google Search one. If it's still not working, leave a comment in our feedback form."}),(0,L.jsx)(G,{type:"heading",lineHeight:2,style:{marginTop:"15px"},bold:!0,children:"I have feedback/questions!"}),(0,L.jsxs)(G,{type:"paragraph",children:["We're actively monitoring all responses on"," ",(0,L.jsx)("a",{href:"https://forms.gle/bkos6SGzr6Jeo33n6",target:"_blank",rel:"noreferrer",children:"this form"}),"."]}),(0,L.jsx)(G,{type:"heading",lineHeight:2,style:{marginTop:"15px"},bold:!0,children:"Hotkeys"}),(0,L.jsx)(G,{type:"paragraph",children:(0,L.jsxs)("div",{className:Pr.shortcutTable,children:[(0,L.jsxs)("div",{children:[(0,L.jsx)(Tn,{children:"Shift"})," + ",(0,L.jsx)(Tn,{children:"Click"})]}),(0,L.jsx)("div",{children:"Range Selection"}),(0,L.jsxs)("div",{children:[(0,L.jsx)(Tn,{children:"^|\u2318"})," + ",(0,L.jsx)(Tn,{children:"Click"})]}),(0,L.jsx)("div",{children:"Select Card"}),(0,L.jsxs)("div",{children:[(0,L.jsx)(Tn,{children:"^|\u2318"})," + ",(0,L.jsx)(Tn,{children:"A"})]}),(0,L.jsx)("div",{children:"Select All"}),(0,L.jsxs)("div",{children:[(0,L.jsx)(Tn,{children:"^|\u2318"})," + ",(0,L.jsx)(Tn,{children:"C"})]}),(0,L.jsx)("div",{children:"Copy Selected Cards"}),(0,L.jsx)("div",{children:(0,L.jsx)(Tn,{children:"esc"})}),(0,L.jsx)("div",{children:"Cancel Selection"})]})})]})]})]})};var Cn=F(it());var c2="b12e7d70a64f80ae83dadf013f72d908f9ac6746c7d13f0629055af659eeb539",kx=`._folderName_152dt_1 {
  display: flex;
  align-items: center;
  padding: 2.5px 0;
  color: var(--light-2);

  transition: 0.2s color, 0.2s font-weight, 0.1s background-color;
}

._folderName_152dt_1:hover {
  background-color: var(--dark-2);
  cursor: pointer;
}
._selectedFolderName_152dt_14 {
  color: var(--light-1);
  font-weight: bold;
}
._children_152dt_19 {
  overflow: hidden;
  transition: 0.2s height;
}
`;(function(){if(!(typeof document>"u")&&!document.getElementById(c2)){var t=document.createElement("style");t.id=c2,t.textContent=kx,document.head.appendChild(t)}})();var Uo={folderName:"_folderName_152dt_1",selectedFolderName:"_selectedFolderName_152dt_14 _folderName_152dt_1",children:"_children_152dt_19"};var cr=F(te()),Am=({folders:t,depth:e=0,onHeightChange:n})=>{var p,g;let r=(0,Cn.useRef)(null),{activeFolder:i,setActiveFolder:s}=Sl(),[o,a]=(0,Cn.useState)(0),[l,u]=(0,Cn.useState)(!!t.open),c=i.id===t.id,h=(0,Cn.useCallback)(y=>{a(A=>A+y),n&&n(y)},[n]);return(0,Cn.useLayoutEffect)(()=>{setTimeout(()=>{let y=r.current;y&&a(y.scrollHeight)},500)},[r]),(0,cr.jsxs)("li",{className:Uo.folder,children:[(0,cr.jsxs)(G,{type:"subheading",className:c?Uo.selectedFolderName:Uo.folderName,style:{paddingLeft:e*12},noSelect:!0,onMouseDown:()=>{s(t)},children:[(0,cr.jsx)(mn,{name:"expand_more",style:{opacity:(p=t.subFolders)!=null&&p.length?1:0,transform:`rotate(${l?0:-90}deg)`,transition:".2s transform",pointerEvents:(g=t.subFolders)!=null&&g.length?"auto":"none"},onMouseDown:y=>{let A=!l;u(A),n&&n((A?1:-1)*o),y.stopPropagation()}}),(0,cr.jsx)(G,{noWrap:!0,children:t.name})]}),t.subFolders&&(0,cr.jsx)("ul",{ref:r,style:{height:l?o===0?"auto":o:0},className:Uo.children,children:t.subFolders.map((y,A)=>(0,cr.jsx)(Am,{folders:y,depth:e+1,onHeightChange:h},y.id))})]})};var h2="55d800d772e7eea397ed1d4480a3a529f15cd8bdf05ea577f20305c276ae5801",Dx=`._container_102e7_1 {
  position: relative;
  overflow: scroll;
  flex-grow: 1;
}

._title_102e7_7 {
  display: flex;
  align-items: center;
  gap: 5px;
  border-bottom: 2px solid var(--light-1);
  margin-bottom: 5px;
  margin-left: 10px;
}
`;(function(){if(!(typeof document>"u")&&!document.getElementById(h2)){var t=document.createElement("style");t.id=h2,t.textContent=Dx,document.head.appendChild(t)}})();var vm={container:"_container_102e7_1",title:"_title_102e7_7"};var Zi=F(te()),Nx=t=>{var i;let e=new Map,n=[];for(let s of t)s.parentId?(e.has(s.parentId)||e.set(s.parentId,[]),(i=e.get(s.parentId))==null||i.push(s)):n.push(Ke({},s));let r=s=>(e.has(s.id)&&(s.subFolders=e.get(s.id).map(o=>r({id:o.id,name:o.name}))),s);return n.map(s=>r(s))},d2=({folders:t})=>{let e=[wm,...Nx(t)];return(0,Zi.jsxs)("div",{className:vm.container,children:[(0,Zi.jsxs)(G,{type:"heading",bold:!0,className:vm.title,children:[(0,Zi.jsx)(mn,{name:"folder"}),"Folders"]}),e.map(n=>(0,Zi.jsx)(Am,{folders:n},n.id))]})};var f2="./logo-XYHG4YFW.svg";var p2=(t=21)=>crypto.getRandomValues(new Uint8Array(t)).reduce((e,n)=>(n&=63,n<36?e+=n.toString(36):n<62?e+=(n-26).toString(36).toUpperCase():n>62?e+="-":e+="_",e),"");var hr=F(te()),g2=(0,dr.createContext)({activeFolder:void 0,setActiveFolder:void 0}),Sl=()=>{let{activeFolder:t,setActiveFolder:e}=(0,dr.useContext)(g2);if(!t||!e)throw new Error("You've used FolderContext outside of its designated scope!");return{activeFolder:t,setActiveFolder:e}},wm={name:"Just Collected",id:"root"},m2=[];function _x(){let t=Xs("cards",m2),e=Xs("folders",m2),[n,r]=(0,dr.useState)(wm);(0,dr.useEffect)(()=>{e&&e.length===0&&gn.setPair("folders",[{name:"Saved",id:p2()}])},[e]);let i=(a,l)=>{if(!t||!e)return;let u=[...t];for(let c of u)a.includes(c.id)&&(c.location=l!=null?l:e[0].id);gn.setPair("cards",u)},s=a=>{if(!t)return;let l=[...t];for(let u of t)a.includes(u.id)&&(u.deleted=!0);gn.setPair("cards",l)},o=t==null?void 0:t.filter(a=>a.location===n.id&&!a.hidden&&!a.deleted);return(0,hr.jsxs)(g2.Provider,{value:{activeFolder:n,setActiveFolder:r},children:[(0,hr.jsxs)("div",{className:od.menu,children:[(0,hr.jsx)("img",{src:f2,className:od.logo,alt:"logo"}),(0,hr.jsx)(d2,{folders:e||[]}),(0,hr.jsx)(u2,{numCardsHidden:t?t.reduce((a,l)=>a+ +!!l.hidden,0):0})]}),o&&(0,hr.jsx)(Y1,{cards:o,moveCards:i,deleteCards:s},n.id)]})}var y2=_x;var Em=F(te()),Ox=v2.default.createRoot(document.getElementById("root"));Ox.render((0,Em.jsx)(A2.default.StrictMode,{children:(0,Em.jsx)(y2,{})}));})();
/*! Bundled license information:

react/cjs/react.production.min.js:
  (**
   * @license React
   * react.production.min.js
   *
   * Copyright (c) Facebook, Inc. and its affiliates.
   *
   * This source code is licensed under the MIT license found in the
   * LICENSE file in the root directory of this source tree.
   *)

scheduler/cjs/scheduler.production.min.js:
  (**
   * @license React
   * scheduler.production.min.js
   *
   * Copyright (c) Facebook, Inc. and its affiliates.
   *
   * This source code is licensed under the MIT license found in the
   * LICENSE file in the root directory of this source tree.
   *)

react-dom/cjs/react-dom.production.min.js:
  (**
   * @license React
   * react-dom.production.min.js
   *
   * Copyright (c) Facebook, Inc. and its affiliates.
   *
   * This source code is licensed under the MIT license found in the
   * LICENSE file in the root directory of this source tree.
   *)

classnames/index.js:
  (*!
  	Copyright (c) 2018 Jed Watson.
  	Licensed under the MIT License (MIT), see
  	http://jedwatson.github.io/classnames
  *)

react/cjs/react-jsx-runtime.production.min.js:
  (**
   * @license React
   * react-jsx-runtime.production.min.js
   *
   * Copyright (c) Facebook, Inc. and its affiliates.
   *
   * This source code is licensed under the MIT license found in the
   * LICENSE file in the root directory of this source tree.
   *)

classnames/bind.js:
  (*!
  	Copyright (c) 2018 Jed Watson.
  	Licensed under the MIT License (MIT), see
  	http://jedwatson.github.io/classnames
  *)

@firebase/util/dist/index.esm2017.js:
  (**
   * @license
   * Copyright 2017 Google LLC
   *
   * Licensed under the Apache License, Version 2.0 (the "License");
   * you may not use this file except in compliance with the License.
   * You may obtain a copy of the License at
   *
   *   http://www.apache.org/licenses/LICENSE-2.0
   *
   * Unless required by applicable law or agreed to in writing, software
   * distributed under the License is distributed on an "AS IS" BASIS,
   * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
   * See the License for the specific language governing permissions and
   * limitations under the License.
   *)

@firebase/util/dist/index.esm2017.js:
  (**
   * @license
   * Copyright 2017 Google LLC
   *
   * Licensed under the Apache License, Version 2.0 (the "License");
   * you may not use this file except in compliance with the License.
   * You may obtain a copy of the License at
   *
   *   http://www.apache.org/licenses/LICENSE-2.0
   *
   * Unless required by applicable law or agreed to in writing, software
   * distributed under the License is distributed on an "AS IS" BASIS,
   * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
   * See the License for the specific language governing permissions and
   * limitations under the License.
   *)

@firebase/util/dist/index.esm2017.js:
  (**
   * @license
   * Copyright 2017 Google LLC
   *
   * Licensed under the Apache License, Version 2.0 (the "License");
   * you may not use this file except in compliance with the License.
   * You may obtain a copy of the License at
   *
   *   http://www.apache.org/licenses/LICENSE-2.0
   *
   * Unless required by applicable law or agreed to in writing, software
   * distributed under the License is distributed on an "AS IS" BASIS,
   * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
   * See the License for the specific language governing permissions and
   * limitations under the License.
   *)

@firebase/util/dist/index.esm2017.js:
  (**
   * @license
   * Copyright 2022 Google LLC
   *
   * Licensed under the Apache License, Version 2.0 (the "License");
   * you may not use this file except in compliance with the License.
   * You may obtain a copy of the License at
   *
   *   http://www.apache.org/licenses/LICENSE-2.0
   *
   * Unless required by applicable law or agreed to in writing, software
   * distributed under the License is distributed on an "AS IS" BASIS,
   * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
   * See the License for the specific language governing permissions and
   * limitations under the License.
   *)

@firebase/util/dist/index.esm2017.js:
  (**
   * @license
   * Copyright 2017 Google LLC
   *
   * Licensed under the Apache License, Version 2.0 (the "License");
   * you may not use this file except in compliance with the License.
   * You may obtain a copy of the License at
   *
   *   http://www.apache.org/licenses/LICENSE-2.0
   *
   * Unless required by applicable law or agreed to in writing, software
   * distributed under the License is distributed on an "AS IS" BASIS,
   * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
   * See the License for the specific language governing permissions and
   * limitations under the License.
   *)
  (**
   * @license
   * Copyright 2021 Google LLC
   *
   * Licensed under the Apache License, Version 2.0 (the "License");
   * you may not use this file except in compliance with the License.
   * You may obtain a copy of the License at
   *
   *   http://www.apache.org/licenses/LICENSE-2.0
   *
   * Unless required by applicable law or agreed to in writing, software
   * distributed under the License is distributed on an "AS IS" BASIS,
   * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
   * See the License for the specific language governing permissions and
   * limitations under the License.
   *)

@firebase/util/dist/index.esm2017.js:
  (**
   * @license
   * Copyright 2017 Google LLC
   *
   * Licensed under the Apache License, Version 2.0 (the "License");
   * you may not use this file except in compliance with the License.
   * You may obtain a copy of the License at
   *
   *   http://www.apache.org/licenses/LICENSE-2.0
   *
   * Unless required by applicable law or agreed to in writing, software
   * distributed under the License is distributed on an "AS IS" BASIS,
   * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
   * See the License for the specific language governing permissions and
   * limitations under the License.
   *)

@firebase/util/dist/index.esm2017.js:
  (**
   * @license
   * Copyright 2017 Google LLC
   *
   * Licensed under the Apache License, Version 2.0 (the "License");
   * you may not use this file except in compliance with the License.
   * You may obtain a copy of the License at
   *
   *   http://www.apache.org/licenses/LICENSE-2.0
   *
   * Unless required by applicable law or agreed to in writing, software
   * distributed under the License is distributed on an "AS IS" BASIS,
   * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
   * See the License for the specific language governing permissions and
   * limitations under the License.
   *)

@firebase/util/dist/index.esm2017.js:
  (**
   * @license
   * Copyright 2017 Google LLC
   *
   * Licensed under the Apache License, Version 2.0 (the "License");
   * you may not use this file except in compliance with the License.
   * You may obtain a copy of the License at
   *
   *   http://www.apache.org/licenses/LICENSE-2.0
   *
   * Unless required by applicable law or agreed to in writing, software
   * distributed under the License is distributed on an "AS IS" BASIS,
   * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
   * See the License for the specific language governing permissions and
   * limitations under the License.
   *)

@firebase/util/dist/index.esm2017.js:
  (**
   * @license
   * Copyright 2022 Google LLC
   *
   * Licensed under the Apache License, Version 2.0 (the "License");
   * you may not use this file except in compliance with the License.
   * You may obtain a copy of the License at
   *
   *   http://www.apache.org/licenses/LICENSE-2.0
   *
   * Unless required by applicable law or agreed to in writing, software
   * distributed under the License is distributed on an "AS IS" BASIS,
   * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
   * See the License for the specific language governing permissions and
   * limitations under the License.
   *)

@firebase/util/dist/index.esm2017.js:
  (**
   * @license
   * Copyright 2017 Google LLC
   *
   * Licensed under the Apache License, Version 2.0 (the "License");
   * you may not use this file except in compliance with the License.
   * You may obtain a copy of the License at
   *
   *   http://www.apache.org/licenses/LICENSE-2.0
   *
   * Unless required by applicable law or agreed to in writing, software
   * distributed under the License is distributed on an "AS IS" BASIS,
   * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
   * See the License for the specific language governing permissions and
   * limitations under the License.
   *)

@firebase/util/dist/index.esm2017.js:
  (**
   * @license
   * Copyright 2017 Google LLC
   *
   * Licensed under the Apache License, Version 2.0 (the "License");
   * you may not use this file except in compliance with the License.
   * You may obtain a copy of the License at
   *
   *   http://www.apache.org/licenses/LICENSE-2.0
   *
   * Unless required by applicable law or agreed to in writing, software
   * distributed under the License is distributed on an "AS IS" BASIS,
   * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
   * See the License for the specific language governing permissions and
   * limitations under the License.
   *)

@firebase/util/dist/index.esm2017.js:
  (**
   * @license
   * Copyright 2017 Google LLC
   *
   * Licensed under the Apache License, Version 2.0 (the "License");
   * you may not use this file except in compliance with the License.
   * You may obtain a copy of the License at
   *
   *   http://www.apache.org/licenses/LICENSE-2.0
   *
   * Unless required by applicable law or agreed to in writing, software
   * distributed under the License is distributed on an "AS IS" BASIS,
   * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
   * See the License for the specific language governing permissions and
   * limitations under the License.
   *)

@firebase/util/dist/index.esm2017.js:
  (**
   * @license
   * Copyright 2017 Google LLC
   *
   * Licensed under the Apache License, Version 2.0 (the "License");
   * you may not use this file except in compliance with the License.
   * You may obtain a copy of the License at
   *
   *   http://www.apache.org/licenses/LICENSE-2.0
   *
   * Unless required by applicable law or agreed to in writing, software
   * distributed under the License is distributed on an "AS IS" BASIS,
   * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
   * See the License for the specific language governing permissions and
   * limitations under the License.
   *)

@firebase/util/dist/index.esm2017.js:
  (**
   * @license
   * Copyright 2022 Google LLC
   *
   * Licensed under the Apache License, Version 2.0 (the "License");
   * you may not use this file except in compliance with the License.
   * You may obtain a copy of the License at
   *
   *   http://www.apache.org/licenses/LICENSE-2.0
   *
   * Unless required by applicable law or agreed to in writing, software
   * distributed under the License is distributed on an "AS IS" BASIS,
   * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
   * See the License for the specific language governing permissions and
   * limitations under the License.
   *)

@firebase/util/dist/index.esm2017.js:
  (**
   * @license
   * Copyright 2019 Google LLC
   *
   * Licensed under the Apache License, Version 2.0 (the "License");
   * you may not use this file except in compliance with the License.
   * You may obtain a copy of the License at
   *
   *   http://www.apache.org/licenses/LICENSE-2.0
   *
   * Unless required by applicable law or agreed to in writing, software
   * distributed under the License is distributed on an "AS IS" BASIS,
   * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
   * See the License for the specific language governing permissions and
   * limitations under the License.
   *)

@firebase/util/dist/index.esm2017.js:
  (**
   * @license
   * Copyright 2020 Google LLC
   *
   * Licensed under the Apache License, Version 2.0 (the "License");
   * you may not use this file except in compliance with the License.
   * You may obtain a copy of the License at
   *
   *   http://www.apache.org/licenses/LICENSE-2.0
   *
   * Unless required by applicable law or agreed to in writing, software
   * distributed under the License is distributed on an "AS IS" BASIS,
   * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
   * See the License for the specific language governing permissions and
   * limitations under the License.
   *)

@firebase/util/dist/index.esm2017.js:
  (**
   * @license
   * Copyright 2021 Google LLC
   *
   * Licensed under the Apache License, Version 2.0 (the "License");
   * you may not use this file except in compliance with the License.
   * You may obtain a copy of the License at
   *
   *   http://www.apache.org/licenses/LICENSE-2.0
   *
   * Unless required by applicable law or agreed to in writing, software
   * distributed under the License is distributed on an "AS IS" BASIS,
   * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
   * See the License for the specific language governing permissions and
   * limitations under the License.
   *)

@firebase/component/dist/esm/index.esm2017.js:
  (**
   * @license
   * Copyright 2019 Google LLC
   *
   * Licensed under the Apache License, Version 2.0 (the "License");
   * you may not use this file except in compliance with the License.
   * You may obtain a copy of the License at
   *
   *   http://www.apache.org/licenses/LICENSE-2.0
   *
   * Unless required by applicable law or agreed to in writing, software
   * distributed under the License is distributed on an "AS IS" BASIS,
   * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
   * See the License for the specific language governing permissions and
   * limitations under the License.
   *)

@firebase/logger/dist/esm/index.esm2017.js:
  (**
   * @license
   * Copyright 2017 Google LLC
   *
   * Licensed under the Apache License, Version 2.0 (the "License");
   * you may not use this file except in compliance with the License.
   * You may obtain a copy of the License at
   *
   *   http://www.apache.org/licenses/LICENSE-2.0
   *
   * Unless required by applicable law or agreed to in writing, software
   * distributed under the License is distributed on an "AS IS" BASIS,
   * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
   * See the License for the specific language governing permissions and
   * limitations under the License.
   *)

@firebase/app/dist/esm/index.esm2017.js:
  (**
   * @license
   * Copyright 2019 Google LLC
   *
   * Licensed under the Apache License, Version 2.0 (the "License");
   * you may not use this file except in compliance with the License.
   * You may obtain a copy of the License at
   *
   *   http://www.apache.org/licenses/LICENSE-2.0
   *
   * Unless required by applicable law or agreed to in writing, software
   * distributed under the License is distributed on an "AS IS" BASIS,
   * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
   * See the License for the specific language governing permissions and
   * limitations under the License.
   *)

@firebase/app/dist/esm/index.esm2017.js:
  (**
   * @license
   * Copyright 2019 Google LLC
   *
   * Licensed under the Apache License, Version 2.0 (the "License");
   * you may not use this file except in compliance with the License.
   * You may obtain a copy of the License at
   *
   *   http://www.apache.org/licenses/LICENSE-2.0
   *
   * Unless required by applicable law or agreed to in writing, software
   * distributed under the License is distributed on an "AS IS" BASIS,
   * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
   * See the License for the specific language governing permissions and
   * limitations under the License.
   *)

@firebase/app/dist/esm/index.esm2017.js:
  (**
   * @license
   * Copyright 2021 Google LLC
   *
   * Licensed under the Apache License, Version 2.0 (the "License");
   * you may not use this file except in compliance with the License.
   * You may obtain a copy of the License at
   *
   *   http://www.apache.org/licenses/LICENSE-2.0
   *
   * Unless required by applicable law or agreed to in writing, software
   * distributed under the License is distributed on an "AS IS" BASIS,
   * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
   * See the License for the specific language governing permissions and
   * limitations under the License.
   *)
  (**
   * @license
   * Copyright 2019 Google LLC
   *
   * Licensed under the Apache License, Version 2.0 (the "License");
   * you may not use this file except in compliance with the License.
   * You may obtain a copy of the License at
   *
   *   http://www.apache.org/licenses/LICENSE-2.0
   *
   * Unless required by applicable law or agreed to in writing, software
   * distributed under the License is distributed on an "AS IS" BASIS,
   * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
   * See the License for the specific language governing permissions and
   * limitations under the License.
   *)

firebase/app/dist/esm/index.esm.js:
  (**
   * @license
   * Copyright 2020 Google LLC
   *
   * Licensed under the Apache License, Version 2.0 (the "License");
   * you may not use this file except in compliance with the License.
   * You may obtain a copy of the License at
   *
   *   http://www.apache.org/licenses/LICENSE-2.0
   *
   * Unless required by applicable law or agreed to in writing, software
   * distributed under the License is distributed on an "AS IS" BASIS,
   * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
   * See the License for the specific language governing permissions and
   * limitations under the License.
   *)

@firebase/firestore/dist/index.esm2017.js:
  (**
   * @license
   * Copyright 2017 Google LLC
   *
   * Licensed under the Apache License, Version 2.0 (the "License");
   * you may not use this file except in compliance with the License.
   * You may obtain a copy of the License at
   *
   *   http://www.apache.org/licenses/LICENSE-2.0
   *
   * Unless required by applicable law or agreed to in writing, software
   * distributed under the License is distributed on an "AS IS" BASIS,
   * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
   * See the License for the specific language governing permissions and
   * limitations under the License.
   *)

@firebase/firestore/dist/index.esm2017.js:
  (**
  * @license
  * Copyright 2020 Google LLC
  *
  * Licensed under the Apache License, Version 2.0 (the "License");
  * you may not use this file except in compliance with the License.
  * You may obtain a copy of the License at
  *
  *   http://www.apache.org/licenses/LICENSE-2.0
  *
  * Unless required by applicable law or agreed to in writing, software
  * distributed under the License is distributed on an "AS IS" BASIS,
  * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
  * See the License for the specific language governing permissions and
  * limitations under the License.
  *)
  (**
   * @license
   * Copyright 2017 Google LLC
   *
   * Licensed under the Apache License, Version 2.0 (the "License");
   * you may not use this file except in compliance with the License.
   * You may obtain a copy of the License at
   *
   *   http://www.apache.org/licenses/LICENSE-2.0
   *
   * Unless required by applicable law or agreed to in writing, software
   * distributed under the License is distributed on an "AS IS" BASIS,
   * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
   * See the License for the specific language governing permissions and
   * limitations under the License.
   *)

@firebase/firestore/dist/index.esm2017.js:
  (**
   * @license
   * Copyright 2017 Google LLC
   *
   * Licensed under the Apache License, Version 2.0 (the "License");
   * you may not use this file except in compliance with the License.
   * You may obtain a copy of the License at
   *
   *   http://www.apache.org/licenses/LICENSE-2.0
   *
   * Unless required by applicable law or agreed to in writing, software
   * distributed under the License is distributed on an "AS IS" BASIS,
   * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
   * See the License for the specific language governing permissions and
   * limitations under the License.
   *)

@firebase/firestore/dist/index.esm2017.js:
  (**
   * @license
   * Copyright 2020 Google LLC
   *
   * Licensed under the Apache License, Version 2.0 (the "License");
   * you may not use this file except in compliance with the License.
   * You may obtain a copy of the License at
   *
   *   http://www.apache.org/licenses/LICENSE-2.0
   *
   * Unless required by applicable law or agreed to in writing, software
   * distributed under the License is distributed on an "AS IS" BASIS,
   * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
   * See the License for the specific language governing permissions and
   * limitations under the License.
   *)
  (**
   * @license
   * Copyright 2017 Google LLC
   *
   * Licensed under the Apache License, Version 2.0 (the "License");
   * you may not use this file except in compliance with the License.
   * You may obtain a copy of the License at
   *
   *   http://www.apache.org/licenses/LICENSE-2.0
   *
   * Unless required by applicable law or agreed to in writing, software
   * distributed under the License is distributed on an "AS IS" BASIS,
   * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
   * See the License for the specific language governing permissions and
   * limitations under the License.
   *)

@firebase/firestore/dist/index.esm2017.js:
  (**
   * @license
   * Copyright 2017 Google LLC
   *
   * Licensed under the Apache License, Version 2.0 (the "License");
   * you may not use this file except in compliance with the License.
   * You may obtain a copy of the License at
   *
   *   http://www.apache.org/licenses/LICENSE-2.0
   *
   * Unless required by applicable law or agreed to in writing, software
   * distributed under the License is distributed on an "AS IS" BASIS,
   * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
   * See the License for the specific language governing permissions and
   * limitations under the License.
   *)
  (**
   * @license
   * Copyright 2021 Google LLC
   *
   * Licensed under the Apache License, Version 2.0 (the "License");
   * you may not use this file except in compliance with the License.
   * You may obtain a copy of the License at
   *
   *   http://www.apache.org/licenses/LICENSE-2.0
   *
   * Unless required by applicable law or agreed to in writing, software
   * distributed under the License is distributed on an "AS IS" BASIS,
   * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
   * See the License for the specific language governing permissions and
   * limitations under the License.
   *)

@firebase/firestore/dist/index.esm2017.js:
  (**
   * @license
   * Copyright 2020 Google LLC
   *
   * Licensed under the Apache License, Version 2.0 (the "License");
   * you may not use this file except in compliance with the License.
   * You may obtain a copy of the License at
   *
   *   http://www.apache.org/licenses/LICENSE-2.0
   *
   * Unless required by applicable law or agreed to in writing, software
   * distributed under the License is distributed on an "AS IS" BASIS,
   * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
   * See the License for the specific language governing permissions and
   * limitations under the License.
   *)
  (**
   * @license
   * Copyright 2017 Google LLC
   *
   * Licensed under the Apache License, Version 2.0 (the "License");
   * you may not use this file except in compliance with the License.
   * You may obtain a copy of the License at
   *
   *   http://www.apache.org/licenses/LICENSE-2.0
   *
   * Unless required by applicable law or agreed to in writing, software
   * distributed under the License is distributed on an "AS IS" BASIS,
   * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
   * See the License for the specific language governing permissions and
   * limitations under the License.
   *)

@firebase/firestore/dist/index.esm2017.js:
  (**
   * @license
   * Copyright 2018 Google LLC
   *
   * Licensed under the Apache License, Version 2.0 (the "License");
   * you may not use this file except in compliance with the License.
   * You may obtain a copy of the License at
   *
   *   http://www.apache.org/licenses/LICENSE-2.0
   *
   * Unless required by applicable law or agreed to in writing, software
   * distributed under the License is distributed on an "AS IS" BASIS,
   * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
   * See the License for the specific language governing permissions and
   * limitations under the License.
   *)

@firebase/firestore/dist/index.esm2017.js:
  (**
   * @license
   * Copyright 2017 Google LLC
   *
   * Licensed under the Apache License, Version 2.0 (the "License");
   * you may not use this file except in compliance with the License.
   * You may obtain a copy of the License at
   *
   *   http://www.apache.org/licenses/LICENSE-2.0
   *
   * Unless required by applicable law or agreed to in writing, software
   * distributed under the License is distributed on an "AS IS" BASIS,
   * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
   * See the License for the specific language governing permissions and
   * limitations under the License.
   *)

@firebase/firestore/dist/index.esm2017.js:
  (**
   * @license
   * Copyright 2022 Google LLC
   *
   * Licensed under the Apache License, Version 2.0 (the "License");
   * you may not use this file except in compliance with the License.
   * You may obtain a copy of the License at
   *
   *   http://www.apache.org/licenses/LICENSE-2.0
   *
   * Unless required by applicable law or agreed to in writing, software
   * distributed under the License is distributed on an "AS IS" BASIS,
   * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
   * See the License for the specific language governing permissions and
   * limitations under the License.
   *)

@firebase/firestore/dist/index.esm2017.js:
  (**
   * @license
   * Copyright 2022 Google LLC
   *
   * Licensed under the Apache License, Version 2.0 (the "License");
   * you may not use this file except in compliance with the License.
   * You may obtain a copy of the License at
   *
   *   http://www.apache.org/licenses/LICENSE-2.0
   *
   * Unless required by applicable law or agreed to in writing, software
   * distributed under the License is distributed on an "AS IS" BASIS,
   * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
   * See the License for the specific language governing permissions and
   * limitations under the License.
   *)

@firebase/firestore/dist/index.esm2017.js:
  (**
   * @license
   * Copyright 2020 Google LLC
   *
   * Licensed under the Apache License, Version 2.0 (the "License");
   * you may not use this file except in compliance with the License.
   * You may obtain a copy of the License at
   *
   *   http://www.apache.org/licenses/LICENSE-2.0
   *
   * Unless required by applicable law or agreed to in writing, software
   * distributed under the License is distributed on an "AS IS" BASIS,
   * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
   * See the License for the specific language governing permissions and
   * limitations under the License.
   *)

@firebase/firestore/dist/index.esm2017.js:
  (**
   * @license
   * Copyright 2017 Google LLC
   *
   * Licensed under the Apache License, Version 2.0 (the "License");
   * you may not use this file except in compliance with the License.
   * You may obtain a copy of the License at
   *
   *   http://www.apache.org/licenses/LICENSE-2.0
   *
   * Unless required by applicable law or agreed to in writing, software
   * distributed under the License is distributed on an "AS IS" BASIS,
   * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
   * See the License for the specific language governing permissions and
   * limitations under the License.
   *)

@firebase/firestore/dist/index.esm2017.js:
  (**
   * @license
   * Copyright 2020 Google LLC
   *
   * Licensed under the Apache License, Version 2.0 (the "License");
   * you may not use this file except in compliance with the License.
   * You may obtain a copy of the License at
   *
   *   http://www.apache.org/licenses/LICENSE-2.0
   *
   * Unless required by applicable law or agreed to in writing, software
   * distributed under the License is distributed on an "AS IS" BASIS,
   * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
   * See the License for the specific language governing permissions and
   * limitations under the License.
   *)
  (**
   * @license
   * Copyright 2023 Google LLC
   *
   * Licensed under the Apache License, Version 2.0 (the "License");
   * you may not use this file except in compliance with the License.
   * You may obtain a copy of the License at
   *
   *   http://www.apache.org/licenses/LICENSE-2.0
   *
   * Unless required by applicable law or agreed to in writing, software
   * distributed under the License is distributed on an "AS IS" BASIS,
   * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
   * See the License for the specific language governing permissions and
   * limitations under the License.
   *)

@firebase/firestore/dist/index.esm2017.js:
  (**
   * @license
   * Copyright 2020 Google LLC
   *
   * Licensed under the Apache License, Version 2.0 (the "License");
   * you may not use this file except in compliance with the License.
   * You may obtain a copy of the License at
   *
   *   http://www.apache.org/licenses/LICENSE-2.0
   *
   * Unless required by applicable law or agreed to in writing, software
   * distributed under the License is distributed on an "AS IS" BASIS,
   * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
   * See the License for the specific language governing permissions and
   * limitations under the License.
   *)
  (**
   * @license
   * Copyright 2017 Google LLC
   *
   * Licensed under the Apache License, Version 2.0 (the "License");
   * you may not use this file except in compliance with the License.
   * You may obtain a copy of the License at
   *
   *   http://www.apache.org/licenses/LICENSE-2.0
   *
   * Unless required by applicable law or agreed to in writing, software
   * distributed under the License is distributed on an "AS IS" BASIS,
   * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
   * See the License for the specific language governing permissions and
   * limitations under the License.
   *)

@firebase/firestore/dist/index.esm2017.js:
  (**
   * @license
   * Copyright 2017 Google LLC
   *
   * Licensed under the Apache License, Version 2.0 (the "License");
   * you may not use this file except in compliance with the License.
   * You may obtain a copy of the License at
   *
   *   http://www.apache.org/licenses/LICENSE-2.0
   *
   * Unless required by applicable law or agreed to in writing, software
   * distributed under the License is distributed on an "AS IS" BASIS,
   * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
   * See the License for the specific language governing permissions and
   * limitations under the License.
   *)

@firebase/firestore/dist/index.esm2017.js:
  (**
   * @license
   * Copyright 2017 Google LLC
   *
   * Licensed under the Apache License, Version 2.0 (the "License");
   * you may not use this file except in compliance with the License.
   * You may obtain a copy of the License at
   *
   *   http://www.apache.org/licenses/LICENSE-2.0
   *
   * Unless required by applicable law or agreed to in writing, software
   * distributed under the License is distributed on an "AS IS" BASIS,
   * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
   * See the License for the specific language governing permissions and
   * limitations under the License.
   *)
  (**
   * @license
   * Copyright 2022 Google LLC
   *
   * Licensed under the Apache License, Version 2.0 (the "License");
   * you may not use this file except in compliance with the License.
   * You may obtain a copy of the License at
   *
   *   http://www.apache.org/licenses/LICENSE-2.0
   *
   * Unless required by applicable law or agreed to in writing, software
   * distributed under the License is distributed on an "AS IS" BASIS,
   * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
   * See the License for the specific language governing permissions and
   * limitations under the License.
   *)

@firebase/firestore/dist/index.esm2017.js:
  (**
   * @license
   * Copyright 2019 Google LLC
   *
   * Licensed under the Apache License, Version 2.0 (the "License");
   * you may not use this file except in compliance with the License.
   * You may obtain a copy of the License at
   *
   *   http://www.apache.org/licenses/LICENSE-2.0
   *
   * Unless required by applicable law or agreed to in writing, software
   * distributed under the License is distributed on an "AS IS" BASIS,
   * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
   * See the License for the specific language governing permissions and
   * limitations under the License.
   *)

@firebase/firestore/dist/index.esm2017.js:
  (**
   * @license
   * Copyright 2017 Google LLC
   *
   * Licensed under the Apache License, Version 2.0 (the "License");
   * you may not use this file except in compliance with the License.
   * You may obtain a copy of the License at
   *
   *   http://www.apache.org/licenses/LICENSE-2.0
   *
   * Unless required by applicable law or agreed to in writing, software
   * distributed under the License is distributed on an "AS IS" BASIS,
   * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
   * See the License for the specific language governing permissions and
   * limitations under the License.
   *)

@firebase/firestore/dist/index.esm2017.js:
  (**
   * @license
   * Copyright 2017 Google LLC
   *
   * Licensed under the Apache License, Version 2.0 (the "License");
   * you may not use this file except in compliance with the License.
   * You may obtain a copy of the License at
   *
   *   http://www.apache.org/licenses/LICENSE-2.0
   *
   * Unless required by applicable law or agreed to in writing, software
   * distributed under the License is distributed on an "AS IS" BASIS,
   * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
   * See the License for the specific language governing permissions and
   * limitations under the License.
   *)
  (**
   * @license
   * Copyright 2020 Google LLC
   *
   * Licensed under the Apache License, Version 2.0 (the "License");
   * you may not use this file except in compliance with the License.
   * You may obtain a copy of the License at
   *
   *   http://www.apache.org/licenses/LICENSE-2.0
   *
   * Unless required by applicable law or agreed to in writing, software
   * distributed under the License is distributed on an "AS IS" BASIS,
   * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
   * See the License for the specific language governing permissions and
   * limitations under the License.
   *)

@firebase/firestore/dist/index.esm2017.js:
  (**
   * @license
   * Copyright 2018 Google LLC
   *
   * Licensed under the Apache License, Version 2.0 (the "License");
   * you may not use this file except in compliance with the License.
   * You may obtain a copy of the License at
   *
   *   http://www.apache.org/licenses/LICENSE-2.0
   *
   * Unless required by applicable law or agreed to in writing, software
   * distributed under the License is distributed on an "AS IS" BASIS,
   * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
   * See the License for the specific language governing permissions and
   * limitations under the License.
   *)
  (**
   * @license
   * Copyright 2017 Google LLC
   *
   * Licensed under the Apache License, Version 2.0 (the "License");
   * you may not use this file except in compliance with the License.
   * You may obtain a copy of the License at
   *
   *   http://www.apache.org/licenses/LICENSE-2.0
   *
   * Unless required by applicable law or agreed to in writing, software
   * distributed under the License is distributed on an "AS IS" BASIS,
   * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
   * See the License for the specific language governing permissions and
   * limitations under the License.
   *)

@firebase/firestore/dist/index.esm2017.js:
  (**
   * @license
   * Copyright 2017 Google LLC
   *
   * Licensed under the Apache License, Version 2.0 (the "License");
   * you may not use this file except in compliance with the License.
   * You may obtain a copy of the License at
   *
   *   http://www.apache.org/licenses/LICENSE-2.0
   *
   * Unless required by applicable law or agreed to in writing, software
   * distributed under the License is distributed on an "AS IS" BASIS,
   * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
   * See the License for the specific language governing permissions and
   * limitations under the License.
   *)

@firebase/firestore/dist/index.esm2017.js:
  (**
   * @license
   * Copyright 2022 Google LLC
   *
   * Licensed under the Apache License, Version 2.0 (the "License");
   * you may not use this file except in compliance with the License.
   * You may obtain a copy of the License at
   *
   *   http://www.apache.org/licenses/LICENSE-2.0
   *
   * Unless required by applicable law or agreed to in writing, software
   * distributed under the License is distributed on an "AS IS" BASIS,
   * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
   * See the License for the specific language governing permissions and
   * limitations under the License.
   *)
  (**
   * @license
   * Copyright 2023 Google LLC
   *
   * Licensed under the Apache License, Version 2.0 (the "License");
   * you may not use this file except in compliance with the License.
   * You may obtain a copy of the License at
   *
   *   http://www.apache.org/licenses/LICENSE-2.0
   *
   * Unless required by applicable law or agreed to in writing, software
   * distributed under the License is distributed on an "AS IS" BASIS,
   * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
   * See the License for the specific language governing permissions and
   * limitations under the License.
   *)

@firebase/firestore/dist/index.esm2017.js:
  (**
   * @license
   * Copyright 2017 Google LLC
   *
   * Licensed under the Apache License, Version 2.0 (the "License");
   * you may not use this file except in compliance with the License.
   * You may obtain a copy of the License at
   *
   *   http://www.apache.org/licenses/LICENSE-2.0
   *
   * Unless required by applicable law or agreed to in writing, software
   * distributed under the License is distributed on an "AS IS" BASIS,
   * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
   * See the License for the specific language governing permissions and
   * limitations under the License.
   *)

@firebase/firestore/dist/index.esm2017.js:
  (**
   * @license
   * Copyright 2023 Google LLC
   *
   * Licensed under the Apache License, Version 2.0 (the "License");
   * you may not use this file except in compliance with the License.
   * You may obtain a copy of the License at
   *
   *   http://www.apache.org/licenses/LICENSE-2.0
   *
   * Unless required by applicable law or agreed to in writing, software
   * distributed under the License is distributed on an "AS IS" BASIS,
   * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
   * See the License for the specific language governing permissions and
   * limitations under the License.
   *)
  (**
   * @license
   * Copyright 2022 Google LLC
   *
   * Licensed under the Apache License, Version 2.0 (the "License");
   * you may not use this file except in compliance with the License.
   * You may obtain a copy of the License at
   *
   *   http://www.apache.org/licenses/LICENSE-2.0
   *
   * Unless required by applicable law or agreed to in writing, software
   * distributed under the License is distributed on an "AS IS" BASIS,
   * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
   * See the License for the specific language governing permissions and
   * limitations under the License.
   *)
  (**
   * @license
   * Copyright 2017 Google LLC
   *
   * Licensed under the Apache License, Version 2.0 (the "License");
   * you may not use this file except in compliance with the License.
   * You may obtain a copy of the License at
   *
   *   http://www.apache.org/licenses/LICENSE-2.0
   *
   * Unless required by applicable law or agreed to in writing, software
   * distributed under the License is distributed on an "AS IS" BASIS,
   * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
   * See the License for the specific language governing permissions and
   * limitations under the License.
   *)

@firebase/firestore/dist/index.esm2017.js:
  (**
   * @license
   * Copyright 2017 Google LLC
   *
   * Licensed under the Apache License, Version 2.0 (the "License");
   * you may not use this file except in compliance with the License.
   * You may obtain a copy of the License at
   *
   *   http://www.apache.org/licenses/LICENSE-2.0
   *
   * Unless required by applicable law or agreed to in writing, software
   * distributed under the License is distributed on an "AS IS" BASIS,
   * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
   * See the License for the specific language governing permissions and
   * limitations under the License.
   *)

@firebase/firestore/dist/index.esm2017.js:
  (**
   * @license
   * Copyright 2020 Google LLC
   *
   * Licensed under the Apache License, Version 2.0 (the "License");
   * you may not use this file except in compliance with the License.
   * You may obtain a copy of the License at
   *
   *   http://www.apache.org/licenses/LICENSE-2.0
   *
   * Unless required by applicable law or agreed to in writing, software
   * distributed under the License is distributed on an "AS IS" BASIS,
   * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
   * See the License for the specific language governing permissions and
   * limitations under the License.
   *)

@firebase/firestore/dist/index.esm2017.js:
  (**
   * @license
   * Copyright 2022 Google LLC
   *
   * Licensed under the Apache License, Version 2.0 (the "License");
   * you may not use this file except in compliance with the License.
   * You may obtain a copy of the License at
   *
   *   http://www.apache.org/licenses/LICENSE-2.0
   *
   * Unless required by applicable law or agreed to in writing, software
   * distributed under the License is distributed on an "AS IS" BASIS,
   * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
   * See the License for the specific language governing permissions and
   * limitations under the License.
   *)

@firebase/firestore/dist/index.esm2017.js:
  (**
   * @license
   * Copyright 2021 Google LLC
   *
   * Licensed under the Apache License, Version 2.0 (the "License");
   * you may not use this file except in compliance with the License.
   * You may obtain a copy of the License at
   *
   *   http://www.apache.org/licenses/LICENSE-2.0
   *
   * Unless required by applicable law or agreed to in writing, software
   * distributed under the License is distributed on an "AS IS" BASIS,
   * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
   * See the License for the specific language governing permissions and
   * limitations under the License.
   *)

@firebase/firestore/dist/index.esm2017.js:
  (**
   * @license
   * Copyright 2022 Google LLC
   *
   * Licensed under the Apache License, Version 2.0 (the "License");
   * you may not use this file except in compliance with the License.
   * You may obtain a copy of the License at
   *
   *   http://www.apache.org/licenses/LICENSE-2.0
   *
   * Unless required by applicable law or agreed to in writing, software
   * distributed under the License is distributed on an "AS IS" BASIS,
   * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
   * See the License for the specific language governing permissions and
   * limitations under the License.
   *)

@firebase/firestore/dist/index.esm2017.js:
  (**
   * @license
   * Copyright 2022 Google LLC
   *
   * Licensed under the Apache License, Version 2.0 (the "License");
   * you may not use this file except in compliance with the License.
   * You may obtain a copy of the License at
   *
   *   http://www.apache.org/licenses/LICENSE-2.0
   *
   * Unless required by applicable law or agreed to in writing, software
   * distributed under the License is distributed on an "AS IS" BASIS,
   * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
   * See the License for the specific language governing permissions and
   * limitations under the License.
   *)

@firebase/firestore/dist/index.esm2017.js:
  (**
   * @license
   * Copyright 2022 Google LLC
   *
   * Licensed under the Apache License, Version 2.0 (the "License");
   * you may not use this file except in compliance with the License.
   * You may obtain a copy of the License at
   *
   *   http://www.apache.org/licenses/LICENSE-2.0
   *
   * Unless required by applicable law or agreed to in writing, software
   * distributed under the License is distributed on an "AS IS" BASIS,
   * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
   * See the License for the specific language governing permissions and
   * limitations under the License.
   *)

@firebase/firestore/dist/index.esm2017.js:
  (**
   * @license
   * Copyright 2019 Google LLC
   *
   * Licensed under the Apache License, Version 2.0 (the "License");
   * you may not use this file except in compliance with the License.
   * You may obtain a copy of the License at
   *
   *   http://www.apache.org/licenses/LICENSE-2.0
   *
   * Unless required by applicable law or agreed to in writing, software
   * distributed under the License is distributed on an "AS IS" BASIS,
   * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
   * See the License for the specific language governing permissions and
   * limitations under the License.
   *)

@firebase/firestore/dist/index.esm2017.js:
  (**
   * @license
   * Copyright 2018 Google LLC
   *
   * Licensed under the Apache License, Version 2.0 (the "License");
   * you may not use this file except in compliance with the License.
   * You may obtain a copy of the License at
   *
   *   http://www.apache.org/licenses/LICENSE-2.0
   *
   * Unless required by applicable law or agreed to in writing, software
   * distributed under the License is distributed on an "AS IS" BASIS,
   * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
   * See the License for the specific language governing permissions and
   * limitations under the License.
   *)

@firebase/firestore/dist/index.esm2017.js:
  (**
   * @license
   * Copyright 2020 Google LLC
   *
   * Licensed under the Apache License, Version 2.0 (the "License");
   * you may not use this file except in compliance with the License.
   * You may obtain a copy of the License at
   *
   *   http://www.apache.org/licenses/LICENSE-2.0
   *
   * Unless required by applicable law or agreed to in writing, software
   * distributed under the License is distributed on an "AS IS" BASIS,
   * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
   * See the License for the specific language governing permissions and
   * limitations under the License.
   *)

@firebase/firestore/dist/index.esm2017.js:
  (**
   * @license
   * Copyright 2017 Google LLC
   *
   * Licensed under the Apache License, Version 2.0 (the "License");
   * you may not use this file except in compliance with the License.
   * You may obtain a copy of the License at
   *
   *   http://www.apache.org/licenses/LICENSE-2.0
   *
   * Unless required by applicable law or agreed to in writing, software
   * distributed under the License is distributed on an "AS IS" BASIS,
   * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
   * See the License for the specific language governing permissions and
   * limitations under the License.
   *)

@firebase/firestore/dist/index.esm2017.js:
  (**
   * @license
   * Copyright 2017 Google LLC
   *
   * Licensed under the Apache License, Version 2.0 (the "License");
   * you may not use this file except in compliance with the License.
   * You may obtain a copy of the License at
   *
   *   http://www.apache.org/licenses/LICENSE-2.0
   *
   * Unless required by applicable law or agreed to in writing, software
   * distributed under the License is distributed on an "AS IS" BASIS,
   * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
   * See the License for the specific language governing permissions and
   * limitations under the License.
   *)

@firebase/firestore/dist/index.esm2017.js:
  (**
   * @license
   * Copyright 2020 Google LLC
   *
   * Licensed under the Apache License, Version 2.0 (the "License");
   * you may not use this file except in compliance with the License.
   * You may obtain a copy of the License at
   *
   *   http://www.apache.org/licenses/LICENSE-2.0
   *
   * Unless required by applicable law or agreed to in writing, software
   * distributed under the License is distributed on an "AS IS" BASIS,
   * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
   * See the License for the specific language governing permissions and
   * limitations under the License.
   *)

@firebase/firestore/dist/index.esm2017.js:
  (**
   * @license
   * Copyright 2020 Google LLC
   *
   * Licensed under the Apache License, Version 2.0 (the "License");
   * you may not use this file except in compliance with the License.
   * You may obtain a copy of the License at
   *
   *   http://www.apache.org/licenses/LICENSE-2.0
   *
   * Unless required by applicable law or agreed to in writing, software
   * distributed under the License is distributed on an "AS IS" BASIS,
   * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
   * See the License for the specific language governing permissions and
   * limitations under the License.
   *)

@firebase/firestore/dist/index.esm2017.js:
  (**
   * @license
   * Copyright 2017 Google LLC
   *
   * Licensed under the Apache License, Version 2.0 (the "License");
   * you may not use this file except in compliance with the License.
   * You may obtain a copy of the License at
   *
   *   http://www.apache.org/licenses/LICENSE-2.0
   *
   * Unless required by applicable law or agreed to in writing, software
   * distributed under the License is distributed on an "AS IS" BASIS,
   * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
   * See the License for the specific language governing permissions and
   * limitations under the License.
   *)

@firebase/firestore/dist/index.esm2017.js:
  (**
   * @license
   * Copyright 2017 Google LLC
   *
   * Licensed under the Apache License, Version 2.0 (the "License");
   * you may not use this file except in compliance with the License.
   * You may obtain a copy of the License at
   *
   *   http://www.apache.org/licenses/LICENSE-2.0
   *
   * Unless required by applicable law or agreed to in writing, software
   * distributed under the License is distributed on an "AS IS" BASIS,
   * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
   * See the License for the specific language governing permissions and
   * limitations under the License.
   *)
  (**
   * @license
   * Copyright 2022 Google LLC
   *
   * Licensed under the Apache License, Version 2.0 (the "License");
   * you may not use this file except in compliance with the License.
   * You may obtain a copy of the License at
   *
   *   http://www.apache.org/licenses/LICENSE-2.0
   *
   * Unless required by applicable law or agreed to in writing, software
   * distributed under the License is distributed on an "AS IS" BASIS,
   * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
   * See the License for the specific language governing permissions and
   * limitations under the License.
   *)
  (**
   * @license
   * Copyright 2020 Google LLC
   *
   * Licensed under the Apache License, Version 2.0 (the "License");
   * you may not use this file except in compliance with the License.
   * You may obtain a copy of the License at
   *
   *   http://www.apache.org/licenses/LICENSE-2.0
   *
   * Unless required by applicable law or agreed to in writing, software
   * distributed under the License is distributed on an "AS IS" BASIS,
   * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
   * See the License for the specific language governing permissions and
   * limitations under the License.
   *)

@firebase/firestore/dist/index.esm2017.js:
  (**
   * @license
   * Copyright 2020 Google LLC
   *
   * Licensed under the Apache License, Version 2.0 (the "License");
   * you may not use this file except in compliance with the License.
   * You may obtain a copy of the License at
   *
   *   http://www.apache.org/licenses/LICENSE-2.0
   *
   * Unless required by applicable law or agreed to in writing, software
   * distributed under the License is distributed on an "AS IS" BASIS,
   * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
   * See the License for the specific language governing permissions and
   * limitations under the License.
   *)

@firebase/firestore/dist/index.esm2017.js:
  (**
   * @license
   * Copyright 2017 Google LLC
   *
   * Licensed under the Apache License, Version 2.0 (the "License");
   * you may not use this file except in compliance with the License.
   * You may obtain a copy of the License at
   *
   *   http://www.apache.org/licenses/LICENSE-2.0
   *
   * Unless required by applicable law or agreed to in writing, software
   * distributed under the License is distributed on an "AS IS" BASIS,
   * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
   * See the License for the specific language governing permissions and
   * limitations under the License.
   *)
  (**
   * @license
   * Copyright 2019 Google LLC
   *
   * Licensed under the Apache License, Version 2.0 (the "License");
   * you may not use this file except in compliance with the License.
   * You may obtain a copy of the License at
   *
   *   http://www.apache.org/licenses/LICENSE-2.0
   *
   * Unless required by applicable law or agreed to in writing, software
   * distributed under the License is distributed on an "AS IS" BASIS,
   * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
   * See the License for the specific language governing permissions and
   * limitations under the License.
   *)
  (**
   * @license
   * Copyright 2020 Google LLC
   *
   * Licensed under the Apache License, Version 2.0 (the "License");
   * you may not use this file except in compliance with the License.
   * You may obtain a copy of the License at
   *
   *   http://www.apache.org/licenses/LICENSE-2.0
   *
   * Unless required by applicable law or agreed to in writing, software
   * distributed under the License is distributed on an "AS IS" BASIS,
   * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
   * See the License for the specific language governing permissions and
   * limitations under the License.
   *)

@firebase/firestore/dist/index.esm2017.js:
  (**
   * @license
   * Copyright 2019 Google LLC
   *
   * Licensed under the Apache License, Version 2.0 (the "License");
   * you may not use this file except in compliance with the License.
   * You may obtain a copy of the License at
   *
   *   http://www.apache.org/licenses/LICENSE-2.0
   *
   * Unless required by applicable law or agreed to in writing, software
   * distributed under the License is distributed on an "AS IS" BASIS,
   * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
   * See the License for the specific language governing permissions and
   * limitations under the License.
   *)
  (**
   * @license
   * Copyright 2023 Google LLC
   *
   * Licensed under the Apache License, Version 2.0 (the "License");
   * you may not use this file except in compliance with the License.
   * You may obtain a copy of the License at
   *
   *   http://www.apache.org/licenses/LICENSE-2.0
   *
   * Unless required by applicable law or agreed to in writing, software
   * distributed under the License is distributed on an "AS IS" BASIS,
   * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
   * See the License for the specific language governing permissions and
   * limitations under the License.
   *)
  (**
   * @license
   * Copyright 2020 Google LLC
   *
   * Licensed under the Apache License, Version 2.0 (the "License");
   * you may not use this file except in compliance with the License.
   * You may obtain a copy of the License at
   *
   *   http://www.apache.org/licenses/LICENSE-2.0
   *
   * Unless required by applicable law or agreed to in writing, software
   * distributed under the License is distributed on an "AS IS" BASIS,
   * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
   * See the License for the specific language governing permissions and
   * limitations under the License.
   *)
  (**
   * @license
   * Copyright 2017 Google LLC
   *
   * Licensed under the Apache License, Version 2.0 (the "License");
   * you may not use this file except in compliance with the License.
   * You may obtain a copy of the License at
   *
   *   http://www.apache.org/licenses/LICENSE-2.0
   *
   * Unless required by applicable law or agreed to in writing, software
   * distributed under the License is distributed on an "AS IS" BASIS,
   * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
   * See the License for the specific language governing permissions and
   * limitations under the License.
   *)

@firebase/firestore/dist/index.esm2017.js:
  (**
   * @license
   * Copyright 2020 Google LLC
   *
   * Licensed under the Apache License, Version 2.0 (the "License");
   * you may not use this file except in compliance with the License.
   * You may obtain a copy of the License at
   *
   *   http://www.apache.org/licenses/LICENSE-2.0
   *
   * Unless required by applicable law or agreed to in writing, software
   * distributed under the License is distributed on an "AS IS" BASIS,
   * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
   * See the License for the specific language governing permissions and
   * limitations under the License.
   *)
  (**
   * @license
   * Copyright 2017 Google LLC
   *
   * Licensed under the Apache License, Version 2.0 (the "License");
   * you may not use this file except in compliance with the License.
   * You may obtain a copy of the License at
   *
   *   http://www.apache.org/licenses/LICENSE-2.0
   *
   * Unless required by applicable law or agreed to in writing, software
   * distributed under the License is distributed on an "AS IS" BASIS,
   * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
   * See the License for the specific language governing permissions and
   * limitations under the License.
   *)

@firebase/firestore/dist/index.esm2017.js:
  (**
   * @license
   * Copyright 2017 Google LLC
   *
   * Licensed under the Apache License, Version 2.0 (the "License");
   * you may not use this file except in compliance with the License.
   * You may obtain a copy of the License at
   *
   *   http://www.apache.org/licenses/LICENSE-2.0
   *
   * Unless required by applicable law or agreed to in writing, software
   * distributed under the License is distributed on an "AS IS" BASIS,
   * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
   * See the License for the specific language governing permissions and
   * limitations under the License.
   *)

@firebase/firestore/dist/index.esm2017.js:
  (**
   * @license
   * Copyright 2017 Google LLC
   *
   * Licensed under the Apache License, Version 2.0 (the "License");
   * you may not use this file except in compliance with the License.
   * You may obtain a copy of the License at
   *
   *   http://www.apache.org/licenses/LICENSE-2.0
   *
   * Unless required by applicable law or agreed to in writing, software
   * distributed under the License is distributed on an "AS IS" BASIS,
   * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
   * See the License for the specific language governing permissions and
   * limitations under the License.
   *)

@firebase/firestore/dist/index.esm2017.js:
  (**
   * @license
   * Copyright 2017 Google LLC
   *
   * Licensed under the Apache License, Version 2.0 (the "License");
   * you may not use this file except in compliance with the License.
   * You may obtain a copy of the License at
   *
   *   http://www.apache.org/licenses/LICENSE-2.0
   *
   * Unless required by applicable law or agreed to in writing, software
   * distributed under the License is distributed on an "AS IS" BASIS,
   * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
   * See the License for the specific language governing permissions and
   * limitations under the License.
   *)
  (**
   * @license
   * Copyright 2020 Google LLC
   *
   * Licensed under the Apache License, Version 2.0 (the "License");
   * you may not use this file except in compliance with the License.
   * You may obtain a copy of the License at
   *
   *   http://www.apache.org/licenses/LICENSE-2.0
   *
   * Unless required by applicable law or agreed to in writing, software
   * distributed under the License is distributed on an "AS IS" BASIS,
   * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
   * See the License for the specific language governing permissions and
   * limitations under the License.
   *)

@firebase/firestore/dist/index.esm2017.js:
  (**
   * @license
   * Copyright 2020 Google LLC
   *
   * Licensed under the Apache License, Version 2.0 (the "License");
   * you may not use this file except in compliance with the License.
   * You may obtain a copy of the License at
   *
   *   http://www.apache.org/licenses/LICENSE-2.0
   *
   * Unless required by applicable law or agreed to in writing, software
   * distributed under the License is distributed on an "AS IS" BASIS,
   * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
   * See the License for the specific language governing permissions and
   * limitations under the License.
   *)

@firebase/firestore/dist/index.esm2017.js:
  (**
   * @license
   * Copyright 2017 Google LLC
   *
   * Licensed under the Apache License, Version 2.0 (the "License");
   * you may not use this file except in compliance with the License.
   * You may obtain a copy of the License at
   *
   *   http://www.apache.org/licenses/LICENSE-2.0
   *
   * Unless required by applicable law or agreed to in writing, software
   * distributed under the License is distributed on an "AS IS" BASIS,
   * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
   * See the License for the specific language governing permissions and
   * limitations under the License.
   *)

@firebase/firestore/dist/index.esm2017.js:
  (**
   * @license
   * Copyright 2020 Google LLC
   *
   * Licensed under the Apache License, Version 2.0 (the "License");
   * you may not use this file except in compliance with the License.
   * You may obtain a copy of the License at
   *
   *   http://www.apache.org/licenses/LICENSE-2.0
   *
   * Unless required by applicable law or agreed to in writing, software
   * distributed under the License is distributed on an "AS IS" BASIS,
   * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
   * See the License for the specific language governing permissions and
   * limitations under the License.
   *)

@firebase/firestore/dist/index.esm2017.js:
  (**
   * @license
   * Copyright 2020 Google LLC
   *
   * Licensed under the Apache License, Version 2.0 (the "License");
   * you may not use this file except in compliance with the License.
   * You may obtain a copy of the License at
   *
   *   http://www.apache.org/licenses/LICENSE-2.0
   *
   * Unless required by applicable law or agreed to in writing, software
   * distributed under the License is distributed on an "AS IS" BASIS,
   * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
   * See the License for the specific language governing permissions and
   * limitations under the License.
   *)
  (**
   * @license
   * Copyright 2017 Google LLC
   *
   * Licensed under the Apache License, Version 2.0 (the "License");
   * you may not use this file except in compliance with the License.
   * You may obtain a copy of the License at
   *
   *   http://www.apache.org/licenses/LICENSE-2.0
   *
   * Unless required by applicable law or agreed to in writing, software
   * distributed under the License is distributed on an "AS IS" BASIS,
   * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
   * See the License for the specific language governing permissions and
   * limitations under the License.
   *)

@firebase/firestore/dist/index.esm2017.js:
  (**
   * @license
   * Copyright 2017 Google LLC
   *
   * Licensed under the Apache License, Version 2.0 (the "License");
   * you may not use this file except in compliance with the License.
   * You may obtain a copy of the License at
   *
   *   http://www.apache.org/licenses/LICENSE-2.0
   *
   * Unless required by applicable law or agreed to in writing, software
   * distributed under the License is distributed on an "AS IS" BASIS,
   * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
   * See the License for the specific language governing permissions and
   * limitations under the License.
   *)

@firebase/firestore/dist/index.esm2017.js:
  (**
   * @license
   * Copyright 2019 Google LLC
   *
   * Licensed under the Apache License, Version 2.0 (the "License");
   * you may not use this file except in compliance with the License.
   * You may obtain a copy of the License at
   *
   *   http://www.apache.org/licenses/LICENSE-2.0
   *
   * Unless required by applicable law or agreed to in writing, software
   * distributed under the License is distributed on an "AS IS" BASIS,
   * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
   * See the License for the specific language governing permissions and
   * limitations under the License.
   *)

@firebase/firestore/dist/index.esm2017.js:
  (**
   * @license
   * Copyright 2017 Google LLC
   *
   * Licensed under the Apache License, Version 2.0 (the "License");
   * you may not use this file except in compliance with the License.
   * You may obtain a copy of the License at
   *
   *   http://www.apache.org/licenses/LICENSE-2.0
   *
   * Unless required by applicable law or agreed to in writing, software
   * distributed under the License is distributed on an "AS IS" BASIS,
   * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
   * See the License for the specific language governing permissions and
   * limitations under the License.
   *)

@firebase/firestore/dist/index.esm2017.js:
  (**
   * @license
   * Copyright 2020 Google LLC
   *
   * Licensed under the Apache License, Version 2.0 (the "License");
   * you may not use this file except in compliance with the License.
   * You may obtain a copy of the License at
   *
   *   http://www.apache.org/licenses/LICENSE-2.0
   *
   * Unless required by applicable law or agreed to in writing, software
   * distributed under the License is distributed on an "AS IS" BASIS,
   * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
   * See the License for the specific language governing permissions and
   * limitations under the License.
   *)
  (**
   * @license
   * Copyright 2017 Google LLC
   *
   * Licensed under the Apache License, Version 2.0 (the "License");
   * you may not use this file except in compliance with the License.
   * You may obtain a copy of the License at
   *
   *   http://www.apache.org/licenses/LICENSE-2.0
   *
   * Unless required by applicable law or agreed to in writing, software
   * distributed under the License is distributed on an "AS IS" BASIS,
   * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
   * See the License for the specific language governing permissions and
   * limitations under the License.
   *)

@firebase/firestore/dist/index.esm2017.js:
  (**
   * @license
   * Copyright 2020 Google LLC
   *
   * Licensed under the Apache License, Version 2.0 (the "License");
   * you may not use this file except in compliance with the License.
   * You may obtain a copy of the License at
   *
   *   http://www.apache.org/licenses/LICENSE-2.0
   *
   * Unless required by applicable law or agreed to in writing, software
   * distributed under the License is distributed on an "AS IS" BASIS,
   * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
   * See the License for the specific language governing permissions and
   * limitations under the License.
   *)

@firebase/firestore/dist/index.esm2017.js:
  (**
   * @license
   * Copyright 2020 Google LLC
   *
   * Licensed under the Apache License, Version 2.0 (the "License");
   * you may not use this file except in compliance with the License.
   * You may obtain a copy of the License at
   *
   *   http://www.apache.org/licenses/LICENSE-2.0
   *
   * Unless required by applicable law or agreed to in writing, software
   * distributed under the License is distributed on an "AS IS" BASIS,
   * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
   * See the License for the specific language governing permissions and
   * limitations under the License.
   *)

@firebase/firestore/dist/index.esm2017.js:
  (**
   * @license
   * Copyright 2020 Google LLC
   *
   * Licensed under the Apache License, Version 2.0 (the "License");
   * you may not use this file except in compliance with the License.
   * You may obtain a copy of the License at
   *
   *   http://www.apache.org/licenses/LICENSE-2.0
   *
   * Unless required by applicable law or agreed to in writing, software
   * distributed under the License is distributed on an "AS IS" BASIS,
   * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
   * See the License for the specific language governing permissions and
   * limitations under the License.
   *)

@firebase/firestore/dist/index.esm2017.js:
  (**
   * @license
   * Copyright 2020 Google LLC
   *
   * Licensed under the Apache License, Version 2.0 (the "License");
   * you may not use this file except in compliance with the License.
   * You may obtain a copy of the License at
   *
   *   http://www.apache.org/licenses/LICENSE-2.0
   *
   * Unless required by applicable law or agreed to in writing, software
   * distributed under the License is distributed on an "AS IS" BASIS,
   * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
   * See the License for the specific language governing permissions and
   * limitations under the License.
   *)
  (**
   * @license
   * Copyright 2022 Google LLC
   *
   * Licensed under the Apache License, Version 2.0 (the "License");
   * you may not use this file except in compliance with the License.
   * You may obtain a copy of the License at
   *
   *   http://www.apache.org/licenses/LICENSE-2.0
   *
   * Unless required by applicable law or agreed to in writing, software
   * distributed under the License is distributed on an "AS IS" BASIS,
   * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
   * See the License for the specific language governing permissions and
   * limitations under the License.
   *)

@firebase/firestore/dist/index.esm2017.js:
  (**
   * @license
   * Copyright 2020 Google LLC
   *
   * Licensed under the Apache License, Version 2.0 (the "License");
   * you may not use this file except in compliance with the License.
   * You may obtain a copy of the License at
   *
   *   http://www.apache.org/licenses/LICENSE-2.0
   *
   * Unless required by applicable law or agreed to in writing, software
   * distributed under the License is distributed on an "AS IS" BASIS,
   * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
   * See the License for the specific language governing permissions and
   * limitations under the License.
   *)

@firebase/firestore/dist/index.esm2017.js:
  (**
   * @license
   * Copyright 2020 Google LLC
   *
   * Licensed under the Apache License, Version 2.0 (the "License");
   * you may not use this file except in compliance with the License.
   * You may obtain a copy of the License at
   *
   *   http://www.apache.org/licenses/LICENSE-2.0
   *
   * Unless required by applicable law or agreed to in writing, software
   * distributed under the License is distributed on an "AS IS" BASIS,
   * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
   * See the License for the specific language governing permissions and
   * limitations under the License.
   *)

@firebase/firestore/dist/index.esm2017.js:
  (**
   * @license
   * Copyright 2017 Google LLC
   *
   * Licensed under the Apache License, Version 2.0 (the "License");
   * you may not use this file except in compliance with the License.
   * You may obtain a copy of the License at
   *
   *   http://www.apache.org/licenses/LICENSE-2.0
   *
   * Unless required by applicable law or agreed to in writing, software
   * distributed under the License is distributed on an "AS IS" BASIS,
   * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
   * See the License for the specific language governing permissions and
   * limitations under the License.
   *)

@firebase/firestore/dist/index.esm2017.js:
  (**
   * @license
   * Copyright 2020 Google LLC
   *
   * Licensed under the Apache License, Version 2.0 (the "License");
   * you may not use this file except in compliance with the License.
   * You may obtain a copy of the License at
   *
   *   http://www.apache.org/licenses/LICENSE-2.0
   *
   * Unless required by applicable law or agreed to in writing, software
   * distributed under the License is distributed on an "AS IS" BASIS,
   * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
   * See the License for the specific language governing permissions and
   * limitations under the License.
   *)

@firebase/firestore/dist/index.esm2017.js:
  (**
   * @license
   * Copyright 2020 Google LLC
   *
   * Licensed under the Apache License, Version 2.0 (the "License");
   * you may not use this file except in compliance with the License.
   * You may obtain a copy of the License at
   *
   *   http://www.apache.org/licenses/LICENSE-2.0
   *
   * Unless required by applicable law or agreed to in writing, software
   * distributed under the License is distributed on an "AS IS" BASIS,
   * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
   * See the License for the specific language governing permissions and
   * limitations under the License.
   *)

@firebase/firestore/dist/index.esm2017.js:
  (**
   * @license
   * Copyright 2022 Google LLC
   *
   * Licensed under the Apache License, Version 2.0 (the "License");
   * you may not use this file except in compliance with the License.
   * You may obtain a copy of the License at
   *
   *   http://www.apache.org/licenses/LICENSE-2.0
   *
   * Unless required by applicable law or agreed to in writing, software
   * distributed under the License is distributed on an "AS IS" BASIS,
   * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
   * See the License for the specific language governing permissions and
   * limitations under the License.
   *)

@firebase/firestore/dist/index.esm2017.js:
  (**
   * @license
   * Copyright 2020 Google LLC
   *
   * Licensed under the Apache License, Version 2.0 (the "License");
   * you may not use this file except in compliance with the License.
   * You may obtain a copy of the License at
   *
   *   http://www.apache.org/licenses/LICENSE-2.0
   *
   * Unless required by applicable law or agreed to in writing, software
   * distributed under the License is distributed on an "AS IS" BASIS,
   * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
   * See the License for the specific language governing permissions and
   * limitations under the License.
   *)

@firebase/firestore/dist/index.esm2017.js:
  (**
   * @license
   * Copyright 2020 Google LLC
   *
   * Licensed under the Apache License, Version 2.0 (the "License");
   * you may not use this file except in compliance with the License.
   * You may obtain a copy of the License at
   *
   *   http://www.apache.org/licenses/LICENSE-2.0
   *
   * Unless required by applicable law or agreed to in writing, software
   * distributed under the License is distributed on an "AS IS" BASIS,
   * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
   * See the License for the specific language governing permissions and
   * limitations under the License.
   *)

@firebase/firestore/dist/index.esm2017.js:
  (**
   * @license
   * Copyright 2022 Google LLC
   *
   * Licensed under the Apache License, Version 2.0 (the "License");
   * you may not use this file except in compliance with the License.
   * You may obtain a copy of the License at
   *
   *   http://www.apache.org/licenses/LICENSE-2.0
   *
   * Unless required by applicable law or agreed to in writing, software
   * distributed under the License is distributed on an "AS IS" BASIS,
   * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
   * See the License for the specific language governing permissions and
   * limitations under the License.
   *)

@firebase/firestore/dist/index.esm2017.js:
  (**
   * @license
   * Copyright 2022 Google LLC
   *
   * Licensed under the Apache License, Version 2.0 (the "License");
   * you may not use this file except in compliance with the License.
   * You may obtain a copy of the License at
   *
   *   http://www.apache.org/licenses/LICENSE-2.0
   *
   * Unless required by applicable law or agreed to in writing, software
   * distributed under the License is distributed on an "AS IS" BASIS,
   * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
   * See the License for the specific language governing permissions and
   * limitations under the License.
   *)

@firebase/firestore/dist/index.esm2017.js:
  (**
   * @license
   * Copyright 2020 Google LLC
   *
   * Licensed under the Apache License, Version 2.0 (the "License");
   * you may not use this file except in compliance with the License.
   * You may obtain a copy of the License at
   *
   *   http://www.apache.org/licenses/LICENSE-2.0
   *
   * Unless required by applicable law or agreed to in writing, software
   * distributed under the License is distributed on an "AS IS" BASIS,
   * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
   * See the License for the specific language governing permissions and
   * limitations under the License.
   *)

@firebase/firestore/dist/index.esm2017.js:
  (**
   * @license
   * Copyright 2020 Google LLC
   *
   * Licensed under the Apache License, Version 2.0 (the "License");
   * you may not use this file except in compliance with the License.
   * You may obtain a copy of the License at
   *
   *   http://www.apache.org/licenses/LICENSE-2.0
   *
   * Unless required by applicable law or agreed to in writing, software
   * distributed under the License is distributed on an "AS IS" BASIS,
   * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
   * See the License for the specific language governing permissions and
   * limitations under the License.
   *)

@firebase/firestore/dist/index.esm2017.js:
  (**
   * @license
   * Copyright 2020 Google LLC
   *
   * Licensed under the Apache License, Version 2.0 (the "License");
   * you may not use this file except in compliance with the License.
   * You may obtain a copy of the License at
   *
   *   http://www.apache.org/licenses/LICENSE-2.0
   *
   * Unless required by applicable law or agreed to in writing, software
   * distributed under the License is distributed on an "AS IS" BASIS,
   * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
   * See the License for the specific language governing permissions and
   * limitations under the License.
   *)

@firebase/firestore/dist/index.esm2017.js:
  (**
   * @license
   * Copyright 2020 Google LLC
   *
   * Licensed under the Apache License, Version 2.0 (the "License");
   * you may not use this file except in compliance with the License.
   * You may obtain a copy of the License at
   *
   *   http://www.apache.org/licenses/LICENSE-2.0
   *
   * Unless required by applicable law or agreed to in writing, software
   * distributed under the License is distributed on an "AS IS" BASIS,
   * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
   * See the License for the specific language governing permissions and
   * limitations under the License.
   *)

@firebase/firestore/dist/index.esm2017.js:
  (**
   * @license
   * Copyright 2021 Google LLC
   *
   * Licensed under the Apache License, Version 2.0 (the "License");
   * you may not use this file except in compliance with the License.
   * You may obtain a copy of the License at
   *
   *   http://www.apache.org/licenses/LICENSE-2.0
   *
   * Unless required by applicable law or agreed to in writing, software
   * distributed under the License is distributed on an "AS IS" BASIS,
   * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
   * See the License for the specific language governing permissions and
   * limitations under the License.
   *)
*/
